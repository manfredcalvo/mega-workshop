# Préstamo Tarjetero

**Página:** https://www.viabcp.com/creditos/otros-creditos/prestamo-tarjetero

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Exclusivo de Tarjeta de Crédito:** Obtén hasta el 95% de tu línea de crédito disponible
- **Tu defines el número de cuotas:** Con financiamiento de 6 hasta 60 meses
- **Una Tasa preferencial para ti:** Nuestros asesores se encargarán de ayudarte a obtener una tasa más baja

---

## Beneficios

- La tasa es menor que la tasa de retiro de efectivo en cajeros automáticos o disposición de efectivo a través de Banca Móvil.
- Permite financiarte por un monto tope del 95% de tu línea de crédito.
- ¡Olvídate de los trámites! Es rápido y sin documentos adicionales*
- Puedes solicitarlo por montos desde S/ 500.
- ¡Nos acomodamos a tu necesidad! Lo puedes pagar hasta 60 meses*
*Sujeto a evaluación crediticia.

---

## Requisitos

- Contar con una tarjeta de crédito BCP activa.
- Contar con línea de crédito disponible.
- Tener un buen comportamiento en el sistema financiero.

---

## Tasas y Tarifas

Puedes consultar tu tasa de las siguientes maneras:
- Comunicándote con tu funcionario de negocios.
- Llamando al 311-9898.
- En cualquier Agencia BCP.
Financiamiento en cuotas desde 6 hasta 60 meses*
(*)Sujeto a evaluación crediticia.

---

## Documentación

- Para canales presenciales: documento de identidad (DNI) del titular de la tarjeta.

---

## Preguntas Frecuentes

**¿Qué es el Préstamo Tarjetero?**
Anteriormente, era conocido como Efectivo Preferente y ahora se llama “Préstamo Tarjetero”. 
 Es un préstamo que consume la línea de tu tarjeta de crédito a una tasa de interés exclusiva que brindamos a nuestros clientes que tengan un buen perfil crediticio.

**¿Cómo puedo solicitar el Préstamo Tarjetero?**
Puedes solicitar un Préstamo Tarjetero a través de los siguientes canales: 
- Funcionarios de negocios 
- Banca por teléfono 311-9898 
- Agencias BCP 
- En el formulario de esta web

**¿El Préstamo Tarjetero genera comisión?**
No genera ninguna comisión adicional.

**¿Donde podré ver el desembolso de mi Préstamo Tarjetero?**
Podrás ver el monto de desembolso en tu cuenta de ahorros. Por otro lado, el cargo figurará en tu estado de cuenta de la tarjeta de crédito en tu siguiente facturación.
