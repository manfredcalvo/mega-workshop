# Préstamo personal con garantía líquida

**La solución para quienes quieren ser protagonistas de su vida**

**Página:** https://www.viabcp.com/creditos/credito-efectivo/garantia-liquida

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Características


#### Beneficios

- Con el BCP puedes solicitar un préstamo con garantía en tus fondos.
- Se considera garantía líquida: Depósitos a plazo, Certificados Bancarios de moneda extranjera y fondos mutuos
- Plazos de 6 a 60 meses.
- Se puede dejar en garantía el depósito de un tercero, siempre y cuando este firme todos los documentos necesarios en los que autorice la afectación de la garantía.
- No se requiere que sustentes tus ingresos.
- No hay límite de edad para solicitar el préstamo.
- Puedes solicitar tu préstamo en moneda nacional o extranjera.
- Puedes **modificar tus cuotas, prepagar o cancelar** tu préstamo, en el momento que desees.
- El monto del préstamo, las cuotas y el plazo estarán sujetos a evaluación crediticia.

#### Más ventajas

- Puedes adquirir el crédito en cualquiera de nuestras Agencias BCP y/o comunicándote directamente con tu Funcionario BCP.
- Incluimos el Seguro de Desgravamen, el cual cancela la deuda de inmediato en caso de muerte, durante todo el plazo de endeudamiento.
- Si deseas realizar prepagos o cancelar tu préstamo, tienes la opción de hacerlo total o parcialmente, sin penalidades, sin comisiones y descontando los intereses respectivos.
- Puedes solicitar el cargo automático de tus cuotas en cualquiera de tus cuentas BCP.
- Si deseas, puedes afiliarte al nuestro [Seguro de Protección Financiera](https://www.viabcp.com/seguros/financieros/proteccion-financiera) , el cual pagará puntualmente tus cuotas en caso de desempleo o incapacidad.
- La cuota de tu crédito incluye el Seguro de Desgravamen, que protege a tu familia cancelando la deuda pendiente en caso de fallecimiento o invalidez permanente del titular del crédito.

#### Consideraciones

- El cliente tiene el derecho de elegir entre: 
- La contratación del seguro ofrecido por el banco. 
- Un seguro contratado directamente por el cliente o a través de la designación de un corredor de seguros , siempre que cumpla con las condiciones previamente informadas por el banco.
- Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Levantamiento de garantía liquida
4. Pagos anticipados
- En caso desee realizar pagos anticipados o adelanto de cuotas, el cliente tiene derecho a realizarlo en cualquier agencia BCP, eligiendo la opción que más le convenga: Pago anticipado: monto destinado al pago del capital del crédito. Se reduce intereses, comisiones y gastos al día de pago: 
- Reducción de plazo: reduce el número de cuotas del crédito manteniendo el importe de cuota original 
- Reducción de cuotas: reduce el importe de las cuotas del crédito, manteniendo el plazo original del mismo
**Adelanto de Cuotas:** pago realizado para la aplicación de las cuotas posteriores a las exigibles en el periodo de facturación. No se reducen intereses, comisiones ni gastos.

---

## Requisitos


#### Generales

- El monto mínimo de la garantía debe ser de S/. 7,500.
- El monto mínimo del préstamo debe ser de S/. 5,100.
- Tener depósitos a plazo, certificados bancarios en moneda extranjera (CBME), o fondos mutuos.
- Presentar la firma de la persona que garantizará el crédito, en caso de ser avalado por un tercero.
- Legalización de firmas del contrato de garantía.

#### Documentación

- Presentar tu documento de identidad en original y copia.
- Si estás casado, tu cónyuge también deberá firmar la solicitud y presentar la copia de su documento de identidad.
- También, tendrás que adjuntar el **recibo de teléfono fijo (copia)** de tu casa.
- En caso de ser garantizado por un tercero, deberá presentar documento de identidad.
- Es necesario que tu contrato de garantía esté debidamente legalizado y en el caso de que la garantía sea de 40 UITs o más, tendrás que elevar tu contrato a Registros.

---

## Tasas y Tarifas

- TEA para crédito en soles: desde 11% hasta 12% [(Ver más)](https://www.viabcp.com/wcm/connect/7c953d13-09e4-4b99-a10d-9904fc224acd/Credito%2Bpersonal%2Btasas%2Bsoles%2B%28GARANTIA%2BL%C3%8DQUIDA%29.pdf?MOD=AJPERES&CVID=pmGvBwM&attachment=false&id=1742323196578)
- TEA para crédito en dólares: desde 11% hasta 12%. [(Ver más)](https://www.viabcp.com/wcm/connect/7e1138c2-102e-4a5d-bce8-a68a2d7b5768/Credito+personal+tasas+dolares.pdf?MOD=AJPERES&CVID=oDs6XwP&attachment=false&id=1691615080803)

---

## Documentación


#### Contratos, Formularios e Información Importante

[Contrato de Crédito Personal BCP](https://www.viabcp.com/wcm/connect/64e18dec-de2f-4fc3-9c32-d440f5954c3e/Contrato+de+Pr%C3%A9stamo+Personal+BCP+%281%29.pdf?MOD=AJPERES&CVID=pAW9jY2&attachment=false&id=1757622851421)
[Calculadora de Crédito Personal BCP](https://www.viabcp.com/wcm/connect/30615566-36c1-409d-b44c-bacd667358cd/10.Simulador%2BCEF.xls?MOD=AJPERES&CVID=ojfD2dD&attachment=false&id=1669930427647)
[Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)
[Constitución de garantía mobiliaria sobre depósitos dinerarios](https://www.viabcp.com/wcm/connect/35217ef4-019a-4e8f-af3e-42cac2dc0061/CONTRATO%2BGARANTIA%2BLIQUIDA.pdf?MOD=AJPERES&CVID=pxWWrFx&attachment=false&id=1754409828017)
[Hoja Resumen de Crédito Efectivo BCP](https://www.viabcp.com/wcm/connect/04550acb-cdd0-4d51-b2fa-10671deb4dcc/Hoja+Resumen+%282%29.pdf?MOD=AJPERES&CVID=ovsI.Xp&attachment=false&id=1683035179023)
[Solicitud de Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/7f80cd8f-d2cc-4914-93b8-dffb262cccee/SOLICITUD_DE_PRESTAMO_CEF+%281%29.pdf?MOD=AJPERES&CVID=oMm7vt4&attachment=false&id=1701178318400)
[Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/23b67334-d53b-446b-bdd6-4fbe50a9a61b/6.Formulas%2By%2Bejemplos%2BCEF-update.pdf?MOD=AJPERES&CVID=osUjfHP&attachment=false&id=1680276892844)
[Formato de instrucción de pago](https://www.viabcp.com/wcm/connect/685e8392-95bd-4cce-a1ac-ef168955ca43/7.Formato%2Bde%2BInstruccio%CC%81n%2Bde%2BPago%2B%281%29+%281%29.pdf?MOD=AJPERES&CVID=ojfCdsp&attachment=false&id=1669930211366)
[Pasos para endoso de la póliza de seguro de desgravamen​](https://www.viabcp.com/wcm/connect/39d642a3-8a39-4442-8eed-bd043bb60a50/8.Pasos%2Bpara%2Bel%2Bendoso%2Bdel%2Bseguro%2Bde%2Bdesgravamen.pdf?MOD=AJPERES&CVID=ojfCrK.&attachment=false&id=1669930269870) ​​​​​​
[Seguro de desgravamen de Crédito Efectivo BCP](https://www.viabcp.com/wcm/connect/c40c0973-c6ae-4591-b5a8-9bbb01f86f07/Seguro+Desgravamen+Tradicional+%281%29.pdf?MOD=AJPERES&CVID=oMm70gD&attachment=false&id=1701178194512)
[Seguro desgravamen con retorno Crédito Efectivo](https://www.viabcp.com/wcm/connect/d36a6c3f-5510-43bd-9988-bce1f6a45bec/Seguro+Desgravamen+Retorno+%281%29.pdf?MOD=AJPERES&CVID=oMm7ofd&attachment=false&id=1701178287829)

### Documentos Descargables

- [Contrato de Crédito Personal BCP](https://www.viabcp.com/wcm/connect/64e18dec-de2f-4fc3-9c32-d440f5954c3e/Contrato+de+Pr%C3%A9stamo+Personal+BCP+%281%29.pdf?MOD=AJPERES&CVID=pAW9jY2&attachment=false&id=1757622851421)
- [Calculadora de Crédito Personal BCP](https://www.viabcp.com/wcm/connect/30615566-36c1-409d-b44c-bacd667358cd/10.Simulador%2BCEF.xls?MOD=AJPERES&CVID=ojfD2dD&attachment=false&id=1669930427647)
- [Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)
- [Constitución de garantía mobiliaria sobre depósitos dinerarios](https://www.viabcp.com/wcm/connect/35217ef4-019a-4e8f-af3e-42cac2dc0061/CONTRATO%2BGARANTIA%2BLIQUIDA.pdf?MOD=AJPERES&CVID=pxWWrFx&attachment=false&id=1754409828017)
- [Hoja Resumen de Crédito Efectivo BCP](https://www.viabcp.com/wcm/connect/04550acb-cdd0-4d51-b2fa-10671deb4dcc/Hoja+Resumen+%282%29.pdf?MOD=AJPERES&CVID=ovsI.Xp&attachment=false&id=1683035179023)
- [Solicitud de Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/7f80cd8f-d2cc-4914-93b8-dffb262cccee/SOLICITUD_DE_PRESTAMO_CEF+%281%29.pdf?MOD=AJPERES&CVID=oMm7vt4&attachment=false&id=1701178318400)
- [Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/23b67334-d53b-446b-bdd6-4fbe50a9a61b/6.Formulas%2By%2Bejemplos%2BCEF-update.pdf?MOD=AJPERES&CVID=osUjfHP&attachment=false&id=1680276892844)
- [Formato de instrucción de pago](https://www.viabcp.com/wcm/connect/685e8392-95bd-4cce-a1ac-ef168955ca43/7.Formato%2Bde%2BInstruccio%CC%81n%2Bde%2BPago%2B%281%29+%281%29.pdf?MOD=AJPERES&CVID=ojfCdsp&attachment=false&id=1669930211366)
- [Pasos para endoso de la póliza de seguro de desgravamen​](https://www.viabcp.com/wcm/connect/39d642a3-8a39-4442-8eed-bd043bb60a50/8.Pasos%2Bpara%2Bel%2Bendoso%2Bdel%2Bseguro%2Bde%2Bdesgravamen.pdf?MOD=AJPERES&CVID=ojfCrK.&attachment=false&id=1669930269870)
- [Seguro de desgravamen de Crédito Efectivo BCP](https://www.viabcp.com/wcm/connect/c40c0973-c6ae-4591-b5a8-9bbb01f86f07/Seguro+Desgravamen+Tradicional+%281%29.pdf?MOD=AJPERES&CVID=oMm70gD&attachment=false&id=1701178194512)
- [Seguro desgravamen con retorno Crédito Efectivo](https://www.viabcp.com/wcm/connect/d36a6c3f-5510-43bd-9988-bce1f6a45bec/Seguro+Desgravamen+Retorno+%281%29.pdf?MOD=AJPERES&CVID=oMm7ofd&attachment=false&id=1701178287829)

---

## Cancelación de préstamo


#### Cancelación de préstamo

Si quieres cancelar la totalidad de tu crédito, recuerda primero comunicarte con nuestra Banca por Teléfono para darte el monto exacto a pagar. En caso optes por ir a una Agencia, el asesor de ventanilla te podrá brindar esa información.
Hay muchos planes por cumplir y queremos que recuerde que siempre estaremos para acompañarlo. **¡Estamos contigo en tus planes!**

---

## Levantamiento de garantía


#### Los requisitos para el levantamiento de la garantía líquida son los siguientes:

**Para Levantamiento de garantía sin deuda:**
- Carta del cliente solicitando el levantamiento de la garantía.
**Para Levantamiento de garantía con deuda:**
- Carta del cliente solicitando el levantamiento de la garantía, condicionada a que dichos fondos sean destinados a la cancelación de la deuda.
- En caso de garantía de fondos mutuos: solicitud de rescate manual, carta modelo y Copia del DNI del Titular en la que el cliente (titular) autoriza expresamente el pago de la deuda con sus Fondos Mutuos en garantía de la siguiente forma: 
 
 “Hacemos referencia al rescate de nuestras cuotas del Fondo Mutuo BCP [SEÑALAR NOMBRE DEL FONDO], solicitado el día [INDICAR LA FECHA DE LA SOLICITUD DE RESCATE] por un importe de [INDICAR MONTO Y MONEDA], el mismo que se encuentra pendiente de cobro en ventanillas de su institución para instruirles con carácter irrevocable que dicho monto sea  puesto a disposición de [INDICAR EL AREA QUE SE HARA CARGO DE LA APLICACIÓN DE LOS FONDOS A LA DEUDA] a fin de ser aplicadas al pago de obligaciones pendientes con su Banco”.

---
