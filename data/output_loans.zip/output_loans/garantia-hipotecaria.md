# Crédito con Garantía Hipotecaria

**Te financiamos montos superiores al de un préstamo personal con el respaldo de tu garantía hipotecaria**

**Página:** https://www.viabcp.com/creditos/credito-efectivo/garantia-hipotecaria

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Ventajas


#### Beneficios

- Tenemos préstamos desde **S/ 87,500 (o $24,000)** hasta **S/ 600,000 (o $162,000).**
- Financiamientos con plazos de **hasta 15 años con hasta 14 cuotas al año.**
- Crédito de libre disponibilidad que te permite disponer de altos montos de dinero al dejar como garantía un inmueble.
- Podrás realizar pagos adelantados, libres de comisión, para acortar el plazo del préstamo o la cuota mensual.
- Ten en cuenta que el monto máximo del préstamo es de hasta 70% del valor del inmueble.
- El monto del préstamo, las cuotas y el plazo estarán sujetos a evaluación crediticia.

#### Más ventajas

- **Adquiere** el Crédito Efectivo con Garantía Hipotecaria **en cualquiera de nuestras Agencias BCP.**
- Solicita tu **estado de cuenta por correo electrónico** sin costo alguno para conocer el estado de tu crédito.
- Incluye un **Seguro de Desgravamen y Seguro de Inmueble** para brindarte una protección integral
- Seguro de Desgravamen: Asegura la cancelación de la deuda pendiente en caso de fallecimiento o invalidez total y permanente del titular del crédito (y/o de su cónyuge en caso de contratación de seguro de desgravamen mancomunado)
- Seguro de Inmueble: Protege contra daños materiales del inmueble por imprevistos (como incendios, sismos, rotura de tuberías, etc.) El seguro cubre sólo el valor de edificación del inmueble; es decir, no cubre el valor del terreno.  Actualmente el valor de la prima se calcula sobre el valor de tasación del inmueble (sin incluir terreno).

#### Consideraciones

- El cliente tiene el derecho de elegir entre: 
- La contratación del seguro ofrecido por el banco. 
- Un seguro contratado directamente por el cliente o través de la designación de un corredor de seguros, siempre que cumpla con las condiciones previamente informadas por el banco.
- Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Levantamiento de garantía hipotecaria
4. Pagos anticipados
- En caso desee realizar pagos anticipados o adelanto de cuotas, el cliente tiene derecho a realizarlo en cualquier agencia BCP, eligiendo la opción que más le convenga:
Pago anticipado: monto destinado al pago del capital del crédito. Se reduce intereses, comisiones y gastos al día de pagos:
- Reducción de plazo: reduce el número de cuotas del crédito manteniendo el importe de cuota original
- Reducción de cuotas: reduce el importe de las cuotas del crédito, manteniendo el plazo original del mismo
Adelanto de Cuotas: pago realizado para la aplicación de las cuotas posteriores a las exigibles en el periodo de facturación. No se reducen intereses, comisiones ni gastos

---

## Requisitos


#### Generales

- **Acreditar un ingreso mínimo debe ser de S/. 1500** o su equivalente al tipo de cambio en caso sea en moneda extranjera
- Tu plazo máximo para cancelar el crédito no debe sobrepasar los 75 años cumplidos
- **Buen comportamiento de pago en BCP y sistema financiero**
- No contar con multas de los últimos procesos electorales

#### Documentación

- Presentar tu documento de identidad en original y copia
- Si estás casado, tu cónyuge también deberá firmar la solicitud y presentar la copia de su documento de identidad
- También, tendrás que adjuntar el **recibo de teléfono fijo (copia)** de tu casa

#### Documentación del inmueble

- Certificado Registral Inmobiliario (CRI) del inmueble a financiar con vigencia no mayor a 30 días calendario.
- Copia simple de la Hoja de Resumen (HR), Predio Urbano (PU) del año en curso emitido por la municipalidad del inmueble que se dejará en garantía.
- Copia simple del Título de Propiedad del inmueble que se dejará como garantía.
- Documento de identidad vigente del propietario del inmueble.
- **Si eres trabajador dependiente (Renta 5ta categoría)**
Presentar la copia y el original de tus dos últimas boletas de pago y si eres vendedor o comisionista, de los últimos 4 meses de pago
- **En caso seas trabajador independiente (Renta 4ta categoría)**
Presentar la copia del Formulario de pago de Impuesto a la Renta de los últimos tres meses. También deberás adjuntar una copia de la última declaración jurada y la hoja de RUC.

---

## Tasas y Tarifas

- TEA para crédito en Soles: desde 8.9% hasta 20% [(Ver más)](https://www.viabcp.com/wcm/connect/b8e822d4-3788-42bf-9d6d-ef0222f4b9f2/Credito%2Bpersonal%2Btasas%2Bsoles%2B%28GAHI%29.pdf?MOD=AJPERES&CVID=pmGv8Ir&attachment=false&id=1742322899162)
- TEA para crédito en Dólares: desde 7.9% hasta 20% [(Ver más)](https://www.viabcp.com/wcm/connect/4a35898f-c900-471c-91e5-9bdfcc0a11be/Credito+personal+tasas+dolares+%28GAHI%29.pdf?MOD=AJPERES&CVID=oDs5fVM&attachment=false&id=1691615047417)

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante la Resolución N° 00805-2022 y N°00808-2022
[Solicitud de Crédito con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/f57d5af8-dc11-4af9-9bab-ac9536766274/SOLICITUD+DE+CREDITO+GAHI.pdf?MOD=AJPERES&CVID=orIVMP0&attachment=false&id=1679012102387)
[Contrato de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/b438d13a-a1ad-48c4-b4aa-5e6b327f2c6e/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+HIPOTECARIA.pdf?MOD=AJPERES&CVID=pzd-qO6&attachment=false&id=1755802705635)
[Contrato de Crédito Efectivo con Garantía Hipotecaria Existente](https://www.viabcp.com/wcm/connect/4aa68830-b271-4e41-a081-48ae6769e25f/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+HIPOTECARIA+EXISTENTE.pdf?MOD=AJPERES&CVID=pzd-kgO&attachment=false&id=1755802663833)
[Hoja Resumen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/8c5568f3-2ba4-41a9-8c2e-ac4f0f82b57b/Hoja%2BResumen%2BGAHI.pdf?MOD=AJPERES&CVID=pxSYAuE&attachment=false&id=1754342688389)
[Solicitud de Seguro Hipotecario](https://www.viabcp.com/wcm/connect/3bdcd53c-9650-4cc0-9c2c-c761b2335dc5/Solicitud+de+seguro+de+bien+inmueble+desde+29nov2023+%28003%29.pdf?MOD=AJPERES&CVID=oMwZPRk&attachment=false&id=1679060479452)
[Declaración de Salud](https://www.viabcp.com/wcm/connect/31a3d8e5-a56e-430d-83b2-9da0e50ae6fe/Declaracio%CC%81n+de+Salud.pdf?MOD=AJPERES&CVID=nh6qVVO&attachment=true&id=1598911265808)
[Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/71526e4f-a609-4434-a1b9-4d1ec56aa657/F%C3%B3rmulas%2By%2Bejemplos%2B%28Hipotecario%2BTradicional%29.pdf?MOD=AJPERES&CVID=pdLNH2Q&attachment=false&id=1732747648660)
[Pasos para endoso de la póliza de seguro de desgravamen e inmueble](https://www.viabcp.com/wcm/connect/265a5726-84f5-4445-ae7d-7e5f8e56b3cd/Pasos+para+endoso+de+seguro+de+desgravamen+y+de+inmueble.pdf?MOD=AJPERES&CVID=orIWKV.&attachment=false&id=1679012367258)
[Calculadora](https://www.viabcp.com/wcm/connect/7d7a70dc-69b5-4aa5-9e96-0fd7e383b959/Calculadora+GAHI.xls?MOD=AJPERES&CVID=odsixl7&attachment=false&id=1663700703045)
[Listado de Notarias según colegio de Notarios de Lima](http://www.notarios.org.pe/#/home)
[Listado de Notarias según colegio de Notarios del Callao](https://www.notarioscallao.org.pe/)
[Cartilla de Notarias según colegio de Notarios Provincia](https://www.viabcp.com/wcm/connect/6fb9614a-bfad-4027-89a3-dd30f64c403f/Cartilla+Notarias_Provincias.pdf?MOD=AJPERES&CVID=nh6r-vl&attachment=true&id=1598911560780)
[Cartilla de Notarias - Staff BCP](https://www.viabcp.com/wcm/connect/c895ca6d-218c-4229-be63-f2742621b639/Cartilla+Notarias_Staff+BCP.pdf?MOD=AJPERES&CVID=nh6s9Lq&attachment=true&id=1598911644140)
[Seguro de desgravamen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/40b1e4f8-5c1f-4f9c-a0f6-38e1c381f405/Seguro_Desgravamen_Cr%C3%A9dito+Efectivo+con+Garant%C3%ADa+Hipotecaria.pdf?MOD=AJPERES&CVID=nH0tBpp&attachment=false&id=1626726618981)
[Seguro de inmueble de uso mixto](https://www.viabcp.com/wcm/connect/bff51ba8-fe83-4028-b4c3-acfa77b43094/Seguro+de+inmueble_Uso+Mixto+2021+-+Desgravamen_Nuevo_Precio_VF+26.07.2021.pdf?MOD=AJPERES&CVID=nWx9kMY&attachment=false&id=1643381083492)
[Seguro de inmueble de uso vivienda](https://www.viabcp.com/wcm/connect/00e8aad6-e5d9-49a7-8a4f-5f658d32eb9d/Seguro+de+inmueble_Uso+Vivienda_Todo+Riesgo_10_2021.pdf?MOD=AJPERES&CVID=nWx90hu&attachment=false&id=1643380999550)
[Seguro desgravamen con retorno Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/28595d4c-f568-4aab-a907-bbad7c56e938/Solicitud+de+Desgravamen+con+retorno+-+GAHI.pdf?MOD=AJPERES&CVID=oay9kp1&attachment=false&id=1660577728368)
[Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)

### Documentos Descargables

- [Solicitud de Crédito con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/f57d5af8-dc11-4af9-9bab-ac9536766274/SOLICITUD+DE+CREDITO+GAHI.pdf?MOD=AJPERES&CVID=orIVMP0&attachment=false&id=1679012102387)
- [Contrato de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/b438d13a-a1ad-48c4-b4aa-5e6b327f2c6e/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+HIPOTECARIA.pdf?MOD=AJPERES&CVID=pzd-qO6&attachment=false&id=1755802705635)
- [Contrato de Crédito Efectivo con Garantía Hipotecaria Existente](https://www.viabcp.com/wcm/connect/4aa68830-b271-4e41-a081-48ae6769e25f/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+HIPOTECARIA+EXISTENTE.pdf?MOD=AJPERES&CVID=pzd-kgO&attachment=false&id=1755802663833)
- [Hoja Resumen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/8c5568f3-2ba4-41a9-8c2e-ac4f0f82b57b/Hoja%2BResumen%2BGAHI.pdf?MOD=AJPERES&CVID=pxSYAuE&attachment=false&id=1754342688389)
- [Solicitud de Seguro Hipotecario](https://www.viabcp.com/wcm/connect/3bdcd53c-9650-4cc0-9c2c-c761b2335dc5/Solicitud+de+seguro+de+bien+inmueble+desde+29nov2023+%28003%29.pdf?MOD=AJPERES&CVID=oMwZPRk&attachment=false&id=1679060479452)
- [Declaración de Salud](https://www.viabcp.com/wcm/connect/31a3d8e5-a56e-430d-83b2-9da0e50ae6fe/Declaracio%CC%81n+de+Salud.pdf?MOD=AJPERES&CVID=nh6qVVO&attachment=true&id=1598911265808)
- [Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/71526e4f-a609-4434-a1b9-4d1ec56aa657/F%C3%B3rmulas%2By%2Bejemplos%2B%28Hipotecario%2BTradicional%29.pdf?MOD=AJPERES&CVID=pdLNH2Q&attachment=false&id=1732747648660)
- [Pasos para endoso de la póliza de seguro de desgravamen e inmueble](https://www.viabcp.com/wcm/connect/265a5726-84f5-4445-ae7d-7e5f8e56b3cd/Pasos+para+endoso+de+seguro+de+desgravamen+y+de+inmueble.pdf?MOD=AJPERES&CVID=orIWKV.&attachment=false&id=1679012367258)
- [Calculadora](https://www.viabcp.com/wcm/connect/7d7a70dc-69b5-4aa5-9e96-0fd7e383b959/Calculadora+GAHI.xls?MOD=AJPERES&CVID=odsixl7&attachment=false&id=1663700703045)
- [Cartilla de Notarias según colegio de Notarios Provincia](https://www.viabcp.com/wcm/connect/6fb9614a-bfad-4027-89a3-dd30f64c403f/Cartilla+Notarias_Provincias.pdf?MOD=AJPERES&CVID=nh6r-vl&attachment=true&id=1598911560780)
- [Cartilla de Notarias - Staff BCP](https://www.viabcp.com/wcm/connect/c895ca6d-218c-4229-be63-f2742621b639/Cartilla+Notarias_Staff+BCP.pdf?MOD=AJPERES&CVID=nh6s9Lq&attachment=true&id=1598911644140)
- [Seguro de desgravamen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/40b1e4f8-5c1f-4f9c-a0f6-38e1c381f405/Seguro_Desgravamen_Cr%C3%A9dito+Efectivo+con+Garant%C3%ADa+Hipotecaria.pdf?MOD=AJPERES&CVID=nH0tBpp&attachment=false&id=1626726618981)
- [Seguro de inmueble de uso mixto](https://www.viabcp.com/wcm/connect/bff51ba8-fe83-4028-b4c3-acfa77b43094/Seguro+de+inmueble_Uso+Mixto+2021+-+Desgravamen_Nuevo_Precio_VF+26.07.2021.pdf?MOD=AJPERES&CVID=nWx9kMY&attachment=false&id=1643381083492)
- [Seguro de inmueble de uso vivienda](https://www.viabcp.com/wcm/connect/00e8aad6-e5d9-49a7-8a4f-5f658d32eb9d/Seguro+de+inmueble_Uso+Vivienda_Todo+Riesgo_10_2021.pdf?MOD=AJPERES&CVID=nWx90hu&attachment=false&id=1643380999550)
- [Seguro desgravamen con retorno Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/28595d4c-f568-4aab-a907-bbad7c56e938/Solicitud+de+Desgravamen+con+retorno+-+GAHI.pdf?MOD=AJPERES&CVID=oay9kp1&attachment=false&id=1660577728368)
- [Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)

---

## Cancelar préstamo


#### Estimado cliente:

- Le informamos que, si realizó el pago total de su Crédito con Garantía Hipotecaria y no presenta deuda, puede **recoger la Minuta de Levantamiento de Hipoteca** , en un plazo no mayor a siete (7) días hábiles, en cualquier Agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado.
- En caso aún mantengas obligaciones directas o indirectas con el banco podrás solicitar una minuta condicionada al pago de acuerdo a evaluación para cada caso en cualquier agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado.
- Hay muchos planes por cumplir y queremos que recuerde que siempre estaremos para acompañarlo.
**¡Estamos contigo en tus planes!**

---
