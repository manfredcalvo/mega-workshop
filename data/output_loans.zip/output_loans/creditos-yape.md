# Créditos Yape

**¡Te prestamos al toque y lo puedes pagar en cuotas!**

**Página:** https://www.viabcp.com/canales/yape/creditos-yape

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Es rápido y online:** Lo haces en simples pasos solo desde tu app Yape.
- **Flexible y a tu medida:** Según tu evaluación, puedes pedir desde S/50 en un solo pago o hasta S/10 000 en varias cuotas.
- **Seguridad garantizada:** Sin letras pequeñas y con el respaldo de BCP.

---

## Cómo Obtenerlo

1. **Ingresa a “Créditos”** — Dentro del menú de Yape
2. **Haz clic en “Simula tu crédito”**
3. **Ingresa el monto que necesitas**
4. **Selecciona la fecha de pago** — Y el número de cuotas que deseas
5. **Revisa el resumen de tu crédito** — Y acepta los “Términos y condiciones”
6. **Ingresa el código de validación**
7. **¡Listo!** — Podrás visualizar el depósito en tu cuenta​

---

## Preguntas Frecuentes

**¿Qué necesito para solicitar un crédito?**
Los principales requisitos que debes cumplir para solicitar tu crédito en Yape: 
- Estar afiliado a Yape con tarjeta BCP o a Cuenta Yape con DNI 
- Tus datos de contacto como dirección y número de celular deben estar actualizados en BCP 
- Si te afiliaste con tu cuenta BCP, tenerla sin bloqueos 
- Presentar un buen historial crediticio Aún cumpliendo todos estos requisitos es posible que no tengas habilitada la opción de crédito, continúa yapeando para conocerte y darte uno muy pronto. 
 
 Recuerda que el horario para solicitar créditos en Yape es de lunes a domingo de 5am a 11:59pm

**¿Cómo pago el crédito que solicité por Yape?**
Si tienes un crédito Yape, no te preocupes por el pago, nosotros haremos el cobro el mismo día de la fecha de vencimiento que elegiste. Este cobro se realiza a tu cuenta asociada a Yape. 
 
 El cobro se hará incluso en estos casos: 
- Te roban o pierdes el celular 
- Eliminaste tu Yape 
- La tarjeta que registraste en Yape está bloqueada 
- Si no tienes saldo suficiente, habrá un cargo por día atrasado. Si tienes otra cuenta en el BCP, haremos el cobro de ella para evitar que pagues de más. Para pagos antes de la fecha elegida, dirígete a la sección de "Créditos" de tu app, selecciona "Yapear crédito" y sigue los pasos. Solo se recibirán pagos de 5 a.m. a 8:30 p.m. todos los días (incluyendo feriados).

**¿Qué hago si me aparece el mensaje “Por ahora no encontramos la campaña perfecta para ti” al solicitar uno?**
Este mensaje aparece después de haber evaluado tu perfil y validar que no cuentas con un crédito preaprobado. 
 
 Para ofrecerte un crédito es importante: 
- Estar al día en el pago de tus deudas de cualquier entidad financiera, tarjetas de crédito y pago de servicios. 
- Realizar más yapeos para conocerte mejor y ofrecerte un producto diseñado especialmente para ti. 
- Además, te recomendamos ver nuestro curso sobre Créditos Yape. Es rápido y al final podrás conseguir un certificado de experto ¡totalmente gratis! Para ver el curso, visita este enlace: [https://info.yape.com.pe/creditosyape](https://info.yape.com.pe/creditosyape)

**¿Quieres simular un Crédito Yape?**
Aunque los montos, plazos y tasas están sujetos a evaluación crediticia, tenemos calculadoras para que puedas estimar tus cuotas a pagar al obtener un Crédito Yape. 
- Si necesitas un préstamo rápido que puedas pagar en una sola cuota en un plazo de hasta 35 días, utiliza nuestro Simulador de créditos a una cuota, [aquí](https://www.viabcp.com/wcm/connect/fbd93a27-6686-43b9-b438-4c32db09cf99/2024_Julio_Simulador_Yape_Mono.xlsm?MOD=AJPERES&CVID=p3s4mk9&attachment=false&id=1721679169354&pcid=viabcp:canales-yape-creditos-yape:quieres-simular-un-credito-ya:masivo:preguntas-frecuentes-simulador%C2%A0de-creditos-a-una-cu) . 
- Si buscas un préstamo mayor que puedas pagar en hasta 24 cuotas, utiliza nuestro Simulador de créditos a varias cuotas, [aquí](https://www.viabcp.com/wcm/connect/2a4acead-5b93-43b9-b946-87a75a9cb289/2024_Julio_Simulador_Yape_Multi.xlsm?MOD=AJPERES&CVID=p3s4x0U&attachment=false&id=1721679364729&pcid=viabcp:canales-yape-creditos-yape:quieres-simular-un-credito-ya:masivo:preguntas-frecuentes-simulador%C2%A0de-creditos-a-varias) . Recuerda que, si haces el pago después de la fecha acordada, existirá un cobro por cada día transcurrido. 
 
 Cada préstamo que solicites está sujeto a una nueva evaluación de tu perfil. La tasa de interés podría variar entre solicitudes.
