# Catálogo de Préstamos y Créditos BCP

**Haz realidad tus planes con nuestros créditos personales**

Pide tu préstamo BCP — Hazlo en segundos desde la web.

**Página del catálogo:** [Ver todos los créditos](https://www.viabcp.com/creditos)

---

## Categorías de Créditos

### Préstamos Personales (Crédito Efectivo)

Préstamos de dinero en efectivo para lo que necesites, con o sin garantía.

| Producto | Monto | Plazo | Garantía | Más detalles |
|----------|-------|-------|----------|-------------|
| Préstamo Personal | Hasta S/ 350,000 | 3 a 72 meses | Sin garantía | [Ver detalles](https://www.viabcp.com/creditos/credito-efectivo/prestamo-personal-bcp) |
| Préstamo con Garantía Hipotecaria | S/ 87,500 a S/ 600,000 | Hasta 15 años | Inmueble | [Ver detalles](https://www.viabcp.com/creditos/credito-efectivo/garantia-hipotecaria) |
| Préstamo Hipotecario Compartido | Desde S/ 87,500 | 1 a 10 años | Inmueble (2 propietarios) | [Ver detalles](https://www.viabcp.com/creditos/credito-efectivo/garantia-hipotecaria-compartida) |
| Préstamo con Garantía Líquida | Según depósito | 6 a 60 meses | Depósito a plazo | [Ver detalles](https://www.viabcp.com/creditos/credito-efectivo/garantia-liquida) |

### Créditos Hipotecarios

Financiamiento para la compra de vivienda, terreno o remodelación.

| Producto | Financiamiento | Plazo | Característica | Más detalles |
|----------|---------------|-------|----------------|-------------|
| Hipotecario Tradicional | Hasta 90% | 4 a 25 años | Prepagos gratis ilimitados | [Ver detalles](https://www.viabcp.com/creditos/credito-hipotecario/tradicional) |
| Hipotecario MiVivienda | Hasta S/ 355,100 | — | Bonos hasta S/ 5,400 | [Ver detalles](https://www.viabcp.com/creditos/credito-hipotecario/nuevo-credito-mivivienda) |
| Hipotecario Ahorro Local | — | — | Ahorro desde 4 meses como sustento | [Ver detalles](https://www.viabcp.com/creditos/credito-hipotecario/ahorro-local-fondeo-bcp) |
| Hipotecario MiVivienda Alquileres | — | — | Sustenta ingresos con alquiler | [Ver detalles](https://www.viabcp.com/creditos/credito-hipotecario/nuevo-credito-mivivienda/ahorro-local) |
| Hipotecario Compartido | 90% | — | Evalúa ingresos en conjunto | [Ver detalles](https://www.viabcp.com/creditos/credito-hipotecario/hipotecario-compartido) |
| Proyectos Inmobiliarios | — | — | Tasas y beneficios especiales | [Ver detalles](https://www.proyectosinmobiliariosbcp.com/) |

**Simulador Hipotecario:** [Simula tu crédito](https://www.viabcp.com/creditos/credito-hipotecario/simulador-credito-hipotecario)

### Créditos Vehiculares

Financiamiento para la compra de autos nuevos, seminuevos y usados.

| Producto | Plazo | Característica | Más detalles |
|----------|-------|----------------|-------------|
| Vehicular Inteligente | 24-36 meses | Menores costos de mantenimiento, renueva cada 2-3 años | [Ver detalles](https://www.viabcp.com/creditos/credito-vehicular/compra-inteligente) |
| Crédito Vehicular | Hasta 6 años | Desde S/ 15,000, autos nuevos/seminuevos/usados | [Ver detalles](https://www.viabcp.com/creditos/credito-vehicular/tradicional) |
| Crédito Auto Usado | Hasta 60 meses | Compra a personas naturales, sin seguro vehicular | [Ver detalles](https://www.viabcp.com/creditos/credito-vehicular/vehicular-autousado) |
| ExpoAutos | — | Elige, simula y solicita tu próximo auto | [Ver detalles](https://www.viabcp.com/expo-autos-bcp) |

**Simulador Vehicular:** [Simula tu crédito](https://www.viabcp.com/creditos/credito-vehicular/simulador-vehicular/)

### Otros Créditos

| Producto | Descripción | Más detalles |
|----------|-------------|-------------|
| Adelanto de Sueldo | Dinero extra de S/ 50 a S/ 2,500, comisión fija sin intereses, débito automático del próximo sueldo | [Ver detalles](https://www.viabcp.com/creditos/otros-creditos/adelanto-de-sueldo) |
| Yape Créditos | Préstamos desde S/ 50 hasta S/ 10,000 desde la app Yape, desembolso en minutos | [Ver detalles](https://www.viabcp.com/canales/yape/creditos-yape) |
| Cuotéalo sin Tarjeta | Compra en +1,000 marcas online sin tarjeta de crédito, desde TEA 8.9% | [Ver detalles](https://www.viabcp.com/cuotealo) |
| Préstamo Tarjetero | Accede hasta el 95% de tu línea de crédito a tasa preferencial | [Ver detalles](https://www.viabcp.com/creditos/otros-creditos/prestamo-tarjetero) |
| Préstamo Tarjetero Digital | Tu línea de crédito a la mano, plazos de 6 a 60 meses | [Ver detalles](https://www.viabcp.com/prestamo-tarjetero-digital) |
| Crédito Estudiantil | Financia maestrías, MBAs y doctorados, hasta S/ 300,000, plazos hasta 144 meses | [Ver detalles](https://www.viabcp.com/creditos/otros-creditos/credito-de-estudio) |

---

## ¿Cómo elegir tu crédito?

- **Necesitas dinero rápido sin garantía:** Préstamo Personal BCP (hasta S/ 350,000, TEA desde 8.9%)
- **Quieres comprar vivienda:** Crédito Hipotecario Tradicional (hasta 90% de financiamiento, hasta 25 años)
- **Quieres comprar tu primer hogar con apoyo estatal:** Crédito MiVivienda (bonos hasta S/ 5,400)
- **Quieres comprar un auto:** Crédito Vehicular (nuevos, seminuevos o usados, hasta 6 años)
- **Necesitas un adelanto pequeño hasta fin de mes:** Adelanto de Sueldo (S/ 50-2,500, comisión fija)
- **Quieres comprar online en cuotas sin tarjeta:** Cuotéalo (TEA desde 8.9%, +1,000 marcas)
- **Necesitas financiar estudios de posgrado:** Crédito Estudiantil (hasta S/ 300,000, hasta 144 meses)
- **Tienes línea de crédito y necesitas efectivo:** Préstamo Tarjetero (hasta 95% de tu línea)
