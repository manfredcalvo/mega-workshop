# Créditos Hipotecarios

**A unos clics de tu hogar**

**Página:** https://www.viabcp.com/creditos/credito-hipotecario

---

## Productos

### Crédito Hipotecario


### Crédito Hipotecario


### Crédito Hipotecario MiVivienda


### Crédito Hipotecario MiVivienda


### Crédito Hipotecario Ahorro Local


### Crédito Hipotecario Ahorro Local


### Crédito Hipotecario MiVivienda Alquileres


### Crédito Hipotecario MiVivienda Alquileres


### Crédito Hipotecario Compartido


### Crédito Hipotecario Compartido


### Proyectos Inmobiliarios


### Proyectos Inmobiliarios


## Preguntas Frecuentes

**¿Qué puedo financiar con mi Crédito Hipotecario BCP?**
El Crédito Hipotecario BCP te permite financiar la compra de una vivienda construida, vivienda en proyecto, casa de campo, casa de playa o un terreno. También podrás hacer uso del crédito para ampliar o remodelar tu actual vivienda.

**¿En cuánto tiempo puedo pagar mi crédito hipotecario?**
El plazo máximo es de 25 años, pudiendo pagar cuotas dobles en julio y diciembre si así lo deseas.

**¿Qué monto puedo financiar con mi Crédito Hipotecario BCP?**
Puedes financiar desde S/ 32,000 (o USD 10,000) hasta el monto que tu capacidad de pago permita.
