# Crédito Vehicular Inteligente BCP

**Página:** https://www.viabcp.com/creditos/credito-vehicular/compra-inteligente

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Cuotas Bajas:** Hasta 45% más bajas que un Crédito Vehicular BCP Convencional
- **Flexibilidad:** Cuota inicial desde 0%
- **Plan 50-50:** Paga el 50% del auto hoy y el 50% restante en un año.

---

## Características

**Elige las condiciones que mejor te convengan**
- Plazo del Crédito: 2 años o 3 años
- Al finalizar el crédito podrás: Renovar tu auto por otro o mantener el auto actual.

#### Ventajas:

- Puedes adquirir la Compra Inteligente en principales concesionarios y nuestras Agencias BCP.
- Adquiere el auto con algún amigo, familiar o con quien desees con Crédito Vehicular Compartido.
- Tenemos **convenios con las principales marcas de vehículos** del país.
- La **tarjeta de propiedad sale a tu nombre desde el primer día.**
- Solicita tu estado de cuenta por correo electrónico, sin costo alguno, y, así, podrás conocer el estado de tu crédito.
- **Incluimos el Seguro de Desgravamen** , el cual cancela la deuda de inmediato en caso de muerte, así como un seguro contra riesgos durante todo el plazo de endeudamiento.
- Para los seguros asociados al crédito puedes elegir entre:
1. Contratar un seguro ofrecido por el BCP.
2. Contratar un seguro de otra compañía (elegido directamente o a través de un corredor de seguros), siempre que cumpla con las condiciones informadas por el banco.
- Podrás realizar **pagos adelantados** , reduciendo la última cuota de la Compra Inteligente BCP.
**¡Si eres Cuenta Sueldo con nosotros obtendrás mejores tasas!**

#### Requisitos:

- Es necesario que tengas un ingreso mensual bruto mínimo de **S/ 1,500.**
- Es obligatorio **afiliarse a un seguro vehicular** durante el plazo total del crédito.
- **Buen comportamiento de pago en el BCP y sistema financiero.**
- No contar con multas de los últimos procesos electorales.

#### ¿Cómo cancelarlo?

Estimado cliente, le informamos que, si realizó el pago total de su Crédito Vehicular y no presenta deuda, su Carta de Levantamiento de Garantía Vehicular estará disponible en un plazo no mayor a siete (7) días hábiles posteriores a la cancelación o pago total del crédito. Podrá acercarse a cualquiera de nuestras Agencias BCP a nivel nacional o comunicarse con su Funcionario de Negocios BCP asignado.

---

## Tasas y Tarifas

- La TEA para crédito en soles: desde 8.49% hasta 20.26%
- La TEA para crédito en dólares: desde 8.49% hasta 20.22%
Conoce más sobre tasas y tarifas [aquí](https://www.viabcp.com/tasasytarifas?rfid=footer:tasas-y-tarifas:link:2)

---

## Documentación


#### Aquí encontrarás el detalle de Contratos, Formularios y Hojas Resumen

[Beneficios, Riesgos y Condiciones para Créditos Vehiculares](https://www.viabcp.com/wcm/connect/6350c95b-3705-4703-89cf-0997aad864b3/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Vehiculares.pdf?MOD=AJPERES&CVID=ot.RJmw&attachment=false&id=1681478036983)
[Contrato de Crédito Vehicular y Preconstitución de Garantía Mobiliaria](https://www.viabcp.com/wcm/connect/323efcde-70b1-4933-8712-ee1576f73dae/Contrato%2BCredito%2BVehicular%2By%2BPre%2BConstitucio%CC%81n%2Bde%2BGarantia%2BMobiliaria.pdf?MOD=AJPERES&CVID=prgGrlM&attachment=false&id=1747257792745)
[Formatos para el endoso del seguro vehicular](https://www.viabcp.com/wcm/connect/f6108943-b821-4a6f-9ce8-96cfbf5bed8f/FORMATOS%2BPARA%2BENDOSAR%2BP%C3%93LIZA%2BVEHICULAR+%281%29.pdf?MOD=AJPERES&CVID=poQQ5hO&attachment=falsee&id=1744643559033)
[Requisitos para que el usuario pueda contratar un seguro directamente o a       través de un corredor de seguros](https://www.viabcp.com/wcm/connect/d85fe84c-ad04-4834-9240-bff454a399c3/Requisitos+para+que+el+usuario+pueda+contratar+un+seguro+directamente+o+a+trav%C3%A9s+de+un+corredor+de+seguros+24.pdf?MOD=AJPERES&CVID=oYopZO1&attachment=false&id=1714101615703)
[Conoce más sobre tu Compra Inteligente BCP](https://www.viabcp.com/wcm/connect/4564b08c-b444-460e-a9f1-2c642433a3c4/Compra+Inteligente+BCP+16.06.pdf?MOD=AJPERES&CVID=nhlJdW4&attachment=true&id=1599173735682)
[Fórmulas y Ejemplos de Crédito Vehicular BCP](https://www.viabcp.com/wcm/connect/b000d56c-86f2-4305-9536-6d6e0077c640/Conoce%2Bmas%2Bsobre%2Btu%2BCr%C3%A9dito%2BVehicular%2BBCP%2BActualizado.pdf?MOD=AJPERES&CVID=plJdoZL&attachment=false&id=1741294113194)
[Fórmulas y Ejemplos de Compra Inteligente BCP](https://www.viabcp.com/wcm/connect/3833c799-4db9-48b4-bd12-cf2e11ec2b98/Conoce%2Bmas%2Bsobre%2Btu%2BCr%C3%A9dito%2BVehicular%2BInteligente%2BBCP%2BActualizado.pdf?MOD=AJPERES&CVID=plJdw0w&attachment=false&id=1741294197177)
[Cotizador Seguro Vehicular BCP](https://www.viabcp.com/wcm/connect/7b722c7f-592f-4288-b5cd-2652e3c037fd/Cotizador+BANA.xls?MOD=AJPERES&CVID=nhlJJOZ&attachment=true&id=1599173842930)
[Certificado de Compra Inteligente BCP](https://www.viabcp.com/wcm/connect/e3cd6048-d4f1-434a-8aab-56bb250a93c0/Certificado+de+Compra+Inteligente+BCP.pdf?MOD=AJPERES&CVID=nhlK8U7&attachment=true&id=1599174165865)
[Hoja resumen Créditos Vehiculares](https://www.viabcp.com/wcm/connect/75ed1a14-0338-4e81-aa51-807650893d1b/HojaResumenYCronograma_21112024112914.pdf?MOD=AJPERES&CVID=pdkZh6a&attachment=false&id=1732304759594)
[Solicitud de Seguros Lima](https://www.viabcp.com/wcm/connect/ee5777f8-8d01-4fef-b4a7-135c5effa283/Solicitud+de+Seguros+Lima.doc?MOD=AJPERES&CVID=nhlKJMa&attachment=true&id=1599174245970)
[Solicitud de Seguros Provincia](https://www.viabcp.com/wcm/connect/8b27ff69-e899-4b48-a2af-87ab732a8cde/Solicitud+de+Seguros+Provincia.doc?MOD=AJPERES&CVID=nhlKSf4&attachment=true&id=1599174281421)
[Solicitud para Levantamiento de Garantía Mobiliaria Vehicular](https://www.viabcp.com/wcm/connect/deecbaba-e2f2-4287-ab33-bb9f284e43f8/Solicitud+para+Levantamiento+de+Garanti%CC%81a+Mobiliaria+Vehicular.pdf?MOD=AJPERES&CVID=nhlamSN&attachment=true&id=1599174322483)
[Calculadora](https://www.viabcp.com/wcm/connect/0ab98b1d-56c0-428c-8282-1e7eac8970e6/Compra+Inteligente.xls?MOD=AJPERES&CVID=prgHtVg&attachment=false&id=1747257884707)
[Formato de solicitud de crédito vehicular](https://www.viabcp.com/wcm/connect/b9cf1675-5f39-419b-8a29-acd07d0d3b6a/Formato+Solicitud+-+Contingencia.pdf?MOD=AJPERES&CVID=oiM6mxk&attachment=false&id=1669401766228)
[Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
[Formulario de Seguro Vehicular](https://www.viabcp.com/wcm/connect/db3a40d3-8e24-4f46-955a-7224a14433d1/Formulario+de+seguro+vehicular.xls?MOD=AJPERES&CVID=ouBuZsO&attachment=false&id=1682108643096)

### Documentos Descargables

- [Beneficios, Riesgos y Condiciones para Créditos Vehiculares](https://www.viabcp.com/wcm/connect/6350c95b-3705-4703-89cf-0997aad864b3/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Vehiculares.pdf?MOD=AJPERES&CVID=ot.RJmw&attachment=false&id=1681478036983)
- [Contrato de Crédito Vehicular y Preconstitución de Garantía Mobiliaria](https://www.viabcp.com/wcm/connect/323efcde-70b1-4933-8712-ee1576f73dae/Contrato%2BCredito%2BVehicular%2By%2BPre%2BConstitucio%CC%81n%2Bde%2BGarantia%2BMobiliaria.pdf?MOD=AJPERES&CVID=prgGrlM&attachment=false&id=1747257792745)
- [Formatos para el endoso del seguro vehicular](https://www.viabcp.com/wcm/connect/f6108943-b821-4a6f-9ce8-96cfbf5bed8f/FORMATOS%2BPARA%2BENDOSAR%2BP%C3%93LIZA%2BVEHICULAR+%281%29.pdf?MOD=AJPERES&CVID=poQQ5hO&attachment=falsee&id=1744643559033)
- [Requisitos para que el usuario pueda contratar un seguro directamente o a       través de un corredor de seguros](https://www.viabcp.com/wcm/connect/d85fe84c-ad04-4834-9240-bff454a399c3/Requisitos+para+que+el+usuario+pueda+contratar+un+seguro+directamente+o+a+trav%C3%A9s+de+un+corredor+de+seguros+24.pdf?MOD=AJPERES&CVID=oYopZO1&attachment=false&id=1714101615703)
- [Conoce más sobre tu Compra Inteligente BCP](https://www.viabcp.com/wcm/connect/4564b08c-b444-460e-a9f1-2c642433a3c4/Compra+Inteligente+BCP+16.06.pdf?MOD=AJPERES&CVID=nhlJdW4&attachment=true&id=1599173735682)
- [Fórmulas y Ejemplos de Crédito Vehicular BCP](https://www.viabcp.com/wcm/connect/b000d56c-86f2-4305-9536-6d6e0077c640/Conoce%2Bmas%2Bsobre%2Btu%2BCr%C3%A9dito%2BVehicular%2BBCP%2BActualizado.pdf?MOD=AJPERES&CVID=plJdoZL&attachment=false&id=1741294113194)
- [Fórmulas y Ejemplos de Compra Inteligente BCP](https://www.viabcp.com/wcm/connect/3833c799-4db9-48b4-bd12-cf2e11ec2b98/Conoce%2Bmas%2Bsobre%2Btu%2BCr%C3%A9dito%2BVehicular%2BInteligente%2BBCP%2BActualizado.pdf?MOD=AJPERES&CVID=plJdw0w&attachment=false&id=1741294197177)
- [Cotizador Seguro Vehicular BCP](https://www.viabcp.com/wcm/connect/7b722c7f-592f-4288-b5cd-2652e3c037fd/Cotizador+BANA.xls?MOD=AJPERES&CVID=nhlJJOZ&attachment=true&id=1599173842930)
- [Certificado de Compra Inteligente BCP](https://www.viabcp.com/wcm/connect/e3cd6048-d4f1-434a-8aab-56bb250a93c0/Certificado+de+Compra+Inteligente+BCP.pdf?MOD=AJPERES&CVID=nhlK8U7&attachment=true&id=1599174165865)
- [Hoja resumen Créditos Vehiculares](https://www.viabcp.com/wcm/connect/75ed1a14-0338-4e81-aa51-807650893d1b/HojaResumenYCronograma_21112024112914.pdf?MOD=AJPERES&CVID=pdkZh6a&attachment=false&id=1732304759594)
- [Solicitud de Seguros Lima](https://www.viabcp.com/wcm/connect/ee5777f8-8d01-4fef-b4a7-135c5effa283/Solicitud+de+Seguros+Lima.doc?MOD=AJPERES&CVID=nhlKJMa&attachment=true&id=1599174245970)
- [Solicitud de Seguros Provincia](https://www.viabcp.com/wcm/connect/8b27ff69-e899-4b48-a2af-87ab732a8cde/Solicitud+de+Seguros+Provincia.doc?MOD=AJPERES&CVID=nhlKSf4&attachment=true&id=1599174281421)
- [Solicitud para Levantamiento de Garantía Mobiliaria Vehicular](https://www.viabcp.com/wcm/connect/deecbaba-e2f2-4287-ab33-bb9f284e43f8/Solicitud+para+Levantamiento+de+Garanti%CC%81a+Mobiliaria+Vehicular.pdf?MOD=AJPERES&CVID=nhlamSN&attachment=true&id=1599174322483)
- [Calculadora](https://www.viabcp.com/wcm/connect/0ab98b1d-56c0-428c-8282-1e7eac8970e6/Compra+Inteligente.xls?MOD=AJPERES&CVID=prgHtVg&attachment=false&id=1747257884707)
- [Formato de solicitud de crédito vehicular](https://www.viabcp.com/wcm/connect/b9cf1675-5f39-419b-8a29-acd07d0d3b6a/Formato+Solicitud+-+Contingencia.pdf?MOD=AJPERES&CVID=oiM6mxk&attachment=false&id=1669401766228)
- [Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
- [Formulario de Seguro Vehicular](https://www.viabcp.com/wcm/connect/db3a40d3-8e24-4f46-955a-7224a14433d1/Formulario+de+seguro+vehicular.xls?MOD=AJPERES&CVID=ouBuZsO&attachment=false&id=1682108643096)

---

## Canales Disponibles


### Podrás solicitar tu Compra Inteligente BCP en los siguientes canales de atención

- Puedes iniciar el tramité de tu Crédito Vehicular dejando tus datos en el formulario.
- Toda la red de Agencias BCP a nivel nacional.
- Comunicándote directamente con tu Funcionario de Negocio Banca Exclusiva, ENALTA o Privada.
- Los módulos de Crédito de Vehicular en Expomotor Plaza Lima Norte y Mall del Sur; así como MotorPlaza Trujillo.
- Solicitándolo directamente en los concesionarios de tu preferencia.

---

## Preguntas Frecuentes

**¿Cuáles son las consideraciones para solicitar el Crédito?**
**Si eres trabajador dependiente con pago de haberes BCP (5ª. categoría): ​​​​​** 
- Te evaluamos solo con tu DNI o carnet de extranjería. **Si cuentas con tu pago de haberes en otras entidades (5ª. categoría):** 
- DNI o carnet extranjería 
- Tres últimas boletas de pago **Si eres trabajador independiente (4ª. categoría):** 
- DNI o carnet extranjería vigente 
- Copia ficha RUC 
- Tres últimas boletas o recibos por honorarios 
- Estar laborando actualmente **Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:** 
- Información en el caso de fallecimiento del titular de la cuenta 
- Solicitudes de resolución del contrato 
- Pagos anticipados

**¿Cómo puedo cancelar mi Préstamo Vehicular?**
Estimado cliente, le informamos que, si realizó el pago total de su Crédito Vehicular y no presenta deuda, su Carta de Levantamiento de Garantía Vehicular estará disponible en un plazo no mayor a siete (7) días hábiles posteriores a la cancelación o pago total del crédito. Podrá acercarse a cualquiera de nuestras Agencias BCP a nivel nacional o comunicarse con su Funcionario de Negocios BCP asignado.

**¿En qué consiste la compra inteligente?**
El Crédito Vehicular Compra Inteligente es una facilidad que brinda el banco con la finalidad de acceder a un financiamiento con cuotas 45% más bajas que un crédito convencional y con la posibilidad de renovar tu auto cada 2 o 3 años, calzando así con la vida útil del vehículo. Además, puedes [cotizar un seguro vehicular](https://www.viabcp.com/seguros/vehicular/seguro-vehicular) para proteger tu inversión desde el primer día.

**¿Qué opciones tengo cuando termino de pagar las cuotas del crédito compra inteligente?**
1. **Mantener:** Puedes elegir Mantener en caso desees quedarte con el auto. Tu cuota balloon la transformamos en un nuevo crédito. Se deberá considerar que el crédito creado sobre la cuota balloon tendrá una TEA correspondiente al tarifario vigente del momento de la creación de dicho crédito. 
2. **Renovar:** Puedes elegir Renovar en caso desees cambiar de auto. Deberás vender el auto actual y con el monto del auto vendido, se realiza el pago de la cuota Balloon. A partir de ahí, se realiza la creación de la siguiente compra inteligente para el siguiente auto. Para estos casos, la tasa de la nueva compra inteligente se vuelve a negociar según la nueva marca y modelo.
