# Préstamo Personal BCP

**Simula tu crédito y solicítalo 100% online**

**Página:** https://www.viabcp.com/creditos/credito-efectivo/prestamo-personal-bcp

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Obtenlo en pocos pasos:** Solicítalo desde la App Banca Móvil BCP en la sección "Para ti" o a través de la web y recíbelo al instante.
- **No te pedimos garantía:** Pide tu préstamo personal hasta S/ 350,000 sin garantías.
- **Plazos Flexibles:** Solicita un préstamo en línea con cuotas desde 3 hasta 72 meses.

---

## Características


#### Ventajas

- Puedes adquirir el [préstamo efectivo](https://www.viabcp.com/creditos/credito-efectivo) a través de la app Banca Móvil BCP en la sección "Para ti" o a través de la web en [https://www.dineroalinstante.viabcp.com/](https://www.dineroalinstante.viabcp.com/)
- También los puedes en cualquiera de nuestras Agencias BCP y/o comunicándote directamente con tu funcionario BCP.
- Podrás realizar **pagos adelantados, libres de comisión** , para acortar el plazo del préstamo o la cuota mensual. Te enviamos tu estado de cuenta mensualmente a través del correo.
- Puedes pagar con **cargo automático** y la cuota se debitará automáticamente de la cuenta que selecciones. O puedes **pagar tu cuota manualmente** desde Banca Móvil, Banca por Internet o en nuestra red de Agencias a nivel nacional.
- **La cuota incluye el Seguro de Desgravamen** , seguro opcional de préstamos, que cancela la deuda pendiente en caso de fallecimiento o invalidez permanente del titular del préstamo.
- También podrás afiliarte al **Seguro de Protección Financiera** para cubrir las cuotas de tu préstamo personal en caso de desempleo o incapacidad.

#### Si eres Cuenta Sueldo con nosotros ¡obtendrás mejores tasas!


#### Consideraciones

- El cliente tiene el derecho de elegir entre: 
- La contratación del seguro ofrecido por el banco. 
- Un seguro contratado directamente por el cliente o través de la designación de un corredor de seguros, siempre que cumpla con las condiciones previamente informadas por el banco. 
- No contratar un seguro, conforme a lo establecido en la norma vigente​.
- Se puede acercar a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:
1. Información en el caso de fallecimiento del titular de la cuenta.
2. Solicitudes de resolución del contrato.
3. Levantamiento de garantía líquida.
4. Pagos anticipados.
- Las solicitudes de resolución de contrato podrán realizarlas a través de los siguientes canales:
1. Todas las agencias a nivel nacional.
2. Banca por teléfono siempre y cuando no hayan fraccionado su cuenta.
3. Llenando un formulario por Via BCP [aquí](https://www.viabcp.com/cancelacionproductos?rfid=footer:span-datatranslatetrueca:link:15)
- En caso desee realizar pagos anticipados o adelanto de cuotas, el cliente tiene derecho a realizarlo en cualquier agencia BCP, eligiendo la opción que más le convenga: 
- **Pago anticipado** : monto destinado al pago del capital del crédito. Se reduce intereses, comisiones y gastos al día de pago. 
- **Reducción de plazo:** reduce el número de cuotas del crédito manteniendo el importe de cuota original. 
- **Reducción de cuotas:** reduce el importe de las cuotas del crédito, manteniendo el plazo original del mismo. 
- **Adelanto de Cuotas** : pago realizado para la aplicación de las cuotas posteriores a las exigibles en el periodo de facturación. No se reducen intereses, comisiones ni gastos.

#### Tasas y Tarifas

- TEA para crédito en soles: desde 8.9% hasta 87.5% [(Ver más)](https://www.viabcp.com/wcm/connect/2276dec7-d418-42e7-b3be-a442be87d15d/Credito+personal+tasas+soles+%282%29.pdf?MOD=AJPERES&CVID=pDf.4Fc&attachment=false&id=1760131547011)
- TEA para crédito en dólares: desde 7.9% hasta 67% [(Ver más)](https://www.viabcp.com/wcm/connect/fd028395-f1c6-4dc4-9d1a-01ba1b427b57/Credito+personal+tasas+dolares+%281%29.pdf?MOD=AJPERES&CVID=pDf.bRx&attachment=false&id=1760131603320)

---

## ¿Qué es el Débito Automático?


#### ¿Qué es el Débito Automático?

Es el servicio que te ayuda a realizar tus pagos de forma mensual y automáticamente. Solo debes tener el monto de tu cuota al menos 1 día útil antes de la fecha de cobro y ¡listo!. Afiliarte es totalmente gratis y podrás hacerlo a través de la Banca por teléfono al (01) 3119898.
- Olvídate de ir al banco o agencias a realizar tus pagos.
- Disfrutas más de tu tiempo.
- Te ayuda a mantener un buen historial crediticio.

#### Ten en cuenta

- En caso el día de cobro sea fin de semana o feriado, este se realizará al siguiente día útil.
- El cobro se realizará a lo largo del día de la fecha de vencimiento. No te preocupes, mientras el dinero esté en tu cuenta, nosotros nos encargamos del cobro.

---

## Requisitos


#### Generales

- No presentar problemas de pago en el BCP ni en ninguna otra entidad del sistema financiero.

#### Si solicitas desde la app Banca Móvil BCP o desde la web

- No necesitas presentar documentación, solo tu Clave de Internet de 6 dígitos. Si aún no la tienes, conoce cómo generarla [aquí](https://www.viabcp.com/como-genero-mi-clave-6) .

#### Si solicitas el préstamo por Yape:​

- No necesitas presentar documentación, solo estar afiliado a Yape con tu tarjeta BCP, conoce cómo afiliarse [aquí.](https://www.yape.com.pe/preguntas-frecuentes/primeros-pasos/2--como-me-registro-a-yape-con-bcp)

#### Si solicitas el Préstamo en Agencias BCP:

- Tu documento de identidad en original y copia.
- Si estás casado, tu cónyuge también deberá firmar la solicitud y presentar la copia de su documento de identidad.
- Si pides el Préstamo Personal en nuestras agencias, debes acreditar ingresos por S/ 1,000
**Si eres trabajador dependiente (5ta categoría):**
- Copia de tus dos últimas boletas de pago.
- Copia del último recibo de teléfono fijo.
- Copia simple de tu documento de identidad.
**Si eres trabajador independiente (4ta categoría):**
- Copia simple de tu documento de identidad.
- Copia del último recibo de teléfono fijo.
- Copia de tus tres últimas declaraciones de impuestos (PDT) o copia de tu declaración jurada de Impuesto a la Renta.
- Copia de tu ficha RUC.

---

## Documentación


#### Contratos y Formularios

[Formato de instrucción de pago](https://www.viabcp.com/wcm/connect/685e8392-95bd-4cce-a1ac-ef168955ca43/7.Formato%2Bde%2BInstruccio%CC%81n%2Bde%2BPago%2B%281%29+%281%29.pdf?MOD=AJPERES&CVID=ojfCdsp&attachment=false&id=1669930211366)
[Pasos para endoso de la póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/39d642a3-8a39-4442-8eed-bd043bb60a50/8.Pasos%2Bpara%2Bel%2Bendoso%2Bdel%2Bseguro%2Bde%2Bdesgravamen.pdf?MOD=AJPERES&CVID=ojfCrK.&attachment=false&id=1669930269870)
[Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)
[Contrato de Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/eddbd152-5756-40e1-8928-44a77805c8c3/Contrato+cr%C3%A9dito+personal+%28versi%C3%B3n+final%29+%282%29.pdf?MOD=AJPERES&CVID=pC.MYYj&attachment=false&id=1759860163681)
[Hoja Resumen Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/e163f70b-a5ed-44b9-b689-67e43d07bef2/Hoja%2BResumen.pdf?MOD=AJPERES&CVID=pxWWkb5&attachment=false&id=1754409596989)
[Solicitud de Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/7f80cd8f-d2cc-4914-93b8-dffb262cccee/SOLICITUD_DE_PRESTAMO_CEF+%281%29.pdf?MOD=AJPERES&CVID=oMm7vt4&attachment=false&id=1701178318400)
[Seguro de desgravamen de Crédito Efectivo BCP](https://www.viabcp.com/wcm/connect/c40c0973-c6ae-4591-b5a8-9bbb01f86f07/Seguro+Desgravamen+Tradicional+%281%29.pdf?MOD=AJPERES&CVID=oMm70gD&attachment=false&id=1701178194512)
[Seguro desgravamen con retorno Crédito Efectivo](https://www.viabcp.com/wcm/connect/d36a6c3f-5510-43bd-9988-bce1f6a45bec/Seguro+Desgravamen+Retorno+%281%29.pdf?MOD=AJPERES&CVID=oMm7ofd&attachment=false&id=1701178287829)

#### Información Adicional

[Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/4dea6bcd-f41d-4bc7-8dec-974e7be3ee6b/6.Formulas%2By%2Bejemplos%2BCEF-update.pdf?MOD=AJPERES&CVID=oWFYnd0&attachment=false&id=1712248273070)
[Calculadora](https://www.viabcp.com/wcm/connect/b47ae0f1-34bd-489a-ac40-2f760eb9f00b/Simulador_CEF_Cuotas_Dobles_060524.xls?MOD=AJPERES&CVID=o-y0hb8&attachment=false&id=1716410001642)

### Documentos Descargables

- [Formato de instrucción de pago](https://www.viabcp.com/wcm/connect/685e8392-95bd-4cce-a1ac-ef168955ca43/7.Formato%2Bde%2BInstruccio%CC%81n%2Bde%2BPago%2B%281%29+%281%29.pdf?MOD=AJPERES&CVID=ojfCdsp&attachment=false&id=1669930211366)
- [Pasos para endoso de la póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/39d642a3-8a39-4442-8eed-bd043bb60a50/8.Pasos%2Bpara%2Bel%2Bendoso%2Bdel%2Bseguro%2Bde%2Bdesgravamen.pdf?MOD=AJPERES&CVID=ojfCrK.&attachment=false&id=1669930269870)
- [Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)
- [Contrato de Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/eddbd152-5756-40e1-8928-44a77805c8c3/Contrato+cr%C3%A9dito+personal+%28versi%C3%B3n+final%29+%282%29.pdf?MOD=AJPERES&CVID=pC.MYYj&attachment=false&id=1759860163681)
- [Hoja Resumen Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/e163f70b-a5ed-44b9-b689-67e43d07bef2/Hoja%2BResumen.pdf?MOD=AJPERES&CVID=pxWWkb5&attachment=false&id=1754409596989)
- [Solicitud de Préstamo Personal BCP](https://www.viabcp.com/wcm/connect/7f80cd8f-d2cc-4914-93b8-dffb262cccee/SOLICITUD_DE_PRESTAMO_CEF+%281%29.pdf?MOD=AJPERES&CVID=oMm7vt4&attachment=false&id=1701178318400)
- [Seguro de desgravamen de Crédito Efectivo BCP](https://www.viabcp.com/wcm/connect/c40c0973-c6ae-4591-b5a8-9bbb01f86f07/Seguro+Desgravamen+Tradicional+%281%29.pdf?MOD=AJPERES&CVID=oMm70gD&attachment=false&id=1701178194512)
- [Seguro desgravamen con retorno Crédito Efectivo](https://www.viabcp.com/wcm/connect/d36a6c3f-5510-43bd-9988-bce1f6a45bec/Seguro+Desgravamen+Retorno+%281%29.pdf?MOD=AJPERES&CVID=oMm7ofd&attachment=false&id=1701178287829)
- [Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/4dea6bcd-f41d-4bc7-8dec-974e7be3ee6b/6.Formulas%2By%2Bejemplos%2BCEF-update.pdf?MOD=AJPERES&CVID=oWFYnd0&attachment=false&id=1712248273070)
- [Calculadora](https://www.viabcp.com/wcm/connect/b47ae0f1-34bd-489a-ac40-2f760eb9f00b/Simulador_CEF_Cuotas_Dobles_060524.xls?MOD=AJPERES&CVID=o-y0hb8&attachment=false&id=1716410001642)

---

## ¿Cómo obtener tu Préstamo online?


#### ¿Qué necesito para solicitar un préstamo online desde la app Banca Móvil BCP?

- Al ingresar a tu **app Banca Móvil BCP** ingresa a la **sección "Para ti"** y revisa si cuentas con una oferta de préstamo.

#### ¿Qué necesito para solicitar un préstamo online en la web Dinero al Instante?​

- Ingresando a [www.dineroalinstante.viabcp.com](http://www.dineroalinstante.viabcp.com/?_ga=2.245507588.1883945511.1716814393-1541110175.1715873630&_gac=1.138069252.1716841645.EAIaIQobChMI6t32vtWuhgMVAkJIAB3rIgvCEAAYASAAEgLlR_D_BwE) ,necesitarás una **tarjeta de débito, tener una clave de 6 dígitos y contar con una cuenta de ahorros, mancomunada o corriente en Soles asociada a la tarjeta.**
La solicitud se puede realizar de **Lunes a Domingo de 5am a 12am (medianoche).**

#### ¿Qué necesito para solicitar un préstamo por Yape??

- Al ingresar a Yape, al abrir el menú y seleccionar la opción Créditos podrás solicitar tu préstamo.

#### ¿Debo presentar o firmar algún documento?

- **No necesitas presentar ni firmar algún tipo de documento.**
De aprobarse el préstamo, se depositará en la cuenta que elijas al instante, sin salir de casa.

#### ¿Puedo personalizar las características de mi préstamo online?

- Dentro de la web **podrás elegir el monto, plazo y cuota** que más se ajuste a tus necesidades.
También podrás elegir el tipo de envío de estado de cuenta, la cuenta a la cual te haremos el desembolso y la cuenta de donde desees que se cobre la cuota mensual.

#### ¿Cuál es monto mínimo o máximo al que puedo acceder?

- El monto aprobado dependerá de la evaluación en línea, considerando un **máximo de S/ 350,000.**
El monto podría variar en el transcurso de los días, de no mantenerse las condiciones crediticias que motivaron la aprobación.

#### ¿En cuánto tiempo se realiza el abono del préstamo online?

- Al solicitarlo en la web, podrás obtener el préstamo **al instante** y en la **cuenta que elijas.**

---

## Cancelar préstamo

Si quieres cancelar la totalidad de tu crédito puedes hacerlo de la siguiente forma:
- **Banca por Teléfono:** Llama al **(01) 311 9898** para darte el monto exacto a pagar.
- **Agencia BCP** : Al ir a agencia contacta un asesor de ventanilla y te podrá brindar la información que requieras.

---

## Preguntas Frecuentes

**¿Cómo solicito un Préstamo BCP 100% online?**
Aprende a pedir tu préstamo de forma fácil, segura y sin papeleos. Solo ingresa, coloca el monto y la fecha de pago, y sigue los pasos. Pasos rápidos 
1. 1. Inicia sesión con tu número de Tarjeta de Débito y tu Clave de Internet (6 dígitos). 
2. 2. Ingresa y valida tus datos. 
3. 3. Elige las opciones de pago del préstamo. 
4. 4. Selecciona la cuenta donde te depositarán y la cuenta desde la que se cobrará mensualmente. 
5. 5. Confirma el préstamo. ¡Listo! El dinero se acreditará en tu cuenta.

**¿Quién puede solicitar un préstamo personal 100% online en el BCP?**
Pueden solicitarlo clientes del BCP que tengan Tarjeta de Débito activa y Clave de Internet. La aprobación depende de la evaluación crediticia online.

**¿Qué requisitos mínimos necesito para aplicar a un crédito personal BCP?**
Tener número de Tarjeta de Débito del BCP, ser un usuario activo de la banca por internet del BCO y cumplir con la evaluación crediticia (ingresos, historial y capacidad de pago).

**¿Cuánto tiempo tarda la aprobación y el desembolso de mi préstamo personal?**
Si la evaluación es exitosa, el desembolso es inmediato.

**¿Cuál es el monto y plazo máximo para solicitar mi préstamo personal?**
Los montos máximos según perfil crediticio y campaña vigente. Pero como máximo por banca por internet puede solicitar S/ 350,000 y el plazo máximo en cuotas es de 60 meses.

**¿Qué puedo hacer para aumentar mis posibilidades de aprobación de mi crédito personal bcp?**
Mantener buen historial crediticio, demostrar ingresos suficientes, reducir ratio de endeudamiento y tener cuentas activas en el banco. Simula montos y plazos realistas acorde a tus ingresos.
