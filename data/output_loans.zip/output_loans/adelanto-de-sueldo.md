# Adelanto de Sueldo

**Página:** https://www.viabcp.com/creditos/otros-creditos/adelanto-de-sueldo

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Al instante:** En 3 simples pasos desde el App Banca Móvil o Banca por Internet.
- **Adelanta lo que necesitas:** Desde S/ 50 hasta S/ 2,500, tu eliges el monto.
- **Comisión única:** Olvídate de los intereses y paga una comisión única por operación.
- **Sin complicaciones:** Se debita automáticamente de tu próxima remuneración. Olvídate de la fecha de pago.

---

## Cómo Obtenerlo

1. **Ingresa a la App Banca Móvil BCP** — Con tu Clave de Internet y seleccionaPara ti.
2. **Revisa tus Ofertas** — Y eligeAdelanto de Sueldo.
3. **Conoce sus beneficios** — Lee detenidamente y da clic enLo quiero.
4. **Verifica el monto a solicitar** — Configura tu adelanto según tus necesidades y dale aContinuar.
5. **Acepta los Términos y Condiciones** — Y presionaConfirmarpara empezar hacer realidad tus planes.

---

## Ventajas

- Obtenlo en tu cuenta al instante por nuestra Banca por Internet, App Banca Móvil BCP y por nuestros cajeros o agentes a nivel nacional.
- Pagas una comisión única por operación. ¡Sin intereses!
- Se debita automáticamente de tu próxima remuneración sin preocuparte por la fecha de pago.
- Podrás realizar el prepago parcial y total de tu Adelanto de Sueldo a través de las agencias BCP.

---

## Requisitos

- Tener una Cuenta Sueldo BCP (Cuenta de Ahorros donde recibes tu sueldo). No aplica para Cuenta Corriente ni Cuenta Maestra.
- Tener un ingreso mensual mínimo de S/. 400 o US$ 170.
- No registrar deudas vencidas en ninguna entidad del sistema financiero.
- Haber recibido al menos por dos meses tu sueldo en tu Cuenta Sueldo BCP (bajo el concepto de haberes de 5ª. Categoría).
- No aplica para depósitos de sueldo realizados mediante transferencias interbancarias.

---

## Documentación

**Contratos y formularios**
- [Cláusula adicional para Adelanto de Sueldo BCP](https://www.viabcp.com/wcm/connect/8caec952-7e35-40c2-8066-1a5c1579301e/1.%2BContrato_Condiciones_Generales_-_Junio_2023_%28CC%29.pdf?MOD=AJPERES&CVID=oIra670&attachment=false&id=1678373456965)
- [Hoja Resumen - Adelanto de Sueldo BCP](https://www.viabcp.com/wcm/connect/10dd05cb-aea7-4fe2-a983-255ea0e7c097/Hoja%2BResumen%2B%2BAdelanto%2Bde%2BSueldo%2BBCP%2B25%2B%281%29.pdf?MOD=AJPERES&CVID=pORAITr&attachment=false&id=1772572999916)
**Información Adicional**
- [Consideraciones, Fórmulas y Ejemplos – Adelanto de Sueldo BCP](https://www.viabcp.com/wcm/connect/3a7d5ede-de72-4fc1-ab38-e168321582f3/Consideraciones%2BFo%CC%81rmulas%2By%2BEjemplos%2B-%2BAdelanto%2Bde%2BSueldo%2BBCP+2025+%281%29.pdf?MOD=AJPERES&CVID=phgFNoV&attachment=false&id=1736523232738)
**Canales disponibles para atención**
- Para solicitudes de información en caso de fallecimiento del titular de cuenta: llama al 311 9898 o visítanos en nuestras Agencias
- Para solicitudes de resolución del contrato: llama al 311 9898 o visítanos en nuestras Agencias.
- Para presentación y atención de pagos anticipados parciales o anticipación de pago total (pago del total del monto de adelanto de sueldo), acércate a la agencia BCP más cercana.

### Documentos Descargables

- [Cláusula adicional para Adelanto de Sueldo BCP](https://www.viabcp.com/wcm/connect/8caec952-7e35-40c2-8066-1a5c1579301e/1.%2BContrato_Condiciones_Generales_-_Junio_2023_%28CC%29.pdf?MOD=AJPERES&CVID=oIra670&attachment=false&id=1678373456965)
- [Hoja Resumen - Adelanto de Sueldo BCP](https://www.viabcp.com/wcm/connect/10dd05cb-aea7-4fe2-a983-255ea0e7c097/Hoja%2BResumen%2B%2BAdelanto%2Bde%2BSueldo%2BBCP%2B25%2B%281%29.pdf?MOD=AJPERES&CVID=pORAITr&attachment=false&id=1772572999916)
- [Consideraciones, Fórmulas y Ejemplos – Adelanto de Sueldo BCP](https://www.viabcp.com/wcm/connect/3a7d5ede-de72-4fc1-ab38-e168321582f3/Consideraciones%2BFo%CC%81rmulas%2By%2BEjemplos%2B-%2BAdelanto%2Bde%2BSueldo%2BBCP+2025+%281%29.pdf?MOD=AJPERES&CVID=phgFNoV&attachment=false&id=1736523232738)

---

## Comisiones

Comisión fija de acuerdo al monto de Adelanto de Sueldo. Recuerda que puedes adelantar hasta S/2,500.
**Soles:**
| Si adelantas: | Pagas comisión de: |
| --- | --- |
| S/ 50 - S/ 500 | S/ 20 |
| S/ 501 - S/ 1,000 | S/ 35 |
| S/ 1,001 - S/ 1,500 | S/ 50 |
| S/ 1,501 - S/ 2,500 | S/ 65 |
**Dólares:**
| Si adelantas: | Pagas comisión de: |
| --- | --- |
| $50 - $150 | $5 |
| $151 - $300 | $10 |
| $301 - $500 | $15 |
| $501 - $508 | $20 |

---

## Preguntas Frecuentes

**¿Qué es un Adelanto de Sueldo?**
Es un préstamo de hasta S/ 2,500 para clientes con Cuenta Sueldo BCP, para cubrir una urgencia de dinero que puede surgir antes de que te depositen tu sueldo a fin de mes. ¿Alguien se enfermó en casa y necesitas pagar el doctor? ¿El concierto que tanto querías ir y aun no es fin de mes? La solución perfecta para una necesidad de liquidez inmediata.

**¿Cómo y cuándo se realiza el cobro de mi Adelanto de Sueldo?**
Se debita automáticamente de tu próxima remuneración. Olvídate de la fecha de pago.

**¿Puedo hacer el pago anticipado de mi adelanto de sueldo?**
Sí, en caso de hacer un prepago total o prepago parcial anticipado, podrás hacerlo por la agencia más cercana.

**¿Sólo lo puedo adelantar mi sueldo  online?**
No, también puedes obtener tu Adelanto de Sueldo por nuestros cajeros o agentes a nivel nacional.
