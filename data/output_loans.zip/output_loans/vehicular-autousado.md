# Crédito Vehicular Auto Usado BCP

**Página:** https://www.viabcp.com/creditos/credito-vehicular/vehicular-autousado

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Flexibilidad:** Compra autos a personas naturales
- **Más Opciones:** Autos con hasta 10 años de antigüedad
- **Menos Requisitos:** No necesitas seguro vehicular

---

## Características


#### Ventajas:

- Puedes solicitar tu Crédito Vehicular Auto Usado BCP en nuestra red de Agencias de Lima Metropolitana, Piura, Chiclayo, Trujillo, Huancayo y Arequipa.
- Podrás adquirir el auto de familiares o de cualquier persona.
- No es necesario presentar un seguro vehicular para solicitar el crédito.
- La tarjeta de propiedad sale a tu nombre desde el primer día.
- Solicita tu estado de cuenta por correo electrónico, sin costo alguno, y, así, podrás conocer el estado de tu crédito.
- Incluimos el Seguro de Desgravamen, el cual cancela la deuda de inmediato en caso de muerte, así como un seguro contra riesgos durante todo el plazo de endeudamiento.
- Para los seguros asociados al crédito puedes elegir entre:
1. Contratar un seguro ofrecido por el BCP. ( [Seguro Vehicular Precios](https://www.viabcp.com/seguros/vehicular/seguro-vehicula) )
2. Contratar un seguro de otra compañía (elegido directamente o a través de un corredor de seguros), siempre que cumpla con las condiciones informadas por el banco.
- Podrás realizar pagos adelantados, reduciendo la última cuota de la Compra Inteligente BCP.
**¡Si eres Cuenta Sueldo con nosotros obtendrás mejores tasas!**

#### Requisitos:

- Es necesario que tengas un ingreso mensual bruto mínimo de **S/ 1,500.**
- El auto no debe superar los 10 años de antigüedad.
- Se debe presentar el DNI/CE del vendedor del auto y la placa del vehículo que se desea comprar.
- El auto a financiar debe pasar el examen de placa correspondiente.
- Buen comportamiento de pago en el BCP y sistema financiero, tanto para el comprador como para el vendedor del auto.

---

## Tasas y Tarifas

- La TEA para crédito en soles: desde 8.0% hasta 17.2%
- La TEA para crédito en dólares: desde 8.0% hasta 17.2%
Conoce más sobre tasas y tarifas [aquí](https://www.viabcp.com/tasasytarifas?rfid=footer:tasas-y-tarifas:link:2)

---

## Documentaciones


### Aquí encontrarás el detalle de Contratos, formularios y Hojas Resumen

[Beneficios, Riesgos y Condiciones para Créditos Vehiculares](https://www.viabcp.com/wcm/connect/6350c95b-3705-4703-89cf-0997aad864b3/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Vehiculares.pdf?MOD=AJPERES&CVID=ot.RJmw&attachment=false&id=1681478036983)
[Contrato de Crédito Vehicular y PreConstitución de Garantía Mobiliaria](https://www.viabcp.com/wcm/connect/323efcde-70b1-4933-8712-ee1576f73dae/Contrato%2BCredito%2BVehicular%2By%2BPre%2BConstitucio%CC%81n%2Bde%2BGarantia%2BMobiliaria.pdf?MOD=AJPERES&CVID=prgGrlM&attachment=false&id=1747257792745)
[Formatos para el endoso del seguro vehicular](https://www.viabcp.com/wcm/connect/100934bf-4a1f-438e-8a9a-b134fe379c3c/FORMATOS+PARA+ENDOSAR+PO%CC%81LIZA+VEHICULAR.pdf?MOD=AJPERES&CVID=o4rWo0Q&attachment=false&id=1654030699743)
[Requisitos para que el usuario pueda contratar un seguro directamente o a través   de un corredor de seguros](https://www.viabcp.com/wcm/connect/ac82ae6c-225c-45e3-b1ea-b9087ff5343c/Requisitos+para+que+el+usuario+pueda+contratar+un+seguro+directamente+o+a+trav%C3%A9s+de+un+corredor+de+seguros.pdf?MOD=AJPERES&CVID=ot.VeVO&attachment=false&id=1681478627115)
[Contrato de Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/48a7d728-ce8c-4e0e-bdff-64da7c918d1c/Contrato%2Bde%2BSeguro%2Bde%2BDesgravamen+VF.pdf?MOD=AJPERES&CVID=oBWB4qo&attachment=true&id=1599165177462)
[Solicitud para Levantamiento de Garantía Mobiliaria Vehicular](https://www.viabcp.com/wcm/connect/ed02478a-b05c-4576-978e-b90f213e7449/Solicitud%2Bpara%2BLevantamiento%2Bde%2BGaranti%CC%81a%2BMobiliaria%2BVehicular+%283%29.pdf?MOD=AJPERES&CVID=omxXawT&attachment=false&id=1673458958080)
[Adenda a la Hoja Resumen de Créditos Vehiculares](https://www.viabcp.com/wcm/connect/c2a1bcea-b591-4245-8e0f-a616724120a7/Adenda+a+la+Hoja+Resumen+de+Cre%CC%81ditos+Vehiculares.pdf?MOD=AJPERES&CVID=nhlaCfE&attachment=true&id=1599165319085)
[Formato de Instrucción de Pago](https://www.viabcp.com/wcm/connect/d1d10276-8a07-47e8-8a7f-c771181534cf/Formato+de+Instruccio%CC%81n+de+Pago+%281%29.pdf?MOD=AJPERES&CVID=nhlaN.1&attachment=true&id=1599165351632)
[Hoja resumen Créditos Vehiculares](https://www.viabcp.com/wcm/connect/75ed1a14-0338-4e81-aa51-807650893d1b/HojaResumenYCronograma_21112024112914.pdf?MOD=AJPERES&CVID=pdkZh6a&attachment=false&id=1732304759594)
[Conoce más sobre tu Crédito Vehicular BCP](https://www.viabcp.com/wcm/connect/b9ed7b11-d9cf-4f38-ab21-71c988c5bb85/Conoce+mas+sobre+tu+Cr%C3%A9dito+Vehicular+BCP.pdf?MOD=AJPERES&CVID=pdlpPC2&attachment=false&id=1732304888547)
[Calculadora](https://www.viabcp.com/wcm/connect/a9b9d27f-d076-48cc-a06c-433aee319c2d/Cr%C3%A9dito+Vehicular+Auto+Usado+%281%29.xlsm?MOD=AJPERES&CVID=psdZYFW&attachment=false&id=1748376455933)
[Formato de solicitud de crédito vehicular](https://www.viabcp.com/wcm/connect/b9cf1675-5f39-419b-8a29-acd07d0d3b6a/Formato+Solicitud+-+Contingencia.pdf?MOD=AJPERES&CVID=oiM6mxk&attachment=false&id=1669401766228)
[Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
[Formulario de Seguro Vehicular](https://www.viabcp.com/wcm/connect/db3a40d3-8e24-4f46-955a-7224a14433d1/Formulario+de+seguro+vehicular.xls?MOD=AJPERES&CVID=ouBuZsO&attachment=false&id=1682108643096)

### Documentos Descargables

- [Beneficios, Riesgos y Condiciones para Créditos Vehiculares](https://www.viabcp.com/wcm/connect/6350c95b-3705-4703-89cf-0997aad864b3/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Vehiculares.pdf?MOD=AJPERES&CVID=ot.RJmw&attachment=false&id=1681478036983)
- [Contrato de Crédito Vehicular y PreConstitución de Garantía Mobiliaria](https://www.viabcp.com/wcm/connect/323efcde-70b1-4933-8712-ee1576f73dae/Contrato%2BCredito%2BVehicular%2By%2BPre%2BConstitucio%CC%81n%2Bde%2BGarantia%2BMobiliaria.pdf?MOD=AJPERES&CVID=prgGrlM&attachment=false&id=1747257792745)
- [Formatos para el endoso del seguro vehicular](https://www.viabcp.com/wcm/connect/100934bf-4a1f-438e-8a9a-b134fe379c3c/FORMATOS+PARA+ENDOSAR+PO%CC%81LIZA+VEHICULAR.pdf?MOD=AJPERES&CVID=o4rWo0Q&attachment=false&id=1654030699743)
- [Requisitos para que el usuario pueda contratar un seguro directamente o a través   de un corredor de seguros](https://www.viabcp.com/wcm/connect/ac82ae6c-225c-45e3-b1ea-b9087ff5343c/Requisitos+para+que+el+usuario+pueda+contratar+un+seguro+directamente+o+a+trav%C3%A9s+de+un+corredor+de+seguros.pdf?MOD=AJPERES&CVID=ot.VeVO&attachment=false&id=1681478627115)
- [Contrato de Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/48a7d728-ce8c-4e0e-bdff-64da7c918d1c/Contrato%2Bde%2BSeguro%2Bde%2BDesgravamen+VF.pdf?MOD=AJPERES&CVID=oBWB4qo&attachment=true&id=1599165177462)
- [Solicitud para Levantamiento de Garantía Mobiliaria Vehicular](https://www.viabcp.com/wcm/connect/ed02478a-b05c-4576-978e-b90f213e7449/Solicitud%2Bpara%2BLevantamiento%2Bde%2BGaranti%CC%81a%2BMobiliaria%2BVehicular+%283%29.pdf?MOD=AJPERES&CVID=omxXawT&attachment=false&id=1673458958080)
- [Adenda a la Hoja Resumen de Créditos Vehiculares](https://www.viabcp.com/wcm/connect/c2a1bcea-b591-4245-8e0f-a616724120a7/Adenda+a+la+Hoja+Resumen+de+Cre%CC%81ditos+Vehiculares.pdf?MOD=AJPERES&CVID=nhlaCfE&attachment=true&id=1599165319085)
- [Formato de Instrucción de Pago](https://www.viabcp.com/wcm/connect/d1d10276-8a07-47e8-8a7f-c771181534cf/Formato+de+Instruccio%CC%81n+de+Pago+%281%29.pdf?MOD=AJPERES&CVID=nhlaN.1&attachment=true&id=1599165351632)
- [Hoja resumen Créditos Vehiculares](https://www.viabcp.com/wcm/connect/75ed1a14-0338-4e81-aa51-807650893d1b/HojaResumenYCronograma_21112024112914.pdf?MOD=AJPERES&CVID=pdkZh6a&attachment=false&id=1732304759594)
- [Conoce más sobre tu Crédito Vehicular BCP](https://www.viabcp.com/wcm/connect/b9ed7b11-d9cf-4f38-ab21-71c988c5bb85/Conoce+mas+sobre+tu+Cr%C3%A9dito+Vehicular+BCP.pdf?MOD=AJPERES&CVID=pdlpPC2&attachment=false&id=1732304888547)
- [Calculadora](https://www.viabcp.com/wcm/connect/a9b9d27f-d076-48cc-a06c-433aee319c2d/Cr%C3%A9dito+Vehicular+Auto+Usado+%281%29.xlsm?MOD=AJPERES&CVID=psdZYFW&attachment=false&id=1748376455933)
- [Formato de solicitud de crédito vehicular](https://www.viabcp.com/wcm/connect/b9cf1675-5f39-419b-8a29-acd07d0d3b6a/Formato+Solicitud+-+Contingencia.pdf?MOD=AJPERES&CVID=oiM6mxk&attachment=false&id=1669401766228)
- [Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
- [Formulario de Seguro Vehicular](https://www.viabcp.com/wcm/connect/db3a40d3-8e24-4f46-955a-7224a14433d1/Formulario+de+seguro+vehicular.xls?MOD=AJPERES&CVID=ouBuZsO&attachment=false&id=1682108643096)

---

## Canales Disponibles


### Podrás solicitar tu Crédito Vehicular Auto Usado BCP en los siguientes canales de atención:

- Puedes iniciar el trámite de tu Crédito Vehicular dejando tus datos en el formulario.
- En nuestras Agencias de Lima Metropolitana, Piura, Chiclayo, Trujillo, Huancayo y Arequipa.
- Comunicándote directamente con tu Funcionario de Negocio Banca Exclusiva, ENALTA o Privada de las plazas antes mencionadas.
- Los módulos de Crédito Vehicular en Expomotor Plaza Lima Norte y Mall del Sur; así como MotorPlaza Trujillo.

---

## Preguntas Frecuentes

**¿Cuáles son las consideraciones para solicitar el Préstamo?**
**Si recibes tu sueldo en el BCP** 
- Solo necesitas una copia de tu documento de identidad **Si recibes tu sueldo fuera del BCP** Y eres trabajador dependiente: 
- Una copia de tu documento de identidad o carnet de extranjería 
- Tres últimas boletas de pago Y eres trabajador independiente: 
- Una copia de tu documento de identidad o carnet de extranjería 
- Copia de tu ficha RUC 
- Copia de tus tres últimas boletas o recibos por honorarios 
- Estar laborando actualmente **Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:** 
1. Información en el caso de fallecimiento del titular de la cuenta 
2. Solicitudes de resolución del contrato 
3. Pagos anticipados

**¿Cómo puedo cancelar mi Préstamo Vehicular?**
Estimado cliente, le informamos que, si realizó el pago total de su Crédito Vehicular y no presenta deuda, su Carta de Levantamiento de Garantía Vehicular estará disponible en un plazo no mayor a siete (7) días hábiles posteriores a la cancelación o pago total del crédito. Podrá acercarse a cualquiera de nuestras Agencias BCP a nivel nacional o comunicarse con su Funcionario de Negocios BCP asignado.

**¿Qué tipos de autos puedo financiar?**
Los autos deberán ser de uso particular (no comercial). Podrás financiar autos con una antigüedad de hasta 10 años.

**¿Dónde puedo solicitarlo?**
Podrás encontrarnos en las principales concesionarias de autos a nivel nacional o podrás solicitarlo en cualquier agencia BCP o directamente con tu funcionario BCP.
