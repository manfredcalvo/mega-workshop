# Crédito Hipotecario Ahorro Local

**Página:** https://www.viabcp.com/creditos/credito-hipotecario/ahorro-local-fondeo-bcp

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados


---

## Ventajas


#### Ventajas

- **Destina el 25% de tu AFP para la cuota inicial del Crédito Hipotecario BCP** . Los trámites de liberación de fondos y la gestión para la emisión del reporte de SUNARP no tienen costo.
- Al iniciar la solicitud de tu Crédito Hipotecario BCP podrás disponer de nuestro servicio de recojo de documentos para facilitarte la entrega y así evitar visitas extras a la agencia donde ingresaste tu solicitud hipotecaria
- Puedes elegir entre: 
- Contratar un seguro ofrecido por el BCP. 
- Contratar un seguro de otra compañía (elegido directamente o a través de un corredor de seguros), siempre que cumpla con las condiciones informadas por el banco.

#### Consideraciones

Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Pagos anticipados

---

## Requisitos


#### Requisito

- Tus ingresos mensuales deben ser mayores a S/ 1,500 o $400.

#### Documentación

- DNI o Carné de extranjería
- Si no recibes tu sueldo en el BCP debes presentar sustento de tus ingresos con boletas de pago, recibos por honorario, etc. dependiendo de la categoría de tu ingreso.

---

## Tasas y Tarifas

- La TEA máxima para crédito en soles 13.99%
- La TEA máxima para crédito en dólares 11.99%
Para mayor detalle sobre nuestras tasas [aquí](https://www.viabcp.com/tasasytarifas)

---

## Documentación


#### Aquí encontrarás el detalle de Contratos, formularios y Hojas Resumen

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 2571-2018
[Contrato de Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/2d5d5688-f7ee-4c44-8941-867273466bd2/Contrato+de+Prestamo+Hipotecario+Tradicional+Resoluci%C3%B3n+SBS+N+01039+-+2022+30.03.2022.pdf?MOD=AJPERES&CVID=o2LQjMI&attachment=false&id=1652217167614)
[Hoja Resumen Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/9e1e8e01-d510-4070-8b6e-284ccb87ed33/Hoja%2BResumen%2BCre%CC%81dito%2BHipotecario%2BTradicional%2BBCP%2B2023_.xls?MOD=AJPERES&CVID=ovX-D66&attachment=false&id=1683559779171)
[Solicitud de Seguro Hipotecario](https://www.viabcp.com/wcm/connect/3bdcd53c-9650-4cc0-9c2c-c761b2335dc5/Solicitud+de+seguro+de+bien+inmueble+desde+29nov2023+%28003%29.pdf?MOD=AJPERES&CVID=oMwZPRk&attachment=false&id=1679060479452)
[Solicitud de Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/8c7438c1-25ac-4ee1-8d0a-e5fcaeaea1d9/SolicitudCredito.pdf?MOD=AJPERES&CVID=oaiPxNB&attachment=false&id=1660320358987)
[Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso mixto)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
[Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso vivienda)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
[Solicitud de Seguro de Desgravamen con retorno](https://www.viabcp.com/wcm/connect/01ec1218-9fa2-457a-a03f-27bfc1305c11/Solicitud+Desgravamen+Hipotecario+Retorno+VF.pdf?MOD=AJPERES&CVID=ok7wsvn&attachment=false&id=1670868224520)
[Declaración de Salud](https://www.viabcp.com/wcm/connect/5fadc08c-e292-48eb-bd98-c872bcdc26fb/Declaracio%CC%81n+Salud.pdf?MOD=AJPERES&CVID=nhk.nEi&attachment=true&id=1599154833129)
[Fórmulas y Ejemplos explicativos](https://www.viabcp.com/wcm/connect/2a6af60a-6b6c-45bc-b869-c56054ca051f/Fo%CC%81rmulas+y+ejemplos+explicativos+%28Hipotecario+Tradicional%29.pdf?MOD=AJPERES&CVID=opMrdVa&attachment=false&id=1676923429099)
[Calculadora](https://www.viabcp.com/wcm/connect/7b4f111b-4202-4eda-ab83-de436bb31e44/Simulador+Tradicional+2023.xlsm?MOD=AJPERES&CVID=oq5clMu&attachment=false&id=1677271850420)
[Listado de notarias a nivel nacional](https://www.viabcp.com/wcm/connect/cf13f694-60ad-4350-bb49-d463b6525ac0/PDF_NOTARIAS_%2BPaginas%2BColegio%2Bde%2BNotario%2Ba%2BNivel%2BNacional_5.12.pdf?MOD=AJPERES&CVID=pI8.z.p&attachment=false&id=1765382831922)
[Pasos para el endoso del seguro de desgravamen y de inmueble](https://www.viabcp.com/wcm/connect/89a12477-dc00-4326-b5ba-89b555d95b86/Pasos+para+endoso+de+seguro+de+desgravamen+y+de+inmueble.pdf?MOD=AJPERES&CVID=nZLlOoz&attachment=false&id=1646840457809)

### Documentos Descargables

- [Contrato de Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/2d5d5688-f7ee-4c44-8941-867273466bd2/Contrato+de+Prestamo+Hipotecario+Tradicional+Resoluci%C3%B3n+SBS+N+01039+-+2022+30.03.2022.pdf?MOD=AJPERES&CVID=o2LQjMI&attachment=false&id=1652217167614)
- [Hoja Resumen Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/9e1e8e01-d510-4070-8b6e-284ccb87ed33/Hoja%2BResumen%2BCre%CC%81dito%2BHipotecario%2BTradicional%2BBCP%2B2023_.xls?MOD=AJPERES&CVID=ovX-D66&attachment=false&id=1683559779171)
- [Solicitud de Seguro Hipotecario](https://www.viabcp.com/wcm/connect/3bdcd53c-9650-4cc0-9c2c-c761b2335dc5/Solicitud+de+seguro+de+bien+inmueble+desde+29nov2023+%28003%29.pdf?MOD=AJPERES&CVID=oMwZPRk&attachment=false&id=1679060479452)
- [Solicitud de Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/8c7438c1-25ac-4ee1-8d0a-e5fcaeaea1d9/SolicitudCredito.pdf?MOD=AJPERES&CVID=oaiPxNB&attachment=false&id=1660320358987)
- [Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso mixto)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
- [Solicitud de Seguro de Desgravamen con retorno](https://www.viabcp.com/wcm/connect/01ec1218-9fa2-457a-a03f-27bfc1305c11/Solicitud+Desgravamen+Hipotecario+Retorno+VF.pdf?MOD=AJPERES&CVID=ok7wsvn&attachment=false&id=1670868224520)
- [Declaración de Salud](https://www.viabcp.com/wcm/connect/5fadc08c-e292-48eb-bd98-c872bcdc26fb/Declaracio%CC%81n+Salud.pdf?MOD=AJPERES&CVID=nhk.nEi&attachment=true&id=1599154833129)
- [Fórmulas y Ejemplos explicativos](https://www.viabcp.com/wcm/connect/2a6af60a-6b6c-45bc-b869-c56054ca051f/Fo%CC%81rmulas+y+ejemplos+explicativos+%28Hipotecario+Tradicional%29.pdf?MOD=AJPERES&CVID=opMrdVa&attachment=false&id=1676923429099)
- [Calculadora](https://www.viabcp.com/wcm/connect/7b4f111b-4202-4eda-ab83-de436bb31e44/Simulador+Tradicional+2023.xlsm?MOD=AJPERES&CVID=oq5clMu&attachment=false&id=1677271850420)
- [Listado de notarias a nivel nacional](https://www.viabcp.com/wcm/connect/cf13f694-60ad-4350-bb49-d463b6525ac0/PDF_NOTARIAS_%2BPaginas%2BColegio%2Bde%2BNotario%2Ba%2BNivel%2BNacional_5.12.pdf?MOD=AJPERES&CVID=pI8.z.p&attachment=false&id=1765382831922)
- [Pasos para el endoso del seguro de desgravamen y de inmueble](https://www.viabcp.com/wcm/connect/89a12477-dc00-4326-b5ba-89b555d95b86/Pasos+para+endoso+de+seguro+de+desgravamen+y+de+inmueble.pdf?MOD=AJPERES&CVID=nZLlOoz&attachment=false&id=1646840457809)

---

## Cancelar Préstamo

- Estimado cliente: Le informamos que, si realizó el pago total de su Crédito con Garantía Hipotecaria y no presenta deuda, puede **recoger La Minuta de Levantamiento de Hipoteca,** en un plazo no mayor a siete (7) días hábiles, en cualquier Agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado.
- Hay muchos planes por cumplir y queremos que recuerde que siempre estaremos para acompañarlo.
- En caso aún mantengas obligaciones directas o indirectas con el banco podrás solicitar una minuta condicionada al pago de acuerdo a evaluación para cada caso en cualquier agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado. ¡Estamos contigo en tus planes!

---

## Preguntas Frecuentes

**¿Qué puedo financiar con mi Crédito Hipotecario BCP Ahorro Local?**
Te permite financiar la compra de una vivienda en planos o construcción (bien futuro), así sea la primera o segunda vivienda que adquieras. Financiado por el BCP u otro banco.

**¿Qué monto puedo financiar con mi Crédito Hipotecario BCP Ahorro Local?**
Puedes financiar desde S/40,000 hasta s/550,000.

**¿Cuánto debe ser mi ingreso mensual para calificar al Crédito Hipotecario BCP Ahorro Local?**
El ingreso bruto mínimo es de S/ 1,500. Podrás demostrarlo a través de ingresos sustentados o no sustentados.

**¿Cómo funciona el plan de ahorros?**
El plan de ahorro te permite demostrar que percibes ingresos de forma constante a través de depósitos mensuales en una cuenta especial. Para ello, te evaluamos y definimos un plan de ahorro, al cumplirlo correctamente te entregamos una Carta de Aprobación para el financiamiento de tu inmueble.

**¿Qué sucede con el dinero que ahorré?**
Este dinero podrá utilizarse como inicial para tu Crédito Hipotecario, una vez terminado el ahorro se completa la inicial para el financiamiento de tu crédito, si hay un excedente se retira al final del desembolso.
