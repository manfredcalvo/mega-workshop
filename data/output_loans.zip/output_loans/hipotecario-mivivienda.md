# Crédito MiVivienda BCP

**Página:** https://www.viabcp.com/creditos/credito-hipotecario/nuevo-credito-mivivienda

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Sustenta tus ingresos ahorrando desde 4 meses.**
- **Bono por hogar sostenible de S/5,400.**
- **Financiamiento de hasta S/355,100**

---

## Características


#### Ventajas

- **Utiliza el 25% de tu AFP para la cuota inicial** de tu nuevo **Crédito Mivivienda BCP** . Nosotros nos encargamos de los trámites de liberación de tus fondos.
- Al iniciar la solicitud de Crédito Hipotecario BCP benefíciate con nuestro servicio de recojo de documentos para facilitarte la entrega de estos y así evitar visitas extra a la agencia donde ingresaste tu solicitud hipotecaria.
- Puedes elegir entre: 
- Contratar un seguro ofrecido por el BCP. 
- Contratar un seguro de otra compañía (elegido directamente o a través de un corredor de seguros), siempre que cumpla con las condiciones informadas por el banco.

#### Consideraciones

Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Pagos anticipados

---

## Requisitos


#### Requisitos Generales

- La vivienda a financiar no debe tener un precio mayor a los S/ 427,600.
- Debe ser la única vivienda registrada en SUNARP a tu nombre, la de tu cónyuge / conviviente o hijos menores de edad.
- Para acceder a los Bonos, no debes haber sido beneficiado anteriormente con recursos del Estado para la compra de viviendas (por ejemplo: Techo Propio, FONAVI, BANMAT, etc).

#### Documentación a Presentar

- Si no recibes tu sueldo en el BCP debes presentar tus boletas de pago o recibos por honorario.
- Presentar documentación del inmueble a financiar (Partidas registrales, HR-PU), no aplica para Proyectos BCP.

---

## Tasas y Tarifas

- La TEA máxima para crédito en soles 13.99%
Para mayor detalle sobre nuestras tasas en [soles aquí](https://www.viabcp.com/tasasytarifas)

---

## Documentación


#### Aquí encontrarás el detalle de Contratos, Formularios y Hojas Resumen

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 2747-2018
[Hoja Resumen Crédito hipotecario MiVivienda BCP](https://www.viabcp.com/wcm/connect/57c36cca-ff1f-4e23-93d5-76657c51c7b7/Hoja%2BResumen%2BCre%CC%81dito%2BHipotecario%2BMiVivivenda%2BBCP%2B2023_.xlsx?MOD=AJPERES&CVID=ovY0nA9&attachment=false&id=1683560291063)
[Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda](https://www.viabcp.com/wcm/connect/098bbe76-8ff5-4a74-b94b-45fe2793dbb2/Contrato+de+Pr%C3%A9stamo+Hipotecario+Nuevo+Cr%C3%A9dito+Mivivienda-Resoluci%C3%B3n+SBS+N+01047-2022-30.03.2022.pdf?MOD=AJPERES&CVID=o2LPiZN&attachment=false&id=1652216902779)
[Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda con PREMIO del Buen Pagador](https://www.viabcp.com/wcm/connect/a2c69e45-5339-4f71-bcb5-fb1d05b865b5/Contrato+de+Pr%C3%A9stamo+Hipotecario+Nuevo+Cr%C3%A9dito+Mivivienda+con+Premio+del+Buen+Pagador+Resoluci%C3%B3n+Sbs+N+00979-2022+25.03.2022.pdf?MOD=AJPERES&CVID=o2LP17q&attachment=false&id=1652216828923)
[Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda Más con BONO del Buen Pagador](https://www.viabcp.com/wcm/connect/dc9a3714-0ef7-4de6-b25a-01ad91462988/Contrato+de+Pr%C3%A9stamo+Hipotecario+Nuevo+Cr%C3%A9dito+MiVivienda+M%C3%A1s+con+BONO+del+Buen+Pagador-Resoluci%C3%B3n+SBS+N+00998-2022-28.03.2022.pdf?MOD=AJPERES&CVID=o2LOIXl&attachment=false&id=1652216749512)
[Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso mixto)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
[Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso vivienda)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
[Solicitud de Seguro de Desgravamen con retorno](https://www.viabcp.com/wcm/connect/01ec1218-9fa2-457a-a03f-27bfc1305c11/Solicitud+Desgravamen+Hipotecario+Retorno+VF.pdf?MOD=AJPERES&CVID=ok7wsvn&attachment=false&id=1670868224520)
[Fórmulas y Ejemplos explicativos](https://www.viabcp.com/wcm/connect/fec06d8c-dacc-4c70-81e8-627a7e25273a/F%C3%B3rmulas+y+ejemplos+explicativos+%28Hipotecario+Mi+Vivienda%29.pdf?MOD=AJPERES&CVID=ouB.7bL&attachment=false&id=1682117101040)
[Calculadora](https://www.viabcp.com/wcm/connect/415cf5d3-1662-4556-9609-8e578ccb12de/Simulador+Mivivienda+2023.xlsm?MOD=AJPERES&CVID=oqtZSR6&attachment=false&id=1677687484078)
[Pasos para el endoso del seguro de desgravamen y de inmueble](https://www.viabcp.com/wcm/connect/4a94662c-dce4-466a-a422-fa59990a8ae2/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+21.03.24+%28003%29.pdf?MOD=AJPERES&CVID=oVC8epJ&attachment=false&id=1711110476675)
[Solicitud de Crédito Hipotecario Mivivenda BCP](https://www.viabcp.com/wcm/connect/0d0003ed-49b3-4584-af1b-0d603cc7e12b/SolicitudCredito+%281%29.pdf?MOD=AJPERES&CVID=oiLNiuK&attachment=false&id=1669396244873)
[Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda con Fondeo BCP](https://www.viabcp.com/wcm/connect/fea9430a-557b-4db3-ae7f-95dfedd10358/VF+Contrato+de+Prestamo+Hipotecario+Tradicional+con+cl%C3%A1usula+adicional+de+mivivienda+con+fondeo+propio-+Revisada+con+SDP+y+Asesor%C3%ADa+Legal.pdf?MOD=AJPERES&CVID=ozz-WTA&attachment=false&id=1687452136961)

### Documentos Descargables

- [Hoja Resumen Crédito hipotecario MiVivienda BCP](https://www.viabcp.com/wcm/connect/57c36cca-ff1f-4e23-93d5-76657c51c7b7/Hoja%2BResumen%2BCre%CC%81dito%2BHipotecario%2BMiVivivenda%2BBCP%2B2023_.xlsx?MOD=AJPERES&CVID=ovY0nA9&attachment=false&id=1683560291063)
- [Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda](https://www.viabcp.com/wcm/connect/098bbe76-8ff5-4a74-b94b-45fe2793dbb2/Contrato+de+Pr%C3%A9stamo+Hipotecario+Nuevo+Cr%C3%A9dito+Mivivienda-Resoluci%C3%B3n+SBS+N+01047-2022-30.03.2022.pdf?MOD=AJPERES&CVID=o2LPiZN&attachment=false&id=1652216902779)
- [Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda con PREMIO del Buen Pagador](https://www.viabcp.com/wcm/connect/a2c69e45-5339-4f71-bcb5-fb1d05b865b5/Contrato+de+Pr%C3%A9stamo+Hipotecario+Nuevo+Cr%C3%A9dito+Mivivienda+con+Premio+del+Buen+Pagador+Resoluci%C3%B3n+Sbs+N+00979-2022+25.03.2022.pdf?MOD=AJPERES&CVID=o2LP17q&attachment=false&id=1652216828923)
- [Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda Más con BONO del Buen Pagador](https://www.viabcp.com/wcm/connect/dc9a3714-0ef7-4de6-b25a-01ad91462988/Contrato+de+Pr%C3%A9stamo+Hipotecario+Nuevo+Cr%C3%A9dito+MiVivienda+M%C3%A1s+con+BONO+del+Buen+Pagador-Resoluci%C3%B3n+SBS+N+00998-2022-28.03.2022.pdf?MOD=AJPERES&CVID=o2LOIXl&attachment=false&id=1652216749512)
- [Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso mixto)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
- [Solicitud de Seguro de Desgravamen con retorno](https://www.viabcp.com/wcm/connect/01ec1218-9fa2-457a-a03f-27bfc1305c11/Solicitud+Desgravamen+Hipotecario+Retorno+VF.pdf?MOD=AJPERES&CVID=ok7wsvn&attachment=false&id=1670868224520)
- [Fórmulas y Ejemplos explicativos](https://www.viabcp.com/wcm/connect/fec06d8c-dacc-4c70-81e8-627a7e25273a/F%C3%B3rmulas+y+ejemplos+explicativos+%28Hipotecario+Mi+Vivienda%29.pdf?MOD=AJPERES&CVID=ouB.7bL&attachment=false&id=1682117101040)
- [Calculadora](https://www.viabcp.com/wcm/connect/415cf5d3-1662-4556-9609-8e578ccb12de/Simulador+Mivivienda+2023.xlsm?MOD=AJPERES&CVID=oqtZSR6&attachment=false&id=1677687484078)
- [Pasos para el endoso del seguro de desgravamen y de inmueble](https://www.viabcp.com/wcm/connect/4a94662c-dce4-466a-a422-fa59990a8ae2/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+21.03.24+%28003%29.pdf?MOD=AJPERES&CVID=oVC8epJ&attachment=false&id=1711110476675)
- [Solicitud de Crédito Hipotecario Mivivenda BCP](https://www.viabcp.com/wcm/connect/0d0003ed-49b3-4584-af1b-0d603cc7e12b/SolicitudCredito+%281%29.pdf?MOD=AJPERES&CVID=oiLNiuK&attachment=false&id=1669396244873)
- [Contrato de Préstamo Hipotecario Nuevo Crédito Mivivienda con Fondeo BCP](https://www.viabcp.com/wcm/connect/fea9430a-557b-4db3-ae7f-95dfedd10358/VF+Contrato+de+Prestamo+Hipotecario+Tradicional+con+cl%C3%A1usula+adicional+de+mivivienda+con+fondeo+propio-+Revisada+con+SDP+y+Asesor%C3%ADa+Legal.pdf?MOD=AJPERES&CVID=ozz-WTA&attachment=false&id=1687452136961)

---

## Cancelar préstamo

- *Estimado cliente:* 
 *Le informamos que, si realizó el pago total de su Crédito con Garantía Hipotecaria y no presenta deuda, puede **recoger La Minuta de Levantamiento de Hipoteca,*** en un plazo no mayor a siete (7) días hábiles *, en cualquier Agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado.*
- En caso aún mantengas obligaciones directas o indirectas con el banco podrás solicitar una minuta condicionada al pago de acuerdo a evaluación para cada caso en cualquier agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado. 
 
 *Hay muchos planes por cumplir y queremos que recuerde que siempre estaremos para acompañarlo.* 
 *¡Estamos contigo en tus planes!*

---

## Preguntas Frecuentes

**¿Qué puedo financiar con mi Crédito Hipotecario MiVivienda BCP?**
Te permite financiar la compra de tu 1era vivienda, esta podrá ser una vivienda construida, vivienda en planos, vivienda en construcción con un crédito otorgado por el fondo MiVivienda a través del BCP.

**¿Qué monto puedo financiar con mi Crédito Hipotecario  MiVivienda BCP?**
Puedes financiarte desde S/ 32,000.00 (o USD 10,000) hasta s/319,590.00 (valor comercial máximo de la vivienda debe ser S/355,100).

**¿Cuánto debe ser mi ingreso mensual para calificar al Crédito Hipotecario MiVivienda BCP?**
El ingreso bruto mínimo es de S/ 1,500. Podrás sustentarlo a través de boletas de pago o recibos por honorarios.

**¿Cómo funciona el Crédito Hipotecario MiVivienda BCP?**
Para acceder a este tipo de crédito no debes tener otra vivienda a tu nombre, además de que el valor comercial de la vivienda debe ser menor a S/355,100. Asimismo, podrás acceder acceder al Bono de Buen Pagador y/o Bono de Buen Pagador Verde (reduciendo tu monto de financiamiento).
