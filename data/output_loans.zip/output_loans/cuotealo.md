# ¡Participa por un Ipad 11!

**Pagando con cuotéalo tus compras del regreso a clases**

**Página:** https://www.viabcp.com/cuotealo

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **¿No tienes tarjeta de crédito?:** Con Cuotéalo financia tus compras al instante con una súper tasa desde 8.9% y sin tarjeta de crédito.
- **Elige pagar en cuotas:** Disfruta comprar en cómodas cuotas en más de 1,000 tiendas online.
- **¡Retira un monto extra!:** Si tu crédito aprobado es mayor al monto de tu compra, podrás retirar el excedente directamente a tu cuenta BCP para lo que necesites.

---

## Cómo Obtenerlo

1. **Ingresa a cualquiera de las tiendas online afiliadas, y selecciona Cuotéalo al pagar tu compra.**
2. **Valida tu identidad con tu Tarjeta de Débito y tu clave de 6 dígitos.**
3. **Elige tu monto a financiar, fecha de pago y número de cuotas.**
4. **Revisa la información y acepta los términos y condiciones.**
5. **Ingresa tu clave token y confirma tu préstamo.**
6. **¡Listo! Si decidiste financiar un monto mayor a tu compra, el extra se depositará a tu cuenta BCP elegida.**

---

## Tasas y Tarifas


#### Tasas y Tarifas

- TCEA para crédito en Soles y Dólares desde 25% hasta 99.9%. Para mayor información [aquí](https://www.viabcp.com/tasasytarifas) .
- Si quieres conocer tu tasa personalizada ingresa al [Simulador Cuotéalo](https://www.cuotealo.viabcp.com/simulador?pcid=viabcp:cuotealo:cuotealo:masivo:banner-principal&_ga=2.158888314.157762308.1710112888-3999033.1698431005) .
*TCEA variable de acuerdo con las condiciones de compra. Para mayor detalle, ver el simulador en cada compra.
Rango referencial (25%-99.9%)

---

## Cancelar préstamo


#### Cancelar préstamo

- Si quieres cancelar la totalidad de tu crédito, recuerda que puedes hacerlo a través de tu Banca Móvil o en cualquiera de nuestras agencias a nivel nacional. Asimismo, para conocer el monto exacto de tu deuda puedes comunicarte con nuestra Banca por Teléfono (311-9898), preguntarlo en nuestras agencias o visualizarlo en tu Banca Móvil.
- Hay muchos planes por cumplir y queremos que recuerde que siempre estaremos para acompañarlo.
¡Estamos contigo en tus planes!

---

## Documentación


#### Contratos y Formularios

[Contrato Préstamo Personal](https://www.viabcp.com/wcm/connect/7cc6be90-f158-4b28-93a5-5609e62a226c/Contrato_de_pr%C3%A9stamo_personal.pdf?MOD=AJPERES&CVID=pb-0VyS&attachment=false&id=1730838562034)
[Endosos Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/a07f5760-83db-4620-9bda-3c1005b53e79/Endosos%2BSeguro%2Bde%2BDesgravamen.pdf?MOD=AJPERES&CVID=osUGYkh&attachment=false&id=1680282994344)
[Hoja Resumen](https://www.viabcp.com/wcm/connect/6405400b-c993-466a-9c63-1d95d59cc579/Hoja_Resumen.pdf?MOD=AJPERES&CVID=pb-0zlL&attachment=false&id=1730838510124)
[Seguro Desgravamen Tradicional](https://www.viabcp.com/wcm/connect/e495d8ce-2660-4803-83e2-70516eb48547/Seguro+Desgravamen+Tradicional.pdf?MOD=AJPERES&CVID=ojzc.Ev&attachment=false&id=1670259145613)
[Solicitud de Préstamo Personal](https://www.viabcp.com/wcm/connect/72003d72-1f17-4931-8414-59f27dcd4934/Solicitud+de+Prestamo+Personal.pdf?MOD=AJPERES&CVID=ojzcaEz&attachment=false&id=1670258928528)
[Solicitud Desgravamen con Retorno](https://www.viabcp.com/wcm/connect/8ede28d6-9d92-4ec0-b3e7-4c9d8b2726d3/Solicitud+Desgravamen+con+Retorno.pdf?MOD=AJPERES&CVID=ojzcHI5&attachment=false&id=1670259063890)

#### Información Adicional

[Ejemplos](https://www.viabcp.com/wcm/connect/d8c392ad-a3be-4ebd-a1ad-61c06bc694d7/Formulas_y_ejemplos.pdf?MOD=AJPERES&CVID=pb-0L33&attachment=false&id=1730838607354)
[Calculadora](https://www.cuotealo.viabcp.com/simulador?skip=true&pcid=viabcp:tarjetas-tarjetas-credito:tarjetas-credito:masivo:banner-principal&_ga=2.21221755.1711854469.1670018950-534208074.1669397627)

### Documentos Descargables

- [Contrato Préstamo Personal](https://www.viabcp.com/wcm/connect/7cc6be90-f158-4b28-93a5-5609e62a226c/Contrato_de_pr%C3%A9stamo_personal.pdf?MOD=AJPERES&CVID=pb-0VyS&attachment=false&id=1730838562034)
- [Endosos Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/a07f5760-83db-4620-9bda-3c1005b53e79/Endosos%2BSeguro%2Bde%2BDesgravamen.pdf?MOD=AJPERES&CVID=osUGYkh&attachment=false&id=1680282994344)
- [Hoja Resumen](https://www.viabcp.com/wcm/connect/6405400b-c993-466a-9c63-1d95d59cc579/Hoja_Resumen.pdf?MOD=AJPERES&CVID=pb-0zlL&attachment=false&id=1730838510124)
- [Seguro Desgravamen Tradicional](https://www.viabcp.com/wcm/connect/e495d8ce-2660-4803-83e2-70516eb48547/Seguro+Desgravamen+Tradicional.pdf?MOD=AJPERES&CVID=ojzc.Ev&attachment=false&id=1670259145613)
- [Solicitud de Préstamo Personal](https://www.viabcp.com/wcm/connect/72003d72-1f17-4931-8414-59f27dcd4934/Solicitud+de+Prestamo+Personal.pdf?MOD=AJPERES&CVID=ojzcaEz&attachment=false&id=1670258928528)
- [Solicitud Desgravamen con Retorno](https://www.viabcp.com/wcm/connect/8ede28d6-9d92-4ec0-b3e7-4c9d8b2726d3/Solicitud+Desgravamen+con+Retorno.pdf?MOD=AJPERES&CVID=ojzcHI5&attachment=false&id=1670259063890)
- [Ejemplos](https://www.viabcp.com/wcm/connect/d8c392ad-a3be-4ebd-a1ad-61c06bc694d7/Formulas_y_ejemplos.pdf?MOD=AJPERES&CVID=pb-0L33&attachment=false&id=1730838607354)

---

## Consultas y Reclamos


#### Consultas y Reclamos

Para la atención de sus consultas o reclamos comunicarse con nosotros a través de [[email protected]](https://www.viabcp.com/cdn-cgi/l/email-protection) .
Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Pagos anticipados
Las solicitudes de resolución de contrato podrán realizarlas a través de los siguientes canales:
- Todas las agencias a nivel nacional
- Banca por teléfono (01- 3119898)*
(*) El pago de la totalidad de la deuda se puede realizar a través de nuestra banca por teléfono o a través de cualquier oficina BCP a nivel nacional. Asimismo, debes contar con el total pendiente de pago en tu tarjeta de débito para realizar la cancelación. Sin embargo, si desea prepagar solo una parte de la deuda, solo podría realizarlo a través de una oficina del BCP.

---

## Transparencia


#### Transparencia

Todos nuestros clientes pueden elegir hacer pagos por encima de la cuota de su préstamo sin que se le apliquen comisiones, gastos ni penalidades; sin embargo, para realizarlos, el cliente debe estar al día en sus pagos. Los pagos antes mencionados pueden consistir en:
1. **Pago anticipado:** 
- Se aplica al capital del crédito reduciendo los intereses, comisiones y gastos al día del pago. 
- En caso el cliente realice pagos mayores a dos (02) cuotas, puede elegir entre (i) reducir el monto de las cuotas pero manteniendo el plazo original o (ii) reducir el plazo del crédito; es decir, reducir el número de cuotas, manteniendo el monto de las mismas. 
- Sin embargo, si el cliente no indica expresamente su elección, dentro de los quince (15) días desde que el cliente realizó el pago, se reducirá el número de cuotas. 
- La reducción de cuotas origina un nuevo cronograma de pagos, el cual puede ser solicitado al banco, debiendo ser entregado en un plazo no mayor a siete (7) días de realizada la solicitud.
2. **Adelanto de cuotas:** 
- Se aplica a las cuotas posteriores a la exigible en el periodo de facturación, sin que se reduzcan los intereses, comisiones y gastos. 
- Los pagos iguales o menores a dos (02) cuotas, son considerados adelanto de cuotas. Sin perjuicio de lo anterior, en cada oportunidad en la que el cliente realice un pago por encima de la cuota exigible en el periodo, éste podrá elegir si dicho pago se aplica como un pago anticipado o adelanto de cuotas.

---

## LATAM Pass


#### Acumulación de Millas LATAM Pass

- 1 milla por cada S/20 de consumo a través de Cuotéalo BCP.
*Promoción vigente del 01 de Diciembre del 2023 al 01 de Diciembre del 2024. Esta campaña es desarrollada por el Banco de Crédito del Perú (BCP). Promoción válida a nivel nacional para clientes que realicen su compra con Cuotéalo BCP en LATAM Airlines S.A. Sucursal del Perú. En caso el acreedor del premio cierre o desactive su Cuenta de Ahorros BCP Soles o Cuenta Corriente BCP Soles en virtud de la cual participó en la presente promoción previo a la fecha del abono del premio o, si por algún otro hecho imputable a este, no pueda realizarse el abono del premio, este perderá su derecho al mismo.
*Se considerará un tipo de cambio referencial que se ajuste al mercado.
*El BCP podrá, previa comunicación a los participantes, modificar alguno de los términos establecidos en el presente texto, únicamente cuando dicho cambio no afecte la naturaleza de la promoción. Para más información sobre la promoción y/o restricciones, llama a nuestra Banca por Teléfono al (01) 311-9898 o en [[email protected]](https://www.viabcp.com/cdn-cgi/l/email-protection)

#### Beneficios exclusivos

- Conoce más sobre tu tarjeta BCP LATAM Pass [aquí](https://latampass.latam.com/es_pe/acumula-millas/tarjeta-bcp-latam-pass) .
- La acumulación, canje, uso y demás condiciones aplicables a los beneficios otorgados por las tarjetas BCP LATAM Pass se rigen bajo el reglamento de LATAM Pass publicado [aquí](https://latampass.latam.com/es_pe/descubre-latam-pass/terminos-y-condiciones) .

---
