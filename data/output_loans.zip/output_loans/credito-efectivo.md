# Créditos Efectivos Rápidos

**En línea y al instante**

**Página:** https://www.viabcp.com/creditos/credito-efectivo

---

## Productos

### Préstamo Personal


### Préstamo Personal


### Préstamo con Garantía Hipotecaria


### Préstamo con Garantía Hipotecaria


### Préstamo Hipotecario Compartido


### Préstamo Hipotecario Compartido


### Préstamo con garantía líquida


### Préstamo con garantía líquida


## Preguntas Frecuentes

**¿Cómo sé si tengo un Préstamo Personal pre aprobado en BCP?**
1. Ingresa a nuestra web: [www.viabcp.com](https://www.viabcp.com) 
2. Busca "Mi Espacio BCP" y coloca tu DNI. 
3. Dale clic al botón "Descubrir" y ¡listo!

**¿Qué necesito para solicitar un préstamo online?**
Para solicitar tu préstamo online debes tener en cuenta lo siguiente: 
1. Necesitas tu DNI. 
2. Ingresa desde un dispositivo con cámara para iniciar sesión por reconocimiento facial. 
3. Recuerda que la solicitud se puede realizar de lunes a sábado entre las 8:00 a.m. y 8:00 p.m.

**¿Qué es un préstamo por convenio?**
Un préstamo por convenio es un préstamo donde las cuotas se pagan a través del descuento por planilla. Está dirigido a trabajadores de instituciones públicas y privadas que hayan firmado un convenio con BCP.

**¿Cuál es la fecha límite para participar por el 10 iPad 11 y cuántos premios hay?**
La fecha límite para desembolsar tu préstamo y entrar al sorteo es el **31 de marzo de 2026** . Existe un stock total de **10 iPad 11,** entregándose un máximo de un premio por cliente ganador. El sorteo se realizará el miércoles 15 de abril, asegurando transparencia en la elección de los 10 ganadores a nivel nacional.

**¿Cuánto tiempo tarda el desembolso del Préstamo Personal BCP tras la aprobación?**
El desembolso del Préstamo Personal BCP es **inmediato.** Una vez que tu solicitud es aprobada digitalmente a través de la App o la web, el dinero se deposita en tu cuenta en cuestión de **minutos.** Esto te permite disponer del capital al instante para tus metas personales y, si realizas la operación en febrero o marzo de 2026, asegurar tu participación en el sorteo del iPad 11 de 11”.

**¿Quiénes pueden acceder a la promoción del Préstamo Personal BCP y el iPad 11?**
Pueden participar todas las **personas naturales mayores de 18 años** que mantengan una oferta aprobada y realicen el desembolso de su préstamo por los canales digitales del BCP. Es fundamental que la operación se complete dentro de la vigencia (1 de febrero al 31 de marzo de 2026). No se requiere un registro en formularios externos, ya que el sistema vincula tu DNI directamente con el sorteo tras el desembolso exitoso.
