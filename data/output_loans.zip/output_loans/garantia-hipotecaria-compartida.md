# Crédito con Garantía Hipotecaria Compartida

**Obtén un crédito aún si compartes la propiedad de un inmueble sin estar casado**

**Página:** https://www.viabcp.com/creditos/credito-efectivo/garantia-hipotecaria-compartida

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Características


#### Beneficios

- Este producto considera el ingreso de los dos propietarios para que puedan conseguir un crédito de mayor volumen mediante un doble aval.
- Puedes solicitar desde S/ 87,500 con **plazos que van de 1 a 10 años.**
- Ten en cuenta que el total del préstamo va hasta el 70% del valor del inmueble.
- El inmueble que se deja como garantía debe ser 100% usado sólo como vivienda.
- Hasta 12 cuotas al año.

#### Más ventajas

- Adquirir el crédito en cualquiera de nuestras Agencias BCP y/o comunicándote directamente con tu Funcionario BCP
- Solicita tu estado de cuenta por correo electrónico sin costo alguno para conocer el estado de tu crédito.
- Si deseas, puedes afiliarte al nuestro Seguro protección financiera, el cual pagará puntualmente tus cuotas en caso de desempleo o incapacidad
- Incluye un Seguro de Desgravamen y Seguro de Inmueble para brindarte una protección integral 
- **Seguro de Desgravamen:** Asegura la cancelación de la deuda pendiente en caso de fallecimiento o invalidez total y permanente del titular del crédito (y/o de su cónyuge en caso de contratación de seguro de desgravamen mancomunado) 
- **Seguro de Inmueble:** Protege contra daños materiales del inmueble por imprevistos (como incendios, sismos, rotura de tuberías, etc.) El seguro cubre sólo el valor de edificación del inmueble; es decir, no cubre el valor del terreno.  Actualmente el valor de la prima se calcula sobre el valor de tasación del inmueble (sin incluir terreno).
- La Garantía Hipotecaria (GAHI) se agrega al valor que da el banco con el crédito hipotecario libre para darle a ambos clientes un crédito de libre disponibilidad

#### Consideraciones

- El cliente tiene el derecho de elegir entre: 
- La contratación del seguro ofrecido por el banco. 
- Un seguro contratado directamente por el cliente o través de la designación de un corredor de seguros, siempre que cumpla con las condiciones previamente informadas por el banco.
- Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Levantamiento de garantía hipotecaria
4. Pagos anticipados
- En caso desee realizar pagos anticipados o adelanto de cuotas, el cliente tiene derecho a realizarlo en cualquier agencia BCP, eligiendo la opción que más le convenga:
1. Pago anticipado: monto destinado al pago del capital del crédito. Se reduce intereses, comisiones y gastos al día de pago: 
- Reducción de plazo: reduce el número de cuotas del crédito manteniendo el importe de cuota original 
- Reducción de cuotas: reduce el importe de las cuotas del crédito, manteniendo el plazo original del mismo
2. Adelanto de Cuotas: pago realizado para la aplicación de las cuotas posteriores a las exigibles en el periodo de facturación. No se reducen intereses, comisiones ni gastos

---

## Requisitos


#### Generales

- Deben tener un **ingreso mínimo de S/ 1,500.**
- Antigüedad laboral de ambas personas mínima de 1 año.

#### Documentación

- Presentar ambos documentos de identidad en original y copia.
- También, tendrás que adjuntar el **recibo de teléfono fijo (copia)** de tu casa y la de tu pareja.
- Sustento de ingresos de cada una de las partes.
- Si eres trabajador dependiente (Renta 5ta categoría): presentar la copia y el original de las dos últimas boletas de pago y si eres vendedor o comisionista, de los últimos 4 meses de pago (aplica para cada una de las partes).
- **En caso seas trabajador independiente (Renta 4ta categoría):** presentar la copia del **Formulario de pago de Impuesto a la Renta** de los últimos tres meses. También deberás adjuntar una copia de la última **declaración jurada** y la hoja de **RUC** .
- **Documentación del inmueble:** 
- Certificado Registral Inmobiliario (CRI) del inmueble a financiar con vigencia no mayor a 30 días calendario. 
- Copia simple de la Hoja de Resumen (HR), Predio Urbano (PU) del año en curso emitido por la municipalidad del inmueble que se dejará en garantía (aplica para cada una de las partes).
- **Documentación del inmueble:** 
- Certificado Registral Inmobiliario (CRI) del inmueble a financiar con vigencia no mayor a 30 días calendario 
- Copia simple de la Hoja de Resumen (HR), Predio Urbano (PU) del año en curso emitido por la municipalidad del inmueble que se dejará en garantía. 
- Copia simple del **Título de Propiedad del inmueble** que se dejará como garantía. 
- Documento de identidad vigente de ambos  propietarios del inmueble.

---

## Tasas y Tarifas

- TEA para crédito en Soles: desde 8.9% hasta 20%. [(Ver más)](https://www.viabcp.com/wcm/connect/9885ce6a-83cb-4eda-833c-1635314ff44d/Credito%2Bpersonal%2Btasas%2Bsoles%2B%28GAHI%29+%281%29.pdf?MOD=AJPERES&CVID=pmGvRX.&attachment=false&id=1742323082214) 
 TEA para crédito en Dólares: desde 7.9% hasta 20%. [(Ver más)](https://www.viabcp.com/wcm/connect/4a35898f-c900-471c-91e5-9bdfcc0a11be/Credito+personal+tasas+dolares+%28GAHI%29.pdf?MOD=AJPERES&CVID=oDs5fVM&attachment=false&id=1691615047417)
[Ver más](https://www.viabcp.com/tasasytarifas)

---

## Documentación


#### Contratos, Formularios e Información Importante

[Solicitud de Crédito con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/e323c2d7-76a3-4fbc-81dd-b4ce09f17c00/1.PLANTILLA+SOLICITUD+DE+CREDITO+GAHI.pdf?MOD=AJPERES&CVID=ojjZRUQ&attachment=false&id=1670003515193)
[Calculadora](https://www.viabcp.com/wcm/connect/934c7d12-1922-4004-8476-a4c07ddb66fe/10.Calculadora%2BGAHI.xls?MOD=AJPERES&CVID=ojj-i-T&attachment=false&id=1670003634540)
[Seguro de protección financiera](https://www.viabcp.com/wcm/connect/aca9830b-f36c-4ea2-a925-a9db55f30771/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2+%281%29.pdf?MOD=AJPERES&CVID=ojj-OQO&attachment=false&id=1670003765067)
[Listado de Notarias según Colegio de Notarios](https://www.notarios.org.pe/#/home)
[Cartilla de Notarías – Staff BCP](https://www.viabcp.com/wcm/connect/bbfc669f-fbf4-4d57-a96e-708d4fb220b0/5.Cartilla%2BNotarias_Staff%2BBCP.pdf?MOD=AJPERES&CVID=ojk0bwu&attachment=false&id=1670003872357)
[Cartilla de Notarías – Ségún Colegio de Notarios](https://www.viabcp.com/wcm/connect/47638f65-043e-4a88-b6cd-8362fbb4b154/6.Cartilla%2BNotarias_Provincias+%281%29.pdf?MOD=AJPERES&CVID=ojj-sXc&attachment=false&id=1670003675119)
[Formato de instrucción de pago](https://www.viabcp.com/wcm/connect/a7f97393-7c1e-4b99-bbb3-f0e14bd628a4/7.Formato%2Bde%2BInstruccio%CC%81n%2Bde%2BPago%2B%281%29+%281%29+%281%29.pdf?MOD=AJPERES&CVID=ojjYh0J&attachment=false&id=1670003102733)
[Pasos para endoso de la póliza de seguro de desgravamen e inmueble](https://www.viabcp.com/wcm/connect/f3caf1b9-6cec-45d4-9689-501058f98ca2/8.Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+%281%29.pdf?MOD=AJPERES&CVID=ojj.2UE&attachment=false&id=1670003830741)
[Lo que debes conocer sobre tus Créditos y Tarjetas de Crédito](https://www.viabcp.com/wcm/connect/6f56834f-1a51-47fa-8e7a-a571c96840ca/Pdf+tarjetas.pdf?MOD=AJPERES&CVID=nh6sT11&attachment=true&id=1598912162735)
[Contrato de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/f7cd8af9-ba59-40ec-8f7f-7f5ee690153a/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+COMPARTIDO+HIPOTECARIA.pdf?MOD=AJPERES&CVID=pzd-vGn&attachment=false&id=1755802733228)
[Contrato de Crédito Efectivo con Garantía Hipotecaria Existente](https://www.viabcp.com/wcm/connect/b909a487-be30-4756-a4df-319d652163e7/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+HIPOTECARIA+COMPARTIDO+EXISTENTE.pdf?MOD=AJPERES&CVID=pzd-DTJ&attachment=false&id=1755802769770)
[Hoja Resumen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/b9dbfa2a-8cb8-4d19-92f5-da524e0d96ea/HOJA+RESUMEN+CREDITO+CON+GARANTIA+HIPOTECARIA+COMPARTIDO.pdf?MOD=AJPERES&CVID=pzd-JTx&attachment=false&id=1755802797374)
[Declaración de Salud](https://www.viabcp.com/wcm/connect/31a3d8e5-a56e-430d-83b2-9da0e50ae6fe/Declaracio%CC%81n+de+Salud.pdf?MOD=AJPERES&CVID=nh6qVVO&attachment=true&id=1598912727991)
[Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/96f3926a-d961-4aab-8a6a-2d550d9f6ffe/6.Formulas+y+ejemplos+CEF.pdf?MOD=AJPERES&CVID=ojfC1rP&attachment=false&id=1669930162205)
[Seguro de inmueble de uso mixto](https://www.viabcp.com/wcm/connect/bff51ba8-fe83-4028-b4c3-acfa77b43094/Seguro+de+inmueble_Uso+Mixto+2021+-+Desgravamen_Nuevo_Precio_VF+26.07.2021.pdf?MOD=AJPERES&CVID=nWx9kMY&attachment=false&id=1643381083492)
[Seguro de inmueble de uso vivienda](https://www.viabcp.com/wcm/connect/00e8aad6-e5d9-49a7-8a4f-5f658d32eb9d/Seguro+de+inmueble_Uso+Vivienda_Todo+Riesgo_10_2021.pdf?MOD=AJPERES&CVID=nWx90hu&attachment=false&id=1643380999550)
[Seguro desgravamen con retorno Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/28595d4c-f568-4aab-a907-bbad7c56e938/Solicitud+de+Desgravamen+con+retorno+-+GAHI.pdf?MOD=AJPERES&CVID=oay9kp1&attachment=false&id=1660577728368)
[Seguro desgravamen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/95106e79-15c6-43a0-b0fd-59eac007203d/Seguro+desgravamen+GAHI.pdf?MOD=AJPERES&CVID=odsi06Q&attachment=false&id=1663700566751)
[Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)

### Documentos Descargables

- [Solicitud de Crédito con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/e323c2d7-76a3-4fbc-81dd-b4ce09f17c00/1.PLANTILLA+SOLICITUD+DE+CREDITO+GAHI.pdf?MOD=AJPERES&CVID=ojjZRUQ&attachment=false&id=1670003515193)
- [Calculadora](https://www.viabcp.com/wcm/connect/934c7d12-1922-4004-8476-a4c07ddb66fe/10.Calculadora%2BGAHI.xls?MOD=AJPERES&CVID=ojj-i-T&attachment=false&id=1670003634540)
- [Seguro de protección financiera](https://www.viabcp.com/wcm/connect/aca9830b-f36c-4ea2-a925-a9db55f30771/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2+%281%29.pdf?MOD=AJPERES&CVID=ojj-OQO&attachment=false&id=1670003765067)
- [Cartilla de Notarías – Staff BCP](https://www.viabcp.com/wcm/connect/bbfc669f-fbf4-4d57-a96e-708d4fb220b0/5.Cartilla%2BNotarias_Staff%2BBCP.pdf?MOD=AJPERES&CVID=ojk0bwu&attachment=false&id=1670003872357)
- [Cartilla de Notarías – Ségún Colegio de Notarios](https://www.viabcp.com/wcm/connect/47638f65-043e-4a88-b6cd-8362fbb4b154/6.Cartilla%2BNotarias_Provincias+%281%29.pdf?MOD=AJPERES&CVID=ojj-sXc&attachment=false&id=1670003675119)
- [Formato de instrucción de pago](https://www.viabcp.com/wcm/connect/a7f97393-7c1e-4b99-bbb3-f0e14bd628a4/7.Formato%2Bde%2BInstruccio%CC%81n%2Bde%2BPago%2B%281%29+%281%29+%281%29.pdf?MOD=AJPERES&CVID=ojjYh0J&attachment=false&id=1670003102733)
- [Pasos para endoso de la póliza de seguro de desgravamen e inmueble](https://www.viabcp.com/wcm/connect/f3caf1b9-6cec-45d4-9689-501058f98ca2/8.Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+%281%29.pdf?MOD=AJPERES&CVID=ojj.2UE&attachment=false&id=1670003830741)
- [Lo que debes conocer sobre tus Créditos y Tarjetas de Crédito](https://www.viabcp.com/wcm/connect/6f56834f-1a51-47fa-8e7a-a571c96840ca/Pdf+tarjetas.pdf?MOD=AJPERES&CVID=nh6sT11&attachment=true&id=1598912162735)
- [Contrato de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/f7cd8af9-ba59-40ec-8f7f-7f5ee690153a/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+COMPARTIDO+HIPOTECARIA.pdf?MOD=AJPERES&CVID=pzd-vGn&attachment=false&id=1755802733228)
- [Contrato de Crédito Efectivo con Garantía Hipotecaria Existente](https://www.viabcp.com/wcm/connect/b909a487-be30-4756-a4df-319d652163e7/CONTRATO+DE+CREDITO+EFECTIVO+CON+GARANTIA+HIPOTECARIA+COMPARTIDO+EXISTENTE.pdf?MOD=AJPERES&CVID=pzd-DTJ&attachment=false&id=1755802769770)
- [Hoja Resumen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/b9dbfa2a-8cb8-4d19-92f5-da524e0d96ea/HOJA+RESUMEN+CREDITO+CON+GARANTIA+HIPOTECARIA+COMPARTIDO.pdf?MOD=AJPERES&CVID=pzd-JTx&attachment=false&id=1755802797374)
- [Declaración de Salud](https://www.viabcp.com/wcm/connect/31a3d8e5-a56e-430d-83b2-9da0e50ae6fe/Declaracio%CC%81n+de+Salud.pdf?MOD=AJPERES&CVID=nh6qVVO&attachment=true&id=1598912727991)
- [Fórmulas y ejemplos explicativos](https://www.viabcp.com/wcm/connect/96f3926a-d961-4aab-8a6a-2d550d9f6ffe/6.Formulas+y+ejemplos+CEF.pdf?MOD=AJPERES&CVID=ojfC1rP&attachment=false&id=1669930162205)
- [Seguro de inmueble de uso mixto](https://www.viabcp.com/wcm/connect/bff51ba8-fe83-4028-b4c3-acfa77b43094/Seguro+de+inmueble_Uso+Mixto+2021+-+Desgravamen_Nuevo_Precio_VF+26.07.2021.pdf?MOD=AJPERES&CVID=nWx9kMY&attachment=false&id=1643381083492)
- [Seguro de inmueble de uso vivienda](https://www.viabcp.com/wcm/connect/00e8aad6-e5d9-49a7-8a4f-5f658d32eb9d/Seguro+de+inmueble_Uso+Vivienda_Todo+Riesgo_10_2021.pdf?MOD=AJPERES&CVID=nWx90hu&attachment=false&id=1643380999550)
- [Seguro desgravamen con retorno Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/28595d4c-f568-4aab-a907-bbad7c56e938/Solicitud+de+Desgravamen+con+retorno+-+GAHI.pdf?MOD=AJPERES&CVID=oay9kp1&attachment=false&id=1660577728368)
- [Seguro desgravamen de Crédito Efectivo con Garantía Hipotecaria](https://www.viabcp.com/wcm/connect/95106e79-15c6-43a0-b0fd-59eac007203d/Seguro+desgravamen+GAHI.pdf?MOD=AJPERES&CVID=odsi06Q&attachment=false&id=1663700566751)
- [Seguro de Protección Financiera BCP](https://www.viabcp.com/wcm/connect/3e496277-a539-44a9-a33e-cfa4d6cbe1e4/11.Solicitud%2By%2BCertificado%2BSPF%2BEnciclopedia%2BV2.pdf?MOD=AJPERES&CVID=ojjzfeu&attachment=false&id=1669996542194)

---

## Cancelar préstamo


#### Estimado cliente:

Le informamos que, si realizó el pago total de su Crédito con Garantía Hipotecaria y no presenta deuda, puede **recoger la Minuta de Levantamiento de Hipoteca** , en un plazo no mayor a siete (7) días hábiles, en cualquier Agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado.
En caso aún mantengas obligaciones directas o indirectas con el banco podrás solicitar una minuta condicionada al pago de acuerdo a evaluación para cada caso en cualquier agencia BCP cerca de su domicilio o puede comunicarse con su Funcionario de Negocios BCP asignado.
Hay muchos planes por cumplir y queremos que recuerde que siempre estaremos para acompañarlo. 
 **¡Estamos contigo en tus planes!**

---
