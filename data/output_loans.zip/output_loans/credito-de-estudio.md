# Crédito educativo

**Página:** https://www.viabcp.com/creditos/otros-creditos/credito-de-estudio

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Financiamiento:** Hasta por el 100% del programa posgrado que escojas a nivel nacional o internacional.
- **Plazos Flexibles:** 12 cuotas al año hasta por 144 meses
- **Periodo de gracia:** De hasta 30 meses previa evaluación crediticia.

---

## Características


#### Beneficios

- El Crédito de Estudios **te financia hasta el 100%** del costo del posgrado, maestría o especializaciones en instituciones locales y extranjeras a tiempo parcial o completo.
- El plazo que te damos para cancelarlo es hasta **144 meses, con 12 cuotas al año** .
- Te prestamos hasta S/300,000, según la maestría que elijas y tu evaluación en el sistema financiero.
- Accede a **periodo de gracia de hasta 30 meses y gastos de manutención hasta $25,000** , sujeto a evaluación crediticia.
**¡Si eres Cuenta Sueldo con nosotros obtendrás mejores tasas!**

#### Más ventajas

- Con este crédito, podrás financiar todo tipo de posgrado, maestría (nacional e internacional) y programas de especialización profesional.
- Contamos con atención personalizada para asesorarte sobre la entidad educativa de tu interés y el proceso.

#### Consideraciones

**El cliente tiene el derecho de elegir entre:**
1. La contratación del seguro ofrecido por el banco.
2. Un seguro contratado directamente por el cliente o través de la designación de un corredor de seguros, siempre que cumpla con las condiciones previamente informadas por el banco.
**Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:**
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Pagos anticipados

---

## Requisitos


#### Generales

- Para este crédito necesitas tener ingresos individuales de S/. 1,500.
- Solicitar un financiamiento mínimo de 12 meses y contar con la carta de aceptación o proforma de costos de estudios que brinda la entidad educativa.
- Es indispensable no tener problema de pago en el BCP u otra entidad financiera.

#### Documentación

- No olvides que para todo trámite crediticio, siempre tendrás que presentar documento de identidad y el de tu cónyuge si eres casado(a).
- SI eres trabajador dependiente (5ª. categoría):
- Te evaluamos solo con tu DNI* o carnet de extranjería.
- SI cuentas con tu pago de haberes en otras entidades (5ª. categoría):
- DNI* o carnet de extranjería.
- Tres últimas boletas de pago.
- SI eres trabajador independiente (4ª. categoría):
- DNI* o carnet de extranjería vigente.
- Copia ficha RUC.
- Tres últimas boletas o recibo por honorarios.
*No contar con multas pendientes en RENIEC.

---

## Tasas y Tarifas


#### Tasas y tarifas

- TEA para crédito en soles: desde 10.5% hasta 23.5 %
- TEA para crédito en dólares: desde 9.5% hasta 18.7 %
Ver más [aquí](https://www.viabcp.com/tasasytarifas) .

---

## Documentación


#### Contrato del Seguro de Desgravamen, Contratos, Formularios e Información importante

[Beneficios, Riesgos y Condiciones para Crédito de Estudios](https://www.viabcp.com/wcm/connect/cb7691a5-9209-42d7-a4d8-4b816c4bb2d6/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Estudios.pdf?MOD=AJPERES&CVID=oyysot7&attachment=false&id=1681478406292)
[Contrato de Fianza Solidaria en favor del BCP](https://www.viabcp.com/wcm/connect/e81c30b9-373f-4333-876b-70c451baf276/Contrato+de+Fianza+Solidaria+a+favor+del+BCP+.pdf?MOD=AJPERES&CVID=nhplGnv&attachment=true&id=1599237838165)
[Solicitud de Créditos Personales](https://www.viabcp.com/wcm/connect/9171287f-dadf-4b77-9ef5-add0a36efd53/Hoja+de+solicitud+Cr%C3%A9dito+Personal.pdf?MOD=AJPERES&CVID=ox3Xi4c&attachment=false&id=1684767285668)
[Hoja de Firmas del Contrato de Créditos Personales](https://www.viabcp.com/wcm/connect/2c7c5186-a6d5-4691-9044-781e9fa1b1e5/Hoja+de+firmas+del+Contrato+de+Cre%CC%81ditos+.pdf?MOD=AJPERES&CVID=nhpmNCJ&attachment=true&id=1599238009196)
[Cláusula de protección de datos personales](https://www.viabcp.com/wcm/connect/9c241eff-225e-442f-9ed8-2cdc371a40db/Cl%C3%A1usula+de+protecci%C3%B3n+de+datos+personales+act.+Mayo+2023.pdf?MOD=AJPERES&CVID=ox3X9A5&attachment=false&id=1684767361200)
[Cronograma de Créditos Personales](https://www.viabcp.com/wcm/connect/aab73a4c-67cb-45eb-ab52-6a7923cbfa7a/Cronograma+de+Cre%CC%81ditos+Personales.pdf?MOD=AJPERES&CVID=nhpYBqg&attachment=true&id=1599238090197)
[Formato de Instrucción de Pago](https://www.viabcp.com/wcm/connect/849efad3-fb51-4257-925c-de5d5feae47f/Formato+de+Instruccio%CC%81n+de+Pago+%282%29.pdf?MOD=AJPERES&CVID=nhpZ7qF&attachment=true&id=1599238129205)
[Hoja Resumen Créditos Estudios](https://www.viabcp.com/wcm/connect/c373184a-363e-4ad7-8cd9-2d2d7cd28499/Hoja+Resumen+Estudios+BCP+-+Septiembre+2023.pdf?MOD=AJPERES&CVID=oGQ53f5&attachment=false&id=1684767325475)
[Conoce más sobre tu Crédito de Estudios](https://www.viabcp.com/wcm/connect/2d05e14a-7dcd-4fda-be9a-33722d5bfe85/Ejemplo+Cre%CC%81dito+de+Estudios.pdf?MOD=AJPERES&CVID=nhp-plP&attachment=true&id=1599238226225)
[Calculadora](https://www.viabcp.com/wcm/connect/8f71873b-7b7c-4169-8691-376fc48edc7f/Cre%CC%81dito+de+Estudios.xls?MOD=AJPERES&CVID=nhp-zS2&attachment=true&id=1599238449331)
[Listado de Notarias según colegio de Notarios de Lima](http://www.notarios.org.pe/#/home)
[Listado de Notarias según colegio de Notarios del Callao](https://www.notarioscallao.org.pe/)
[Cartilla de Notarias según colegio de Notarios Provincia](https://www.viabcp.com/wcm/connect/45ba4e9b-bde2-462f-bc26-f99a82438307/Notarias_Provincias_Vehicular.pdf?MOD=AJPERES&CVID=nhlbM6H&attachment=true&id=1599238511552)
[Cartilla de Notarias - Staff BCP](https://www.viabcp.com/wcm/connect/3cab5166-226b-4d37-9f70-f65d85b4f4d3/Notarias+Staff+BCP_Vehicular.pdf?MOD=AJPERES&CVID=nhlb-st&attachment=true&id=1599238560134)
[Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
[Pasos para el endoso de la póliza del seguro de desgravamen](https://www.viabcp.com/wcm/connect/77bbcf39-6643-48e1-a04f-f172ed2238a4/Pasos+para+el+endoso+del+seguro+de+desgravamen.pdf?MOD=AJPERES&CVID=oiLUuSL&attachment=false&id=1669398130382)
[Contrato del Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/44dd0fad-7932-467a-b894-b8b91dd2673b/Contrato%2Bde%2BSeguro%2Bde%2BDesgravamen.pdf?MOD=AJPERES&CVID=oiM6xMY&attachment=false&id=1669401814203)
[Contrato Crédito de Estudios](https://www.viabcp.com/wcm/connect/d27a1bdb-d9c9-48ec-945e-b571d91e0ffa/Contrato+cr%C3%A9ditos+personales+Act.+Mayo+2023.pdf?MOD=AJPERES&CVID=oyytdLp&attachment=false&id=1686352810167)

### Documentos Descargables

- [Beneficios, Riesgos y Condiciones para Crédito de Estudios](https://www.viabcp.com/wcm/connect/cb7691a5-9209-42d7-a4d8-4b816c4bb2d6/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Estudios.pdf?MOD=AJPERES&CVID=oyysot7&attachment=false&id=1681478406292)
- [Contrato de Fianza Solidaria en favor del BCP](https://www.viabcp.com/wcm/connect/e81c30b9-373f-4333-876b-70c451baf276/Contrato+de+Fianza+Solidaria+a+favor+del+BCP+.pdf?MOD=AJPERES&CVID=nhplGnv&attachment=true&id=1599237838165)
- [Solicitud de Créditos Personales](https://www.viabcp.com/wcm/connect/9171287f-dadf-4b77-9ef5-add0a36efd53/Hoja+de+solicitud+Cr%C3%A9dito+Personal.pdf?MOD=AJPERES&CVID=ox3Xi4c&attachment=false&id=1684767285668)
- [Hoja de Firmas del Contrato de Créditos Personales](https://www.viabcp.com/wcm/connect/2c7c5186-a6d5-4691-9044-781e9fa1b1e5/Hoja+de+firmas+del+Contrato+de+Cre%CC%81ditos+.pdf?MOD=AJPERES&CVID=nhpmNCJ&attachment=true&id=1599238009196)
- [Cláusula de protección de datos personales](https://www.viabcp.com/wcm/connect/9c241eff-225e-442f-9ed8-2cdc371a40db/Cl%C3%A1usula+de+protecci%C3%B3n+de+datos+personales+act.+Mayo+2023.pdf?MOD=AJPERES&CVID=ox3X9A5&attachment=false&id=1684767361200)
- [Cronograma de Créditos Personales](https://www.viabcp.com/wcm/connect/aab73a4c-67cb-45eb-ab52-6a7923cbfa7a/Cronograma+de+Cre%CC%81ditos+Personales.pdf?MOD=AJPERES&CVID=nhpYBqg&attachment=true&id=1599238090197)
- [Formato de Instrucción de Pago](https://www.viabcp.com/wcm/connect/849efad3-fb51-4257-925c-de5d5feae47f/Formato+de+Instruccio%CC%81n+de+Pago+%282%29.pdf?MOD=AJPERES&CVID=nhpZ7qF&attachment=true&id=1599238129205)
- [Hoja Resumen Créditos Estudios](https://www.viabcp.com/wcm/connect/c373184a-363e-4ad7-8cd9-2d2d7cd28499/Hoja+Resumen+Estudios+BCP+-+Septiembre+2023.pdf?MOD=AJPERES&CVID=oGQ53f5&attachment=false&id=1684767325475)
- [Conoce más sobre tu Crédito de Estudios](https://www.viabcp.com/wcm/connect/2d05e14a-7dcd-4fda-be9a-33722d5bfe85/Ejemplo+Cre%CC%81dito+de+Estudios.pdf?MOD=AJPERES&CVID=nhp-plP&attachment=true&id=1599238226225)
- [Calculadora](https://www.viabcp.com/wcm/connect/8f71873b-7b7c-4169-8691-376fc48edc7f/Cre%CC%81dito+de+Estudios.xls?MOD=AJPERES&CVID=nhp-zS2&attachment=true&id=1599238449331)
- [Cartilla de Notarias según colegio de Notarios Provincia](https://www.viabcp.com/wcm/connect/45ba4e9b-bde2-462f-bc26-f99a82438307/Notarias_Provincias_Vehicular.pdf?MOD=AJPERES&CVID=nhlbM6H&attachment=true&id=1599238511552)
- [Cartilla de Notarias - Staff BCP](https://www.viabcp.com/wcm/connect/3cab5166-226b-4d37-9f70-f65d85b4f4d3/Notarias+Staff+BCP_Vehicular.pdf?MOD=AJPERES&CVID=nhlb-st&attachment=true&id=1599238560134)
- [Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
- [Pasos para el endoso de la póliza del seguro de desgravamen](https://www.viabcp.com/wcm/connect/77bbcf39-6643-48e1-a04f-f172ed2238a4/Pasos+para+el+endoso+del+seguro+de+desgravamen.pdf?MOD=AJPERES&CVID=oiLUuSL&attachment=false&id=1669398130382)
- [Contrato del Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/44dd0fad-7932-467a-b894-b8b91dd2673b/Contrato%2Bde%2BSeguro%2Bde%2BDesgravamen.pdf?MOD=AJPERES&CVID=oiM6xMY&attachment=false&id=1669401814203)
- [Contrato Crédito de Estudios](https://www.viabcp.com/wcm/connect/d27a1bdb-d9c9-48ec-945e-b571d91e0ffa/Contrato+cr%C3%A9ditos+personales+Act.+Mayo+2023.pdf?MOD=AJPERES&CVID=oyytdLp&attachment=false&id=1686352810167)

---

## Preguntas Frecuentes

**¿Qué es el Crédito Educativo BCP?**
Es un financiamiento de hasta el 100% del costo del postgrado, maestría o especializaciones en instituciones locales y extranjeras, ya sea a tiempo parcial o completo. Además, dependiendo del programa en el extranjero, podrías acceder incluso a financiamiento para gastos de manutención.

**¿Cuáles son los plazos de pago para el Crédito Educativo BCP?**
El plazo que te damos para cancelarlo es hasta 144 meses, con 12 cuotas anuales. Además, podrás acceder hasta 30 meses de periodo de gracia dependiendo del programa escogido*. *Previa evaluación crediticia.

**Tengo mi Cuenta Sueldo en BCP ¿Hay algún beneficio por eso?**
¡Por supuesto! Si tienes una Cuenta Sueldo BCP, podrás obtener mejores tasas para tu Crédito de Estudios.

**¿Cuáles son los requisitos para acceder a un Crédito Educativo?**
Te detallamos algunos de ellos: 
- Necesitas tener ingresos individuales de S/ 1,500. 
- Solicitar un financiamiento mínimo de 12 meses y contar con la carta de aceptación de la entidad educativa a la cual postulas. 
- DNI vigente Puedes revisarlos a detalle en la sección "Requisitos".
