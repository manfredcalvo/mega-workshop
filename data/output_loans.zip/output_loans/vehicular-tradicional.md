# Préstamo  Vehicular BCP

**Página:** https://www.viabcp.com/creditos/credito-vehicular/tradicional

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Mejores plazos:** Plazo de financiamiento hasta en 6 años
- **Flexibilidad:** Cuota inicial desde 0%
- **Diversidad:** Financiamos autos nuevos, semi-nuevos y usados de concesionarios

---

## Características


#### Ventajas:

- Puedes solicitar tu Crédito Vehicular Auto Usado BCP en nuestra red de Agencias de Lima Metropolitana, Piura, Chiclayo, Trujillo, Huancayo y Arequipa.
- Podrás adquirir el auto de familiares o de cualquier persona.
- No es necesario presentar un seguro vehicular para solicitar el crédito.
- La tarjeta de propiedad sale a tu nombre desde el primer día.
- Solicita tu estado de cuenta por correo electrónico, sin costo alguno, y, así, podrás conocer el estado de tu crédito.
- Incluimos el Seguro de Desgravamen, el cual cancela la deuda de inmediato en caso de muerte, así como un seguro contra riesgos durante todo el plazo de endeudamiento.
- Para los seguros asociados al crédito puedes elegir entre:
1. Contratar un seguro ofrecido por el BCP.
2. Contratar un seguro de otra compañía (elegido directamente o a través de un corredor de seguros), siempre que cumpla con las condiciones informadas por el banco.
- Podrás realizar pagos adelantados, reduciendo la última cuota de la Compra Inteligente BCP.

#### Requisitos:

- Es necesario que tengas un ingreso mensual bruto mínimo de S/ 1,500.
- El auto no debe superar los 10 años de antigüedad.
- Se debe presentar el DNI/CE del vendedor del auto y la placa del vehículo que se desea comprar.
- El auto a financiar debe pasar el examen de placa correspondiente.
- Buen comportamiento de pago en el BCP y sistema financiero, tanto para el comprador como para el vendedor del auto.

---

## Tasas y Tarifas

- La TEA para crédito en soles: desde 8.0% hasta 17.2%
- La TEA para crédito en dólares: desde 8.0% hasta 17.2%
Conoce más sobre tasas y tarifas [aquí](https://www.viabcp.com/tasasytarifas?rfid=footer:tasas-y-tarifas:link:2)

---

## Documentación

[Beneficios, Riesgos y Condiciones para Créditos Vehiculares](https://www.viabcp.com/wcm/connect/6350c95b-3705-4703-89cf-0997aad864b3/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Vehiculares.pdf?MOD=AJPERES&CVID=ot.RJmw&attachment=false&id=1681478036983)
[Contrato de Crédito Vehicular y Preconstitución de Garantía Mobiliaria](https://www.viabcp.com/wcm/connect/323efcde-70b1-4933-8712-ee1576f73dae/Contrato%2BCredito%2BVehicular%2By%2BPre%2BConstitucio%CC%81n%2Bde%2BGarantia%2BMobiliaria.pdf?MOD=AJPERES&CVID=prgGrlM&attachment=false&id=1747257792745)
[Contrato de Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/48a7d728-ce8c-4e0e-bdff-64da7c918d1c/Contrato%2Bde%2BSeguro%2Bde%2BDesgravamen+VF.pdf?MOD=AJPERES&CVID=oBWB4qo&attachment=true&id=1599163966790)
[Formatos para el endoso del seguro vehicular](https://www.viabcp.com/wcm/connect/f6108943-b821-4a6f-9ce8-96cfbf5bed8f/FORMATOS%2BPARA%2BENDOSAR%2BP%C3%93LIZA%2BVEHICULAR+%281%29.pdf?MOD=AJPERES&CVID=poQQ5hO&attachment=falsee&id=1744643559033)
[Requisitos para que el usuario pueda contratar un seguro directamente o a través   de un corredor de seguros](https://www.viabcp.com/wcm/connect/ac82ae6c-225c-45e3-b1ea-b9087ff5343c/Requisitos+para+que+el+usuario+pueda+contratar+un+seguro+directamente+o+a+trav%C3%A9s+de+un+corredor+de+seguros.pdf?MOD=AJPERES&CVID=ot.VeVO&attachment=false&id=1681478627115)
[Solicitud para Levantamiento de Garantía Mobiliaria Vehicular](https://www.viabcp.com/wcm/connect/deecbaba-e2f2-4287-ab33-bb9f284e43f8/Solicitud+para+Levantamiento+de+Garanti%CC%81a+Mobiliaria+Vehicular.pdf?MOD=AJPERES&CVID=nhlamSN&attachment=true&id=1599164063990)
[Adenda a la Hoja Resumen de Créditos Vehiculares](https://www.viabcp.com/wcm/connect/c2a1bcea-b591-4245-8e0f-a616724120a7/Adenda+a+la+Hoja+Resumen+de+Cre%CC%81ditos+Vehiculares.pdf?MOD=AJPERES&CVID=nhlaCfE&attachment=true&id=1599164112637)
[Formato de Instrucción de Pago](https://www.viabcp.com/wcm/connect/d1d10276-8a07-47e8-8a7f-c771181534cf/Formato+de+Instruccio%CC%81n+de+Pago+%281%29.pdf?MOD=AJPERES&CVID=nhlaN.1&attachment=true&id=1599164183326)
[Hoja resumen Créditos Vehiculares](https://www.viabcp.com/wcm/connect/75ed1a14-0338-4e81-aa51-807650893d1b/HojaResumenYCronograma_21112024112914.pdf?MOD=AJPERES&CVID=pdkZh6a&attachment=false&id=1732304759594)
[Conoce más sobre tu Crédito Vehicular BCP](https://www.viabcp.com/wcm/connect/b9ed7b11-d9cf-4f38-ab21-71c988c5bb85/Conoce+mas+sobre+tu+Cr%C3%A9dito+Vehicular+BCP.pdf?MOD=AJPERES&CVID=pdlpPC2&attachment=false&id=1732304888547)
[Calculadora](https://www.viabcp.com/wcm/connect/60a937dd-a5a7-4878-9d19-cccc83d49368/Cr%C3%A9dito+Vehicular+Tradicional.xlsm?MOD=AJPERES&CVID=prgH6Gh&attachment=false&id=1747257833538)
[Listado de Notarias según colegio de Notarios de Lima](http://www.notarios.org.pe/#/home)
[Listado de Notarias según colegio de Notarios del Callao](https://www.notarioscallao.org.pe)
[Cartilla de Notarias según colegio de Notarios Provincia](https://www.viabcp.com/wcm/connect/45ba4e9b-bde2-462f-bc26-f99a82438307/Notarias_Provincias_Vehicular.pdf?MOD=AJPERES&CVID=nhlbM6H&attachment=true&id=1599164640325)
[Cartilla de Notarias - Staff BCP](https://www.viabcp.com/wcm/connect/45ba4e9b-bde2-462f-bc26-f99a82438307/Notarias_Provincias_Vehicular.pdf?MOD=AJPERES&CVID=nhlbM6H&attachment=true&id=1599164684597)
[Políticas de Uso - Promoción SOATGratis – BCP](https://www.viabcp.com/wcm/connect/dd28a651-6389-435f-b42f-f9e20acb3d0e/Soat+Bianual+Terminos+y+Condiciones+FINAL+-+Septiembre.pdf?MOD=AJPERES&CVID=obX1rzl&attachment=false&id=1662068835287)
[Términos y condiciones de la Promoción “Seguro adicional con cobertura de Accidentes Personales”](https://www.viabcp.com/wcm/connect/cd698ded-22f1-479b-b752-f2d9c0348776/Te%CC%81rminos+y+condiciones+-+Seguro+de+Autos+%2B+AP+FINAL+-+Septiembre+%281%29.pdf?MOD=AJPERES&CVID=ockjCM5&attachment=false&id=1662493027828)
[Formato de solicitud de crédito vehicular](https://www.viabcp.com/wcm/connect/b9cf1675-5f39-419b-8a29-acd07d0d3b6a/Formato+Solicitud+-+Contingencia.pdf?MOD=AJPERES&CVID=oiM6mxk&attachment=false&id=1669401766228)
[Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
[Formulario de Seguro Vehicular](https://www.viabcp.com/wcm/connect/db3a40d3-8e24-4f46-955a-7224a14433d1/Formulario+de+seguro+vehicular.xls?MOD=AJPERES&CVID=ouBuZsO&attachment=false&id=1682108643096)
[Términos y Condiciones de Sorteo](https://www.viabcp.com/wcm/connect/a91a1f01-e91e-4503-854a-91dec781a8ff/TC+-+SORTEO+SQUAD+VEHICULAR+FINALES+%282%29.pdf?MOD=AJPERES&CVID=pacR1gY&attachment=false&id=1728939619878)

### Documentos Descargables

- [Beneficios, Riesgos y Condiciones para Créditos Vehiculares](https://www.viabcp.com/wcm/connect/6350c95b-3705-4703-89cf-0997aad864b3/Beneficios%2C+Riesgos+y+Condiciones+para+Cr%C3%A9ditos+Vehiculares.pdf?MOD=AJPERES&CVID=ot.RJmw&attachment=false&id=1681478036983)
- [Contrato de Crédito Vehicular y Preconstitución de Garantía Mobiliaria](https://www.viabcp.com/wcm/connect/323efcde-70b1-4933-8712-ee1576f73dae/Contrato%2BCredito%2BVehicular%2By%2BPre%2BConstitucio%CC%81n%2Bde%2BGarantia%2BMobiliaria.pdf?MOD=AJPERES&CVID=prgGrlM&attachment=false&id=1747257792745)
- [Contrato de Seguro de Desgravamen](https://www.viabcp.com/wcm/connect/48a7d728-ce8c-4e0e-bdff-64da7c918d1c/Contrato%2Bde%2BSeguro%2Bde%2BDesgravamen+VF.pdf?MOD=AJPERES&CVID=oBWB4qo&attachment=true&id=1599163966790)
- [Formatos para el endoso del seguro vehicular](https://www.viabcp.com/wcm/connect/f6108943-b821-4a6f-9ce8-96cfbf5bed8f/FORMATOS%2BPARA%2BENDOSAR%2BP%C3%93LIZA%2BVEHICULAR+%281%29.pdf?MOD=AJPERES&CVID=poQQ5hO&attachment=falsee&id=1744643559033)
- [Requisitos para que el usuario pueda contratar un seguro directamente o a través   de un corredor de seguros](https://www.viabcp.com/wcm/connect/ac82ae6c-225c-45e3-b1ea-b9087ff5343c/Requisitos+para+que+el+usuario+pueda+contratar+un+seguro+directamente+o+a+trav%C3%A9s+de+un+corredor+de+seguros.pdf?MOD=AJPERES&CVID=ot.VeVO&attachment=false&id=1681478627115)
- [Solicitud para Levantamiento de Garantía Mobiliaria Vehicular](https://www.viabcp.com/wcm/connect/deecbaba-e2f2-4287-ab33-bb9f284e43f8/Solicitud+para+Levantamiento+de+Garanti%CC%81a+Mobiliaria+Vehicular.pdf?MOD=AJPERES&CVID=nhlamSN&attachment=true&id=1599164063990)
- [Adenda a la Hoja Resumen de Créditos Vehiculares](https://www.viabcp.com/wcm/connect/c2a1bcea-b591-4245-8e0f-a616724120a7/Adenda+a+la+Hoja+Resumen+de+Cre%CC%81ditos+Vehiculares.pdf?MOD=AJPERES&CVID=nhlaCfE&attachment=true&id=1599164112637)
- [Formato de Instrucción de Pago](https://www.viabcp.com/wcm/connect/d1d10276-8a07-47e8-8a7f-c771181534cf/Formato+de+Instruccio%CC%81n+de+Pago+%281%29.pdf?MOD=AJPERES&CVID=nhlaN.1&attachment=true&id=1599164183326)
- [Hoja resumen Créditos Vehiculares](https://www.viabcp.com/wcm/connect/75ed1a14-0338-4e81-aa51-807650893d1b/HojaResumenYCronograma_21112024112914.pdf?MOD=AJPERES&CVID=pdkZh6a&attachment=false&id=1732304759594)
- [Conoce más sobre tu Crédito Vehicular BCP](https://www.viabcp.com/wcm/connect/b9ed7b11-d9cf-4f38-ab21-71c988c5bb85/Conoce+mas+sobre+tu+Cr%C3%A9dito+Vehicular+BCP.pdf?MOD=AJPERES&CVID=pdlpPC2&attachment=false&id=1732304888547)
- [Calculadora](https://www.viabcp.com/wcm/connect/60a937dd-a5a7-4878-9d19-cccc83d49368/Cr%C3%A9dito+Vehicular+Tradicional.xlsm?MOD=AJPERES&CVID=prgH6Gh&attachment=false&id=1747257833538)
- [Cartilla de Notarias según colegio de Notarios Provincia](https://www.viabcp.com/wcm/connect/45ba4e9b-bde2-462f-bc26-f99a82438307/Notarias_Provincias_Vehicular.pdf?MOD=AJPERES&CVID=nhlbM6H&attachment=true&id=1599164640325)
- [Cartilla de Notarias - Staff BCP](https://www.viabcp.com/wcm/connect/45ba4e9b-bde2-462f-bc26-f99a82438307/Notarias_Provincias_Vehicular.pdf?MOD=AJPERES&CVID=nhlbM6H&attachment=true&id=1599164684597)
- [Políticas de Uso - Promoción SOATGratis – BCP](https://www.viabcp.com/wcm/connect/dd28a651-6389-435f-b42f-f9e20acb3d0e/Soat+Bianual+Terminos+y+Condiciones+FINAL+-+Septiembre.pdf?MOD=AJPERES&CVID=obX1rzl&attachment=false&id=1662068835287)
- [Términos y condiciones de la Promoción “Seguro adicional con cobertura de Accidentes Personales”](https://www.viabcp.com/wcm/connect/cd698ded-22f1-479b-b752-f2d9c0348776/Te%CC%81rminos+y+condiciones+-+Seguro+de+Autos+%2B+AP+FINAL+-+Septiembre+%281%29.pdf?MOD=AJPERES&CVID=ockjCM5&attachment=false&id=1662493027828)
- [Formato de solicitud de crédito vehicular](https://www.viabcp.com/wcm/connect/b9cf1675-5f39-419b-8a29-acd07d0d3b6a/Formato+Solicitud+-+Contingencia.pdf?MOD=AJPERES&CVID=oiM6mxk&attachment=false&id=1669401766228)
- [Solicitud del seguro de desgravamen con retorno](https://www.viabcp.com/wcm/connect/10fab283-3e60-4d6e-8e01-51f2dd845605/1.-+Desgravamen+Retorno+-+Vehicular.pdf?MOD=AJPERES&CVID=oMrWSAi&attachment=false&id=1669398067896)
- [Formulario de Seguro Vehicular](https://www.viabcp.com/wcm/connect/db3a40d3-8e24-4f46-955a-7224a14433d1/Formulario+de+seguro+vehicular.xls?MOD=AJPERES&CVID=ouBuZsO&attachment=false&id=1682108643096)
- [Términos y Condiciones de Sorteo](https://www.viabcp.com/wcm/connect/a91a1f01-e91e-4503-854a-91dec781a8ff/TC+-+SORTEO+SQUAD+VEHICULAR+FINALES+%282%29.pdf?MOD=AJPERES&CVID=pacR1gY&attachment=false&id=1728939619878)

---

## Canales Disponibles

- Puedes iniciar el trámite de tu Crédito Vehicular dejando tus datos en el formulario.
- Toda la red de Agencias BCP a nivel nacional.
- Los módulos de Crédito Vehicular en Expomotor Plaza Lima Norte y Mall del Sur; así como MotorPlaza Trujillo.
- Solicitándolo directamente en los concesionarios de tu preferencia.
- Comunicándote directamente con tu Funcionario.

---

## Preguntas Frecuentes

**¿Cuáles son las consideraciones para solicitar el Préstamo?**
**Si recibes tu sueldo en el BCP** 
- Solo necesitas una copia de tu documento de identidad **Si recibes tu sueldo fuera del BCP** Y eres trabajador dependiente: 
- Una copia de tu documento de identidad o carnet de extranjería 
- Tres últimas boletas de pago Y eres trabajador independiente: 
- Una copia de tu documento de identidad o carnet de extranjería 
- Copia de tu ficha RUC 
- Copia de tus tres últimas boletas o recibos por honorarios 
- Estar laborando actualmente **Podrás acercarte a cualquiera de nuestras agencias a nivel nacional para las siguientes solicitudes:** 
1. Información en el caso de fallecimiento del titular de la cuenta 
2. Solicitudes de resolución del contrato 
3. Pagos anticipados

**¿Cómo puedo cancelar mi Préstamo Vehicular?**
- Si quieres cancelar la totalidad de tu crédito, recuerda primero comunicarte con nuestra Banca por Teléfono para darte el monto exacto a pagar. En caso optes por ir a una Agencia, el asesor de ventanilla te podrá brindar esa información. 
- Estimado cliente, le informamos que, si realizó el pago total de su Crédito Vehicular y no presenta deuda, su Carta de Levantamiento de Garantía Vehicular estará disponible en un plazo no mayor a siete (7) días hábiles posteriores a la cancelación o pago total del crédito. Podrá acercarse a cualquiera de nuestras Agencias BCP a nivel nacional o comunicarse con su Funcionario de Negocios BCP asignado.

**¿Qué tipos de autos puedo financiar?**
Los autos deberán ser de uso particular (no comercial). Podrás financiar autos con una antigüedad de hasta 10 años. Además, puedes [cotizar tu seguro vehicular](https://www.viabcp.com/seguros/vehicular/seguro-vehicular) y manejar con total tranquilidad.

**¿Dónde puedo solicitarlo?**
Podrás encontrarnos en las principales concesionarias de autos a nivel nacional o podrás solicitarlo en cualquier agencia BCP o directamente con tu funcionario BCP.
