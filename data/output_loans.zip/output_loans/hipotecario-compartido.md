# Hipotecario Compartido

**Página:** https://www.viabcp.com/creditos/credito-hipotecario/hipotecario-compartido

**Solicítalo aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Se evalúa en conjunto los ingresos de ambos solicitantes.**
- **Cada solicitante obtendrá un crédito individual.**
- **Financiamos hasta el 90% del valor del inmueble.**

---

## Características


#### Ventajas

- No es necesario que el inmueble a financiar sea de estreno.
- Destina el 25% de tu AFP para la cuota inicial del Crédito Hipotecario BCP. Los trámites de liberación de fondos y la gestión para la emisión del reporte de SUNARP no tienen costo.
- Al iniciar la solicitud de tu Crédito Hipotecario BCP podrás disponer de nuestro servicio de recojo de documentos para facilitarte la entrega y así evitar visitas extras a la agencia donde ingresaste tu solicitud hipotecaria
- Puedes elegir entre: 
- Contratar un seguro ofrecido por el BCP. 
- Contratar un seguro de otra compañía (elegido directamente o a través de un corredor de seguros), siempre que cumpla con las condiciones informadas por el banco.

#### Consideraciones

En caso desees conocer más sobre los siguientes procesos, podrás acercarte a cualquiera de nuestras agencias a nivel nacional para obtener el detalle:
1. Información en el caso de fallecimiento del titular de la cuenta
2. Solicitudes de resolución del contrato
3. Pagos anticipados

---

## Requisitos


#### Generales

- Tus ingresos mensuales deben ser mayores a S/ 1,500 o $400.

#### Documentación

- DNI o Carné de extranjería.
- Si no recibes tu sueldo en el BCP debes presentar sustento de tus ingresos con boletas de pago, recibos por honorario, etc. dependiendo de la categoría de tu ingreso.

---

## Tasas y Tarifas

- TEA máxima para crédito en soles: 13.90 %
- TEA máxima para crédito en dólares: 11.10 %
Conoce más sobre Tasas y Tarifas [aquí](https://www.viabcp.com/tasasytarifas?pcid=viabcp:creditos-credito-hipotecario-tradicional:solicita-tu-credito-hipotecari:masivo:todo-lo-que-debes-saber-aqui) .

---

## Documentación


### Contratos y formularios

[Contrato de Prestamo Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/5630dba5-4f0d-48ec-8e35-c78f7c3d3e67/Contrato+de+Prestamo+Hipotecario+Tradicional+Resoluci%C3%B3n+SBS+N+01039+-+2022+30.03.2022-Credito+Compartido.docx?MOD=AJPERES&CVID=ovDFJHX&attachment=false&id=1683219737446)
[Hoja Resumen Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/946cfadc-c11c-4db8-a5b5-d944616217a6/Hoja%2BResumen%2BCre%CC%81dito%2BHipotecario%2BTradicional%2BBCP%2B2023_.pdf?MOD=AJPERES&CVID=ovDKrlG&attachment=false&id=1683219898073)
[Solicitud de Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/44c192ae-0c8b-46b0-aa71-cc673dddda58/SolicitudCredito.pdf?MOD=AJPERES&CVID=ovXYmjj&attachment=false&id=1683559166009)
[Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso mixto)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
[Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso vivienda)](https://www.viabcp.com/wcm/connect/6df0792b-cce1-4d7d-ad4c-db97cdc93a9d/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXEX5&attachment=false&id=1683219835593)
[Declaración de Salud](https://www.viabcp.com/wcm/connect/a373b127-37b1-4cf5-abb6-e2e51418da18/Declaracio%CC%81n%2BSalud.pdf?MOD=AJPERES&CVID=ovDFRYK&attachment=false&id=1683219800534)
[Fórmulas y Ejemplos explicativos](https://www.viabcp.com/wcm/connect/64c9f5e4-c77a-453c-93e1-dd3ae9994420/F%C3%B3rmulas+y+ejemplos+explicativos+%28Hipotecario+Tradicional%29.pdf?MOD=AJPERES&CVID=ovDKx8L&attachment=false&id=1683219920448)

### Documentos Descargables

- [Contrato de Prestamo Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/5630dba5-4f0d-48ec-8e35-c78f7c3d3e67/Contrato+de+Prestamo+Hipotecario+Tradicional+Resoluci%C3%B3n+SBS+N+01039+-+2022+30.03.2022-Credito+Compartido.docx?MOD=AJPERES&CVID=ovDFJHX&attachment=false&id=1683219737446)
- [Hoja Resumen Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/946cfadc-c11c-4db8-a5b5-d944616217a6/Hoja%2BResumen%2BCre%CC%81dito%2BHipotecario%2BTradicional%2BBCP%2B2023_.pdf?MOD=AJPERES&CVID=ovDKrlG&attachment=false&id=1683219898073)
- [Solicitud de Crédito Hipotecario Tradicional BCP](https://www.viabcp.com/wcm/connect/44c192ae-0c8b-46b0-aa71-cc673dddda58/SolicitudCredito.pdf?MOD=AJPERES&CVID=ovXYmjj&attachment=false&id=1683559166009)
- [Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso mixto)](https://www.viabcp.com/wcm/connect/54fd4b29-4c50-48fe-8961-efe3c8854a0c/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXC9f&attachment=false&id=1683219865171)
- [Solicitud de Seguro de Desgravamen y de Seguro de Inmueble (uso vivienda)](https://www.viabcp.com/wcm/connect/6df0792b-cce1-4d7d-ad4c-db97cdc93a9d/Anexo+7+-+Seguro_Desgravamen_Hipotecario_BCP.pdf?MOD=AJPERES&CVID=oMmXEX5&attachment=false&id=1683219835593)
- [Declaración de Salud](https://www.viabcp.com/wcm/connect/a373b127-37b1-4cf5-abb6-e2e51418da18/Declaracio%CC%81n%2BSalud.pdf?MOD=AJPERES&CVID=ovDFRYK&attachment=false&id=1683219800534)
- [Fórmulas y Ejemplos explicativos](https://www.viabcp.com/wcm/connect/64c9f5e4-c77a-453c-93e1-dd3ae9994420/F%C3%B3rmulas+y+ejemplos+explicativos+%28Hipotecario+Tradicional%29.pdf?MOD=AJPERES&CVID=ovDKx8L&attachment=false&id=1683219920448)

---

## Preguntas Frecuentes

**¿Qué puedo financiar con mi Crédito Hipotecario Compartido?**
Te permite financiar la compra de una vivienda construida, vivienda en planos, vivienda construcción, casa de campo o casa de playa.

**¿Qué monto puedo financiar con mi Crédito Hipotecario BCP?**
Puedes financiarte desde S/ 32,000 (o USD 10,000) hasta el monto que tu capacidad de pago permita.

**¿Cuánto debe ser mi ingreso mensual para calificar al Crédito Hipotecario BCP?**
El ingreso bruto mínimo es de S/ 1,500. Podrás sustentarlo a través de boletas de pago o recibos por honorarios.

**¿Cómo funciona el Crédito Hipotecario Compartido?**
Te permite adquirir una vivienda junto a otra persona, ambos serán evaluados en conjunto, pero cada solicitante obtendrá un crédito individual con condiciones similares (el monto de financiamiento variará en función a la capacidad de pago que cada uno podrá asumir).

**¿A quién puedo elegir para mi Crédito Hipotecario Compartido?**
En el BCP le damos la oportunidad a todos de elegir con quién desean hacer realidad el sueño del depa propio, esta persona puede ser tu pareja, amigo o familiar. ¡Tú decides!
