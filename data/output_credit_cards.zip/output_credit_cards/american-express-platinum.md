# American Express Platinum LATAM PASS

**Conoce los beneficios exclusivos de tu Tarjeta de Crédito American Express Platinum LATAM Pass BCP.**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Bono de Millas:** 3,000 Millas por meta de compras de S/ 1,000 durante los primeros 45 días
- **Beneficios AMEX Platinum:** Llena tu vida de momentos inolvidables **[aquí](https://www.americanexpress.com/es-pe/network/beneficios/)**
- **Acumula Millas LATAM Pass:** 1 Milla por cada USD 1 de consumo

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Beneficios American Express

- Club Avolta: Membresía Platinum de cortesía de 1 año
- Hoteles: Booking.com y Tablet Hotels
- Alquiler de autos: Hertz, SIXT y Rentalcars
- Estilo de Vida: 
- PressReader (Suscripción Premium de cortesía por 1 año) 
- Restaurantes: Hasta S/150 dto. y postre de cortesía de lunes a viernes en restaurantes seleccionados
- Preventa de entradas: Us Open, Wimbledon, Fórmula 1
- **Cineplanet:** 50% OFF en entradas 2D, 3D XTREME y 35% de descuento en salas PRIME. (Aplica [Términos y Condiciones](https://www.viabcp.com/wcm/connect/79029a0e-320d-498b-8b6b-bcae4a38c1ee/T%26C+Beneficio+Cineplanet+-+Amex+2025-2026.pdf?MOD=AJPERES&CVID=pHLMu2r&attachment=false&id=1764959470447) ).
Conoce más sobre los términos y condiciones [aquí](https://www.americanexpress.com/es-pe/network/?cid=pe-homepage-country?cid=pe-homepage-country)

#### Asistencia en viajes premier

- Disponible 24 horas todos los días de la semana.
- Servicio de Telemedicina.
- Cobertura COVID durante viajes.
- Médico a domicilio.
- Envío de medicamentos y más.
- [Conoce más aquí](https://www.americanexpress.com/es-pe/network/)
(*) Sólo aplica en viajes

#### Seguros gratuitos

**Seguros de viajes**
- Seguro de Accidentes en viajes
- Seguro de inconvenientes en viajes
- Demora de vuelo
- Demora de equipaje
- Pérdida de equipaje
- Pérdida de conexión
- Seguro de alquiler de vehículos
**Seguros de compras**
- Seguro de Protección de compras
[Portal de Asistencia y Seguro de American Express](https://cardmember-benefits.axa-assistance.us/home) 
 Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Amex.

#### Campañas exclusivas

- **Campañas multiplicadoras y sorteos de millas**
Podrás participar en campañas exclusivas de Tarjeta de Crédito BCP y ganar millas para canjear productos y/o viajes o participar en sorteos o devolución por compras. Para ello es importante que tengas tus datos actualizados. 
 
 (*) Las campañas campañas exclusivas y alianzas son temporales.

#### Beneficios adicionales

- **Solicita tu Préstamo Tarjetero**
Obtén liquidez al instante desde tu Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslada tu deuda**
Libérate de las preocupaciones y reorganiza tus deudas
- **Solicita una Tarjeta Adicional Gratis**
Solicita adicionales sin costo y comparte tu línea de crédito.
[Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplía tu línea de crédito**
Solicita un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesitas un aumento mayor, acércate a cualquiera de nuestras agencias. (*) Sujeto a evaluación.
- **Mejora tu tarjeta**
Se conoce como **Upgrade** . Puedes cambiar tu tarjeta por otra con beneficios adicionales. *Sujeto a evaluación.
- **Cuenta Sueldo**
Si eres cliente Cuenta Sueldo, podrás disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas. 
 [Conoce los Beneficios Cuenta Sueldo aquí](https://www.viabcp.com/beneficios/todos-los-beneficios)

#### ¡Afíliate a Cargos recurrentes!

- Realiza tus pagos de manera automática con tu Tarjeta de Crédito BCP LATAM Pass.
- Paga todos tus pendientes sin tener que ir al banco ni ingresar a la web. Solo debes registrarte con tu Clave de Internet y tus pagos se harán de manera automática y sencilla.
- Puedes suspender hasta dos cargos seguidos. ¡No te preocupes!, puedes desafiliarte cuando quieras.
- Podrás acumular Millas LATAM Pass según el tipo de tarjeta que tengas.
- [Conoce más beneficios y cómo hacerlo aquí.](https://www.viabcp.com/tarjetas/cargos-recurrentes)

#### ¡Conoce otrasTarjetas American Express!


---

## LATAM Pass


#### Bono de bienvenida

- Recibe un bono de 3,000 Millas LATAM Pass por una meta mínima de compras de S/1,000 en consumo por POS o por internet durante los primeros 45 días desde la aprobación de tu tarjeta de crédito.

#### Acumula millas

- 1 milla por cada USD 1 de consumo
- [Consideraciones del programa LATAM Pass American Express Platinum](https://www.viabcp.com/wcm/connect/4a7d37ab-59ed-4564-aa78-078636b0fab7/Consideraciones%2Bdel%2BPrograma%2BLATAM%2BPass%2B+AMEX+PLATINUM.pdf?MOD=AJPERES&CVID=oTD2ibP&attachment=false&id=1708978346566)

#### Beneficios Exclusivos

- Conoce más sobre tu tarjeta BCP LATAM Pass [aquí](https://latampass.latam.com/es_pe/acumula-millas/tarjeta-bcp-latam-pass)
- La acumulación, canje, uso y demás condiciones aplicables a los beneficios otorgados por las tarjetas BCP LATAM Pass se rigen bajo el reglamento de LATAM Pass publicado [aquí](https://latampass.latam.com/es_pe/descubre-latam-pass/terminos-y-condiciones)

---

## Tasas y Tarifas


#### Tasa de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios: 57.00% - 95.90%
- Tasa Efectiva Anual (TEA) para compras o pago de servicios en $​: 57.00% - 76.90%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo: 107.00%
- Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 85.9%​
- Tasa de interés TCEA Máxima 171.14%
- Tasa de Interés TCEA MÁXIMA en $: 76.90%​

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/ 350 
- ¡ExonÉrate del pago de membresía! 
- Solo si consumes todos los meses y el consumo promedio de 12 meses es igual o mayor a S/ 1,200 (aplica para venta de nuevas tarjetas).
- **Seguros desgravamen** 
- Seguro de desgravamen mensual 0.285% del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20
- **Otros gastos** 
- Para exonerarte de la membresía, debes cumplir con las siguientes condiciones 
- (*) Ver más información sobre Tasas y Tarifas [aquí](https://www.viabcp.com/tasasytarifas) .

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo S/ 5,000.
- Debes estar laborando al momento de solicitar la tarjeta.

#### Documentación en Canal Digital

- No necesitas ningún documento; obtén tu tarjeta al instante ingresando a nuestra web con tu número de tarjeta de débito y tu clave de internet haciendo clic [aquí](https://www.mitarjetabcp.viabcp.com/) .
- La venta está sujeta a evaluación.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesitas una copia de tu documento de identidad.
**Si recibes tu sueldo fuera del BCP**
- **Y eres trabajador dependiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus dos últimas boletas de pago.
- **Y eres trabajador independiente:** 
- Copia de tu ficha RUC. 
- Copia de tus tres últimas declaraciones de impuestos (PDT) o copia de tu declaración jurada de Impuesto a la Renta. 
- Copia del último recibo de teléfono fijo. 
- Copia simple de tu documento de identidad.

---

## Consideraciones


#### ¡Tu eliges cómo asegurarte!

Puedes optar por las siguientes alternativas para asegurarte:
- Elegir la contratación del seguro ofrecido por el BCP.
- Contratar un seguro a través de un corredor de seguros. Este deberá cumplir con las condiciones previamente informadas en el certificado o póliza de seguros.

#### Si vas a realizar compras en el extranjero

- Ten en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación.
- Para más información sobre las tarifas, clic [aquí](https://ww3.viabcp.com/tasasytarifas/index.aspx#) **.**

#### Sobre el Programa LATAM Pass

- Las disposiciones de efectivo, traslados de deuda, préstamo tarjetero, consumos en casinos, pagos de servicios realizados en  Banca por Internet o en Banca Móvil, débitos automáticos, pagos de impuestos y servicios legales no acumulan Millas LATAM Pass. Únicamente los pagos de servicios educativos en viabcp o banca móvil con [Tarjeta de crédito](https://www.viabcp.com/tarjetas/tarjetas-credito) Visa Signature, Visa Infinite y Amex Black acumulan millas. ​
- A partir del 1 de abril del 2024 los clientes que tengan mora mayor a 8 días en el pago de la cuota de su Tarjeta de Crédito BCP, no podrán acumular millas por los consumos generados a partir del día 9 de mora hasta que se regularice la deuda inclusive. Recién podrá acumularlas por aquellos consumos realizados a partir del día siguiente después de realizado el pago de su cuota.​

#### Ten en cuenta que

- Puedes trasladar tu deuda en soles o dólares a cualquiera de las tarjetas de crédito del BCP.
- Tus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realizas disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debes comunicarte con nuestra Banca por Teléfono.
- La facturación de tu **Tarjeta de Crédito en el Perú** se realiza en soles, mientras que los consumos efectuados en el exterior se facturan en dólares, excepto en aquellos establecimientos dentro del país que operan en esta moneda.

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 01697-2023.
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/83e75772-d73a-4dad-8f1f-b218e238296d/Solicitud%2BCompra%2Bde%2BDeuda%2BTarjeta%2Bde%2BCr%C3%A9dito+%282%29.pdf?MOD=AJPERES&CVID=nYNOiiD&attachment=false&id=1645807740535)
[Hoja Resumen Tarjeta de Crédito American Express Platinum BCP LATAM Pass](https://www.viabcp.com/wcm/connect/a8110886-cde5-4d13-b8d5-79d79305bf6e/HR_AMEX_LATAM%2B-%2BPlatinum%2B%281%29.pdf?MOD=AJPERES&CVID=pAGphzG&attachment=false&id=1757353227119)
[Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
[Fórmulas y Ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
[AMEX - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/36a954c7-f946-42f3-82ea-5335a96b067c/AMEX+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25uAc&attachment=false&id=1768487967405)
[Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599512159906)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/83e75772-d73a-4dad-8f1f-b218e238296d/Solicitud%2BCompra%2Bde%2BDeuda%2BTarjeta%2Bde%2BCr%C3%A9dito+%282%29.pdf?MOD=AJPERES&CVID=nYNOiiD&attachment=false&id=1645807740535)
- [Hoja Resumen Tarjeta de Crédito American Express Platinum BCP LATAM Pass](https://www.viabcp.com/wcm/connect/a8110886-cde5-4d13-b8d5-79d79305bf6e/HR_AMEX_LATAM%2B-%2BPlatinum%2B%281%29.pdf?MOD=AJPERES&CVID=pAGphzG&attachment=false&id=1757353227119)
- [Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
- [Fórmulas y Ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
- [AMEX - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/36a954c7-f946-42f3-82ea-5335a96b067c/AMEX+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25uAc&attachment=false&id=1768487967405)
- [Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599512159906)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---

## Preguntas Frecuentes

**¿Qué requisitos se necesita para tener una Tarjeta de Crédito American Express Platinum BCP?**
Para obtener una Tarjeta de Crédito [American Express](https://www.viabcp.com/tarjetas/tarjetas-credito-amex) Platinum LATAM Pass BCP, también conocida como Tarjeta de Crédito AMEX Platinum, necesitas tener un ingreso mensual mínimo de S/5,000 y estar laborando al momento de solicitar la tarjeta.

**¿Qué beneficios y descuentos tiene la Tarjeta de Crédito AMEX Platinum BCP?**
- Acumulación de millas con tus compras ¡Y obtén muchos más beneficios con tu Tarjeta de Crédito AMEX Platinum BCP!

**¿Cómo acumular millas con la Tarjeta de Crédito American Express Platinum BCP?**
Acumula 1.5 millas por cada 1 USD que consumas con tu Tarjeta de Crédito AMEX Black LATAM Pass BCP, una [tarjeta Amex](https://www.viabcp.com/tarjetas/tarjetas-credito-amex) diseñada para maximizar tus beneficios en viajes.
