# Tarjeta Visa Light

**Sin Membresía: Ligera como el aire**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Libérate del Pago de Membresía:** No necesitas de montos mínimos de consumo
- **Compra en Cuotas Sin Intereses:** Realiza tus compras hasta en 24 cuotas **[aquí](https://www.viabcp.com/beneficios/cuotas-sin-intereses) .**
- **Traslada tu Deuda:** Libérate de las preocupaciones y reorganiza tus deudas

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Beneficios Visa Light

- **Libérate del pago de membresía**
La membresía anual es gratuita y no necesitas de montos mínimos de consumo.
- **Asistencia**
Servicio de Asistencia Internacional Visa 24x7 (desembolso de efectivo y reemplazo de tarjetas). Conoce más [aquí](http://www.visa.com/portalbeneficios) .
(*) Sólo aplica para casos internacionales.
- **Seguros de compras**
Seguro de Protección de Precio. 
 
 Conoce más sobre los términos y condiciones [aquí](https://visabenefitslac.axa-assistance.us/?utm_source=visacom&utm_medium=redirect&utm_campaign=visa&utm_content=esp)
(*) Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Visa.

#### Beneficios Exclusivos

- **Delivery gratis a donde quieras​**

#### Campañas exclusivas

- **Campañas de cashback** 
- Podrás participar en campañas de Tarjeta de Crédito BCP para obtener una devolución por las compras que realices. 
- (*) Las campañas exclusivas son temporales.

#### Beneficios adicionales

- **Solicita tu Préstamo Tarjetero**
Obtén liquidez al instante desde tu Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslada tu deuda**
Libérate de las preocupaciones y reorganiza tus deudas.
- **Solicita una Tarjeta Adicional Gratis**
Solicita adicionales sin costo y comparte tu línea de crédito.
[Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplía tu línea de crédito**
Solicita un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesitas un aumento mayor, acércate a cualquiera de nuestras agencias. 
 (*) Sujeto a evaluación.
- **Mejora tu tarjeta**
Se conoce como “Upgrade”. Puedes cambiar tu tarjeta por otra con beneficios adicionales. 
 (*) Sujeto a evaluación.
- **Cuenta Sueldo**
Si eres cliente Cuenta Sueldo, podrás disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas. Conoce los Beneficios Cuenta Sueldo [aquí](https://www.viabcp.com/beneficios/todos-los-beneficios) .

#### ¡Afíliate a Cargos recurrentes!

- Realiza tus pagos de manera automática con tu Tarjeta de Crédito BCP.
- Paga todos tus pendientes sin tener que ir al banco ni ingresar a la web. Solo debes registrarte con tu Clave de Internet y tus pagos se harán de manera automática y sencilla.
- Puedes suspender hasta dos cargos seguidos. ¡No te preocupes!, puedes desafiliarte cuando quieras.
- Conoce más beneficios y cómo hacerlo [aquí](https://www.viabcp.com/tarjetas/cargos-recurrentes) .

---

## Tasas y Tarifas


#### Tasas de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios: 112.9%
- Tasa Efectiva Anual (TEA) para compras o pago de servicios en $​: 94.9%
- Tasa Efectiva Anual (TEA) para retiro de efectivo​: 112.9%
- Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 94.9%
- Tasa de interés TCEA Máxima: 112.9%
- Tasa de Interés TCEA MÁXIMA en $: 94.9%

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/ 0 
- Con la Visa Light estás libre del pago de membresía.
- **Seguro desgravamen** 
- Seguro de desgravamen mensual 0.285%​ del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20. 
- Solo aplica para tarjetas emitidas hasta el 31/08/2025. Las tarjetas emitidas posteriormente ya no cuentan con cobertura.
- **Otros gastos** 
- Se cobrará el 3% del monto para operaciones en POS o digitales hechas en el extranjero en moneda diferente al Dólar Americano. 
- (*) Ver más información sobre tasas y tarifas [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.136222385.1876249796.1645454048-994464575.1644356021) .

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo S/ 850.
- Debes estar trabajando al momento de solicitar la tarjeta.
**Y eres trabajador independiente:**
Copia simple de tu documento de identidad. Copia del último recibo de teléfono fijo. Copia de tus tres últimas declaraciones de impuestos (PDT) o copia de tu declaración jurada de Impuesto a la Renta. Copia de tu ficha RUC.
**Y eres trabajador dependiente:**
Copia simple de tu documento de identidad. Copia del último recibo de teléfono fijo. Copia de tus dos últimas boletas de pago.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesitas una copia de tu documento de identidad.
**Si recibes tu sueldo fuera del BCP**

#### Documentación en Canal Digital

No necesitas ningún documento; obtén tu [tarjeta](https://www.mitarjetabcp.viabcp.com/) al instante ingresando a nuestra web con tu número de tarjeta de débito y tu clave de internet haciendo clic [aquí](https://www.mitarjetabcp.viabcp.com/) . La venta está sujeta a evaluación.

---

## Consideraciones


#### Si vas a realizar compras en el extranjero

- Ten en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación. 
 Para más información sobre las tarifas, clic [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.268972401.1876249796.1645454048-994464575.1644356021) .

#### Ten en cuenta que

- Puedes trasladar tu deuda en soles o dólares a cualquiera de las Tarjetas de Crédito del BCP.
- Tus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realizas disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debes comunicarte con nuestra Banca por Teléfono.
- La facturación de tu **Tarjeta de Crédito en el Perú** se realiza en soles, mientras que los consumos efectuados en el exterior se facturan en dólares, excepto en aquellos establecimientos dentro del país que operan en esta moneda.

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 03319-2023.
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/bb20c71a-e34e-4809-a47c-2e30d64b331e/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado_removed.pdf?MOD=AJPERES&CVID=pA.coKY&attachment=false&id=1757702329761)
[Hoja Resumen Tarjeta de Crédito Visa Light](https://www.viabcp.com/wcm/connect/0d87139a-6d4b-4720-8e7d-024fdda116aa/HR_VISA_LIGHT%2B-%2B0712+%281%29.pdf?MOD=AJPERES&CVID=pE89NYc&attachment=false&id=1761073683552)
[Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599503357115)
[Fórmulas y Ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/c585c8bb-67fa-43d1-ac87-9f0c708936e7/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre_sin%2Bdesgravamen.pdf+Visa+Light.pdf?MOD=AJPERES&CVID=pJbzG9s&attachment=false&id=1766499798891)
[VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861) 
 [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
[Contrato de Tarjeta de Crédito – Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599503496559)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/bb20c71a-e34e-4809-a47c-2e30d64b331e/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado_removed.pdf?MOD=AJPERES&CVID=pA.coKY&attachment=false&id=1757702329761)
- [Hoja Resumen Tarjeta de Crédito Visa Light](https://www.viabcp.com/wcm/connect/0d87139a-6d4b-4720-8e7d-024fdda116aa/HR_VISA_LIGHT%2B-%2B0712+%281%29.pdf?MOD=AJPERES&CVID=pE89NYc&attachment=false&id=1761073683552)
- [Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599503357115)
- [Fórmulas y Ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/c585c8bb-67fa-43d1-ac87-9f0c708936e7/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre_sin%2Bdesgravamen.pdf+Visa+Light.pdf?MOD=AJPERES&CVID=pJbzG9s&attachment=false&id=1766499798891)
- [VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861)
- [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
- [Contrato de Tarjeta de Crédito – Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599503496559)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---
