# Tarjeta de Crédito Visa Platinum Qore​

**Conoce los beneficios exclusivos de tu Visa Platinum Qore**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Bono de Puntos Qore:** 3,000 puntos Qore por meta de compras S/1,000 durante los primeros 45 días
- **Beneficios Visa:** Existe un mundo de beneficios **[aquí](https://visabenefitslac.axa-assistance.us/?utm_source=visacom&utm_medium=redirect&utm_campaign=visa&utm_content=esp&pcid=viabcp:tarjetas-visa-clasica-qore-ut-p-z1-pvpbtsjaep0wsxze2w230_axrzaq5dikpfvsvfilsrccfy1f77yqxusk0u12k82cm3pmbhw41zgptcoemyycc-b5veue4jip8jit_9ui6xh5dixie4qteul6wmqv-qixxns3otu9ixzfxoq8hbzlmujyzwg5royzcijjqgkscy-g3xvr7907o1sgqq044f1mpabv5s9a5lcurcbapcjwavwkcpoxnd14pql2ogthihq4mpa9o1z7ppmw_qoyy-g5zy2zvqh-xz_gx_r_vdygv-m3cotn5qmqztqqzi7qe9dav0msd01pnzejxu_a6eafc9lswtgdqkryp3arj6go0od4i-c9vdzux30cvhwpwfrrappmokjom1tndxbwxsje18wmhlmc9pb8wzdrgybekxsvtedd1almheme5fa0t8m7kea8ntrr9vae0xlkpjutk_dgkrqm9yplqq8fflufhfb2q5io07zyzhlt925oxbfxt1xk4huzte3vsfuyytr6bbqpgef-g-zv59f3kveq3q368oqghwtt8xayorcfenjs1a-:beneficios-visa:masivo:beneficios-de-tu%C2%A0tarjeta-visa%C2%A0-aqui)**
- **Acumulación Puntos Qore:** Hasta 1.5 Puntos Qore por cada USD 1 de consumo

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Beneficios Visa

- Visa Airport Companion
- Visa Luxury Hotel Collection
- Servicios Médicos de Emergencia Internacional
- Visa Concierge
- Visa Digital Concierge
- Visa Médico Online
- COVID Línea de Ayuda
- Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Asistencia

- Visa Médico Online.
- COVID Línea de Ayuda.
- Servicios de Asistencia Internacional Visa 24x7 (Desembolso de efectivo, Reemplazo de tarjetas).
- Visa Concierge.
- Visa Digital Concierge.
Conoce más [aquí](https://www.visa.com/portalbeneficios) . 
 (*) Sólo aplica para casos internacionales

#### Beneficios Especiales

- GibSky
- Delivery gratis a donde quieras​
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Seguros

- **Seguros de compras** 
- Seguro de Protección de Compra 
- Seguro de Protección de Precio 
- Garantía Extendida
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) . 
 Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Visa.

#### Campañas exclusivas

- **Campañas multiplicadoras y sorteos de puntos.​**
Podrás participar en campañas exclusivas de Tarjeta de Crédito BCP y ganar puntos Qore para canjear productos/servicios. Para ello es importante que tengas tus datos actualizados​
(*) Las campañas exclusivas y alianzas son temporales.

#### Beneficios adicionales

- **Solicita tu Préstamo Tarjetero**
Obtén liquidez al instante desde tu Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslada tu deuda**
Libérate de las preocupaciones y reorganiza tus deudas.
- **Solicita una Tarjeta Adicional Gratis**
Solicita adicionales sin costo y comparte tu línea de crédito. [Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplía tu línea de crédito**
Solicita un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesitas un aumento mayor, acércate a cualquiera de nuestras agencias. 
 (*) Sujeto a evaluación.
- **Mejora tu tarjeta**
Se conoce como “Upgrade”. Puedes cambiar tu tarjeta por otra con beneficios adicionales. 
 (*) Sujeto a evaluación.
- **Cuenta Sueldo**
Si eres cliente Cuenta Sueldo, podrás disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas. 
 Conoce los Beneficios Cuenta Sueldo [aquí](https://www.viabcp.com/beneficios/todos-los-beneficios) .

#### ¡Afíliate a Cargos recurrentes!

- Realiza tus pagos de manera automática con tu Tarjeta de Crédito BCP Qore.
- Paga todos tus pendientes sin tener que ir al banco ni ingresar a la web. Solo debes registrarte con tu Clave de Internet y tus pagos se harán de manera automática y sencilla.
- Puedes suspender hasta dos cargos seguidos. ¡No te preocupes!, puedes desafiliarte cuando quieras.
- Podrás acumular Punto Qore según el tipo de tarjeta que tengas.
- Conoce más beneficios y cómo hacerlo [aquí](https://www.viabcp.com/tarjetas/cargos-recurrentes)

---

## Qore


#### Bono de Bienvenida

- Recibe un bono de 3,000 Puntos Qore por una meta mínima de compras de S/1,000 en consumos por POS o por internet durante los primeros 45 días desde la aprobación de tu tarjeta de crédito.

#### Acumula Puntos Qore

- Acumule 1.5 Puntos Qore por $1 consumido en restaurantes
- Acumule 1.5 puntos por $1 consumido en supermercados y grifos.
- Acumule 1 punto por $1 consumido en los demás rubros de consumo.
- 1 Punto Qore por $1 en otros consumos.
- [Consideraciones del programa Puntos Visa Platinum Qore](https://www.viabcp.com/wcm/connect/0d7f08bd-56e3-429c-97a3-7c5df639eec3/Pauta+Puntos+Platinum+Latam+Qore+%281%29.pdf?MOD=AJPERES&CVID=pHb1z1X&attachment=false&id=1764348781654)

#### Beneficios exclusivos

- **Descuentos Qore:** Disfrute de una variedad de establecimientos físicos y virtuales en donde podrá hacer uso de sus descuentos.​
- **Acumulación y Canje de Puntos Qore:** Acumule Puntos Qore y disfrútelos canjeando productos y servicios exclusivos.​
- **Acumulación adicional por Nivel:** Podrá acumular Puntos Qore adicionales a los acumulados como base ($1 = 1 Punto) según el nivel al que pertenezca (Nivel 5: +20%, Nivel 4: 10%, Nivel 3: 5%).
Conoce más sobre los beneficios de Qore ​ [aquí ​](https://www.viabcp.com/qore)
La acumulación, canje, uso y demás condiciones a los beneficios otorgados por las tarjetas BCP Qore se rigen bajo los términos y condiciones del programa publicados ​ [aqui​](https://www.viabcp.com/qore) .

---

## Tasas y Tarifas


#### Tasas de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios: 57.0%-95.9% 
 Tasa Efectiva Anual (TEA) para compras o pago de servicios en $: 57.0%-76.9% 
 Tasa Efectiva Anual (TEA) para retiro de efectivo: 107% 
 Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 85.90% 
 Tasas de Interés TCEA Máxima: 171.14% 
 Tasa de Interés TCEA Máxima en $: 76.90%

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/ 350 
- ¡Exonérate del pago de membresía! Solo si consumes todos los meses y el consumo promedio de 12 meses es igual o mayor a S/3,500 (aplica para venta de nuevas tarjetas).
- **Seguro desgravamen** 
- Seguro de desgravamen mensual 0.285% del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20
- **Otros gastos** 
- Se cobrará el 3% del monto para operaciones en POS o digitales hechas en el extranjero en moneda diferente al Dólar Americano. 
- (*) Ver más información sobre Tasas y Tarifas [aquí](https://www.viabcp.com/tasasytarifas) .

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo S/ 5,000.
- Debes estar laborando al momento de solicitar la tarjeta.

#### Documentación en Canal Digital

- No necesitas ningún documento; obtén tu tarjeta al instante ingresando a nuestra web con tu número de tarjeta de débito y tu clave de internet haciendo clic [aquí](https://www.mitarjetabcp.viabcp.com/) .
- La venta está sujeta a evaluación.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesitas una copia de tu documento de identidad.
**Si recibes tu sueldo fuera del BCP**
- **Y eres trabajador dependiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus dos últimas boletas de pago.
- **Y eres trabajador independiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus tres últimas declaraciones de impuestos (PDT) o copia de tu declaración jurada de Impuesto a la Renta. 
- Copia de tu ficha RUC.

---

## Consideraciones


#### ¡Tu eliges cómo asegurarte!

Puedes optar por las siguientes alternativas para asegurarte:
- Elegir la contratación del seguro ofrecido por el BCP.
- Contratar un seguro a través de un corredor de seguros. Este deberá cumplir con las condiciones previamente informadas en el certificado o póliza de seguros.

#### Si vas a realizar compras en el extranjero

- Ten en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación. 
 Para más información sobre las tarifas, clic [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.264576399.1876249796.1645454048-994464575.1644356021) .

#### Sobre el programa Qore​

- Las disposiciones de efectivo, traslados de deuda, préstamo tarjetero, consumos en casinos, pagos de servicios realizados en Banca por Internet o en Banca Móvil, débitos automáticos, pagos de impuestos y servicios legales no acumulan Puntos Qore.
- A partir del 1 de abril del 2024 los clientes que tengan mora mayor a 8 días en el pago de la cuota de su Tarjeta de Crédito BCP, no podrán acumular puntos Qore por los consumos generados a partir del día 9 de mora hasta que se regularice la deuda inclusive. Recién podrá acumular por aquellos consumos realizados a partir del día siguiente después de realizado el pago de su cuota.​​​

#### Ten en cuenta que

- Puedes trasladar tu deuda en soles o dólares a cualquiera de las Tarjetas de Crédito del BCP.
- Tus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realizas disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debes comunicarte con nuestra Banca por Teléfono.
- Recibes la facturación de tus consumos en el Perú en soles y la de los que realizas en el exterior, en dólares (a excepción de los consumos en los establecimientos en el Perú que facturan en dólares).

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 01697-2023.
[Hoja Resumen Visa Platinum BCP Qore](https://www.viabcp.com/wcm/connect/9156a87d-9b50-4b72-a87c-2d1dadc21ed1/HR_VISA_LATAM_PLATINUM+QORE_+%281%29.pdf?MOD=AJPERES&CVID=pHb1oUP&attachment=false&id=1764350359986)
[Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
[Cronograma de pagos 2025](https://www.viabcp.com/wcm/connect/9505b989-ff44-4e58-a314-46bb5dd7ef81/VISA+Cronograma+de+Pagos+2025+1.pdf?MOD=AJPERES&CVID=pl8oRE9&attachment=false&id=1740676683683)
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599253074480)
[Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ab50db33-0620-44bc-97bc-3366042f57fa/F%C3%B3rmulas%2BTarjetas_de_Cr%C3%A9dito_Noviembre.pdf?MOD=AJPERES&CVID=pdJVTVl&attachment=false&id=1732716151742)
[Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599255393231)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Hoja Resumen Visa Platinum BCP Qore](https://www.viabcp.com/wcm/connect/9156a87d-9b50-4b72-a87c-2d1dadc21ed1/HR_VISA_LATAM_PLATINUM+QORE_+%281%29.pdf?MOD=AJPERES&CVID=pHb1oUP&attachment=false&id=1764350359986)
- [Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
- [Cronograma de pagos 2025](https://www.viabcp.com/wcm/connect/9505b989-ff44-4e58-a314-46bb5dd7ef81/VISA+Cronograma+de+Pagos+2025+1.pdf?MOD=AJPERES&CVID=pl8oRE9&attachment=false&id=1740676683683)
- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599253074480)
- [Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ab50db33-0620-44bc-97bc-3366042f57fa/F%C3%B3rmulas%2BTarjetas_de_Cr%C3%A9dito_Noviembre.pdf?MOD=AJPERES&CVID=pdJVTVl&attachment=false&id=1732716151742)
- [Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599255393231)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---

## Preguntas Frecuentes

**¿Qué es una tarjeta VISA Platinum Qore​?**
Es una tarjeta de crédito emitida por el Banco de Crédito del Perú (BCP) que ofrece beneficios exclusivos como acumulación de puntos Qore, cuotas sin intereses en establecimientos seleccionados y más.​

**¿Cómo tener la tarjeta VISA Platinum Qore​?**
Para obtener una tarjeta dorada BCP debes completar el proceso de solicitud correspondiente mediante la web [www.mitarjetabcp.viabcp.com](https://www.mitarjetabcp.viabcp.com/) o desde tu app Banca Móvil BCP. La oferta se encuentra sujeta a evaluación crediticia.

**Requisitos para solicitar VISA Platinum Qore​**
- Ingreso mensual mínimo S/ 1,800. 
- Debes estar laborando al momento de solicitar la tarjeta.

**Beneficios de la tarjeta VISA Platinum Qore​**
- Bono de 3000 Puntos Qore​ 
- Acumulación de puntos 
- Visa Airport Companion 
- Hasta 24 cuotas sin intereses en + 4,000 establecimientos​
