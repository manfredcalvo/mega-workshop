# Gana S/ 150 para tuscompras del Cyber

**Solo pide tu tarjeta de crédito y listo.**

**Página:** https://www.viabcp.com/tarjetas/tarjetas-credito

---

## Tarjetas Disponibles

### [AMEX Clásica LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- Membresía anual S/80(GRATIS si consumes S/1 al mes)
- 1 Milla acumuladapor cada 2 USD que consumas.
- Campañas multiplicadorasde Millas
- S/ 150 de descuentode lunes a viernes en restaurantes seleccionados

### AMEX Clásica LATAM Pass


### [AMEX Oro LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- Membresía anual S/170(GRATIS si consumes S/1 al mes)
- 1 Millaacumuladapor cada 1.5 USD que consumas
- Campañas multiplicadorasde Millas
- S/ 150 de descuentode lunes a viernes en restaurantes seleccionados

### AMEX Oro LATAM Pass


### [AMEX Platinum LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- 3,000 Millasde bienvenida
- Membresía anual S/350(GRATIS si consumes S/1,200 al mes)
- 1 Milla acumuladapor cada 1 USD que consumas.
- S/ 150 de descuento y postre de cortesíade lunes a viernes en restaurantes seleccionados.

### AMEX Platinum LATAM Pass


### [AMEX Black LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- 6,000 Millasde bienvenida
- Membresía anual S/400(GRATIS si consumes S/3,500 al mes)
- 1.5 Millas acumuladapor cada 1 USD que consumas.
- Priority Pass+ 2 invitados
- S/ 150 de descuento y postre de cortesíade lunes a viernes en restaurantes seleccionados.

### AMEX Black LATAM Pass


### [Visa Clásica LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- Membresía anual S/80(GRATIS si consumes S/1 al mes)
- 1 Milla acumuladapor cada 2 USD que consumas.
- Campañas multiplicadorasde Millas
- Delivery gratisa donde quieras​

### Visa Clásica LATAM Pass


### [Visa Oro LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- Membresía anual S/170(GRATIS si consumes S/1 al mes)
- 1 Milla acumuladapor cada 1.5 USD que consumas
- Campañas multiplicadorasde Millas
- Delivery gratisa donde quieras​

### Visa Oro LATAM Pass


### [Visa Platinum LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- 3,000 Millasde bienvenida
- Membresía anual S/350(GRATIS si consumes S/1,200 al mes)
- 1 Milla acumuladapor cada 1 USD que consumas
- Delivery gratisa donde quieras​

### Visa Platinum LATAM Pass


### [Visa Signature LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- 6,000 Millasde bienvenida
- Membresía anual S/400(GRATIS si consumes S/3,500 al mes)
- 1.25 Millas acumuladapor cada 1 USD que consumas
- Priority Pass+ 2 invitados
- Delivery gratisa donde quieras​

### Visa Signature LATAM Pass


### [Visa Infinite Sapphire LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- 10,000 Millasde bienvenida
- Membresía anual S/450(GRATIS si consumes S/4,500 al mes). (Sujeto a Términos y condiciones)
- Hasta 1.5 Millas acumuladaspor cada 1 USD de consumo
- Priority Pass+ 3 invitados
- Delivery gratisa donde quieras​

### Visa Infinite Sapphire LATAM Pass


### [Visa Infinite Iridium LATAM Pass](https://www.mitarjetabcp.viabcp.com)

- 15,000 Millasde bienvenida
- Membresía anual S/500(GRATIS si consumes S/5,000 al mes).(Sujeto a Términos y condiciones)
- Hasta 2 Millas acumuladapor cada 1 USD de consumo.
- Priority Pass+ 4 invitados
- Delivery gratisa donde quieras​

### Visa Infinite Iridium LATAM Pass


### [Visa Clásica Qore](https://www.mitarjetabcp.viabcp.com)

- Paga tu tarjetacon Puntos Qore
- Consume S/ 1 al mes yno pagues membresía
- 1 punto Qorepor cada 2USD de consumo
- Hasta24 Cuotas Sin Interesesen más de 4000 establecimientos
- Entrega gratuitade tu tarjeta donde estés

### Visa Clásica Qore


### [Visa Oro Qore](https://www.mitarjetabcp.viabcp.com)

- Paga tu tarjetacon Puntos Qore
- Consume S/ 1 al mes yno pagues membresía
- 1 Punto Qorepor cada 1USD de consumo
- Hasta24 Cuotas Sin Interesesen más de 4000 establecimientos
- Entrega gratuitade tu tarjeta donde estés

### Visa Oro Qore


### [Visa Platinum Qore](https://www.mitarjetabcp.viabcp.com)

- Paga tu tarjetacon Puntos Qore
- 3,000Puntos Qore
- Membresía anual S/ 350(GRATIS si consumes S/1,200 al mes)
- Hasta 1.5 Puntos Qoreacumulados por cada 1USD que consumas​
- Delivery gratisa donde quieras​

### Visa Platinum Qore


### [Visa Clásica](https://www.mitarjetabcp.viabcp.com)

- Campañas de Cashback
- Membresía anual S/80(GRATIS si consumes S/50 al mes)
- Delivery gratisa donde quieras​

### Visa Clásica


### [Visa Signature Qore](https://www.mitarjetabcp.viabcp.com)

- Paga tu tarjetacon Puntos Qore
- 6,000 Puntos Qore
- Membresía anual S/400(GRATIS si consumes S/3,500 al mes)
- Hasta 2.5 Puntos Qoreacumulados por cada 1USD que consumas​
- Priority Pass+ 2 invitados
- Delivery gratisa donde quieras​

### Visa Signature Qore


### [Visa Infinite Qore](https://www.mitarjetabcp.viabcp.com)

- Paga tu tarjetacon Puntos Qore
- 15,000 Puntos Qore
- Membresía anual S/500(GRATIS si consumes S/5,000 al mes).(Sujeto a Términos y condiciones)
- Hasta 3 Puntos Qore acumuladospor cada 1USD que consumas
- Priority Pass+ 4 invitados
- Delivery gratisa donde quieras​

### Visa Infinite Qore


### [Visa Light](https://www.mitarjetabcp.viabcp.com)

- Sin consumomínimo
- Membresía anualGRATIS
- Delivery gratisa donde quieras​

### Visa Light


### [Visa iO](https://www.io.pe/)

- Tarjeta de Crédito digital y física.
- Membresía cero: ni mensual, ni anual.
- Acumula cashback por tus compras.
- Accede a descuentos exclusivos.

### Visa iO


## Preguntas Frecuentes

**¿Qué es una Tarjeta de Crédito?**
Una tarjeta de crédito es una herramienta que te permite comprar ahora y pagar después. Al usarla, accedes a un monto de dinero que el BCP pone a tu disposición, conocido como línea de crédito. Es como tener un respaldo para cubrir tus gastos sin necesidad de desembolsar efectivo al instante. [Solicita tu Tarjeta de Crédito aquí.](https://www.viabcp.com/solicitar-tarjeta)

**¿Cómo saber si tengo Tarjeta de Crédito aprobada?**
Para [saber si tienes una tarjeta de crédito preaprobada](https://www.viabcp.com/ayuda-bcp/tarjetas/como-saber-tengo-tarjeta-credito-pre-aprobada) , ingresa a [https://www.mitarjetabcp.viabcp.com/](https://www.mitarjetabcp.viabcp.com/) 
1. Da clic en el botón “Adquiérela hoy” 
2. Ingresa tu DNI 
3. Selecciona identificarte con tu Clave 6 o con reconocimiento facial 
4. Valida tu número de celular 
5. ¡Listo! Podrás validar si tienes una Tarjeta de Crédito aprobada

**¿Cómo acceder a una mejor Tarjeta de Crédito?**
Para acceder a una mejor tarjeta de crédito según el BCP, es importante seguir algunos pasos clave. En primer lugar, mantén un historial crediticio sólido y puntual en tus pagos, ya que esto demuestra responsabilidad financiera. Además, mantener un nivel de ingresos adecuado y estable también es importante para calificar para una tarjeta de crédito de mayor categoría. Otra opción es mejorar tu relación con el banco, utilizando y demostrando un buen uso de una tarjeta de crédito actual del BCP. Si cumples con estos requisitos, es posible que puedas solicitar un upgrade a una tarjeta de crédito de mayor nivel y acceder a beneficios y características adicionales. Recuerda siempre revisar los requisitos y condiciones específicas del BCP para cada tipo de tarjeta de crédito.

**¿Qué tipos de Tarjetas de Crédito existen?**
Existen los siguientes [tipos de tarjetas de crédito](https://www.viabcp.com/ayuda-bcp/tarjetas/cuales-son-tipos-tarjeta-credito) : Tarjetas Visa 
1. [Visa Clásica](https://www.viabcp.com/tarjetas/credito-visa-clasica) 
2. [Visa Clásica Latam Pass](https://www.viabcp.com/tarjetas/visa-latampass-clasica) 
3. [Visa Oro Latam Pass](https://www.viabcp.com/tarjetas/visa-latampass-oro) 
4. [Visa Platinum Latam Pass](https://www.viabcp.com/tarjetas/visa-latampass-platinum) 
5. [Visa Signature Latam Pass](https://www.viabcp.com/tarjetas/visa-latampass-signature) 
6. [Visa Infinite Sapphire Latam Pass](https://www.viabcp.com/tarjetas/sapphire) 
7. [Visa Infinite Iridium LATAM Pass](https://www.viabcp.com/tarjetas/visa-latampass-infinite) [Tarjetas American Express](https://www.viabcp.com/tarjetas/tarjetas-credito-amex) 
1. [American Express Clásica Latam Pass](https://www.viabcp.com/tarjetas/american-express-clasica) 
2. [American Express Oro Latam Pass](https://www.viabcp.com/tarjetas/american-express-gold) 
3. [American Express Platinum Latam Pass](https://www.viabcp.com/tarjetas/american-express-platinum) 
4. [American Express Black Latam Pass](https://www.viabcp.com/tarjetas/american-express-clasica)
