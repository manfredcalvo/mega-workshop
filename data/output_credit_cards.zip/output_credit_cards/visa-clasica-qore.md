# Tarjeta de Crédito Visa Clásica Qore

**Conoce los beneficios exclusivos de tu Visa Clásica Qore**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Beneficios Visa:** Existe un mundo de beneficios **[aquí](https://visabenefitslac.axa-assistance.us/?utm_source=visacom&utm_medium=redirect&utm_campaign=visa&utm_content=esp&pcid=viabcp:tarjetas-visa-clasica-qore:beneficios-visa:masivo:beneficios-de-tu%C2%A0tarjeta-visa%C2%A0-aqui)**
- **Compra en Cuotas Sin Intereses:** Realiza tus compras hasta en 24 cuotas **[aquí](https://www.viabcp.com/beneficios/cuotas-sin-intereses?pcid=viabcp:tarjetas-visa-clasica-qore:compra-en-cuotas-sin-intereses:masivo:beneficios-de-tu%C2%A0tarjeta-visa%C2%A0-aqui)**
- **Acumula Puntos Qore​:** 1 punto Qore por cada USD 2 de consumo

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Beneficios Visa

- **Asistencia**
Servicio de Asistencia Internacional Visa 24x7 (desembolso de efectivo y reemplazo de tarjetas). Conoce más [aquí](http://www.visa.com/portalbeneficios) .
(*) Sólo aplica para casos internacionales

#### Beneficios Especiales

- **Delivery gratis a donde quieras​**

#### Seguros

- **Seguros de compras**
Seguro de Protección de Precio. Conoce más sobre los términos y condiciones [aquí](http://www.visa.com/portalbeneficios) . 
 (*) Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Visa.

#### Campañas exclusivas

- **Campañas multiplicadoras y sorteos de puntos.​**
Podrás participar en campañas exclusivas de Tarjeta de Crédito BCP y ganar puntos Qore para canjear productos/servicios. Para ello es importante que tengas tus datos actualizados​
(*) Las campañas exclusivas y alianzas son temporales.

#### Beneficios adicionales

- **Solicita tu Préstamo Tarjetero**
Obtén liquidez al instante desde tu Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslada tu deuda**
Libérate de las preocupaciones y reorganiza tus deudas.
- **Solicita una Tarjeta Adicional Gratis**
Solicita adicionales sin costo y comparte tu línea de crédito. [Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplía tu línea de crédito**
Solicita un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesitas un aumento mayor, acércate a cualquiera de nuestras agencias. 
 (*) Sujeto a evaluación.
- **Mejora tu tarjeta**
Se conoce como “Upgrade”. Puedes cambiar tu tarjeta por otra con beneficios adicionales. 
 (*) Sujeto a evaluación.
- **Cuenta Sueldo**
Si eres cliente Cuenta Sueldo, podrás disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas. 
 Conoce los Beneficios Cuenta Sueldo [aquí](https://www.viabcp.com/beneficios/todos-los-beneficios) .

#### ¡Afíliate a Cargos recurrentes!

- Realiza tus pagos de manera automática con tu Tarjeta de Crédito BCP Qore.
- Paga todos tus pendientes sin tener que ir al banco ni ingresar a la web. Solo debes registrarte con tu Clave de Internet y tus pagos se harán de manera automática y sencilla.
- Puedes suspender hasta dos cargos seguidos. ¡No te preocupes!, puedes desafiliarte cuando quieras.
- Podrás acumular Punto Qore según el tipo de tarjeta que tengas.
- Conoce más beneficios y cómo hacerlo [aquí](https://www.viabcp.com/tarjetas/cargos-recurrentes)

---

## Qore


#### Acumula Puntos Qore

- 1 Punto Qore por cada USD 2 de consumo​.

#### Consideraciones

- [Consideraciones del programa Puntos Visa Clásica Qore](https://www.viabcp.com/wcm/connect/07a96c19-7ef2-4c12-9e2d-17f552573ace/Pauta+Puntos+Clasica+Latam+Qore+%281%29.pdf?MOD=AJPERES&CVID=pHb1Fdq&attachment=false&id=1764342942967)

#### Beneficios exclusivos

- **Descuentos Qore:** Disfrute de una variedad de establecimientos físicos y virtuales en donde podrá hacer uso de sus descuentos.​
- **Acumulación y Canje de Puntos Qore:** Acumule Puntos Qore y disfrútelos canjeando productos y servicios exclusivos.​
- **Acumulación adicional por Nivel:** Podrá acumular Puntos Qore adicionales a los acumulados como base ($2 = 1 Punto) según el nivel al que pertenezca (Nivel 5: +20%, Nivel 4: 10%, Nivel 3: 5%)
(*) Conoce más sobre los beneficios de Qore ​ [aquí ​](https://www.viabcp.com/qore)
La acumulación, canje, uso y demás condiciones a los beneficios otorgados por las tarjetas BCP Qore se rigen bajo los términos y condiciones del programa publicados [aquí](https://www.viabcp.com/qore) .

---

## Tasas y Tarifas


#### Tasas de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios: 83.4%-95.9% 
 Tasa Efectiva Anual (TEA) para compras o pago de servicios en $: 76.90% 
 Tasa Efectiva Anual (TEA) para retiro de efectivo: 107% 
 Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 85.90% 
 Tasas de Interés TCEA Máxima: 118.64% 
 Tasa de Interés TCEA Máxima en $: 76.90%

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/ 80. 
- ¡Exonérate del pago de membresía! 
- Solo si consumes todos los meses y el consumo promedio de 12 meses es igual o mayor a S/ 1 (aplica para venta de nuevas tarjetas).
- **Seguro desgravamen** 
- Seguro de desgravamen mensual 0.285% del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20.
- **Otros gastos** 
- Se cobrará el 3% del monto para operaciones en POS o digitales hechas en el extranjero en moneda diferente al Dólar Americano. 
- (*) Ver más información sobre Tasas y Tarifas **[aquí](https://www.viabcp.com/tasasytarifas) .**

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo S/ 1,800.
- Debes estar laborando al momento de solicitar la tarjeta.

#### Documentación en Canal Digital

- No necesitas ningún documento; obtén tu tarjeta al instante ingresando a nuestra web con tu número de tarjeta de débito y tu clave de internet haciendo clic [aquí](https://www.mitarjetabcp.viabcp.com/) .
- La venta está sujeta a evaluación.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesitas una copia de tu documento de identidad.
**Si recibes tu sueldo fuera del BCP**
- **Y eres trabajador dependiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus dos últimas boletas de pago.
- **Y eres trabajador independiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus tres últimas declaraciones de impuestos (PDT) o copia de tu declaración jurada de Impuesto a la Renta. 
- Copia de tu ficha RUC.

---

## Consideraciones


#### ¡Tu eliges cómo asegurarte!

Puedes optar por las siguientes alternativas para asegurarte:
- Elegir la contratación del seguro ofrecido por el BCP.
- Contratar un seguro a través de un corredor de seguros. Este deberá cumplir con las condiciones previamente informadas en el certificado o póliza de seguros.

#### Si vas a realizar compras en el extranjero

- Ten en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación. 
 Para más información sobre las tarifas, clic [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.136222385.1876249796.1645454048-994464575.1644356021) .

#### Sobre el Programa Qore​

- Las disposiciones de efectivo, traslados de deuda, préstamo tarjetero, consumos en casinos, pagos de servicios realizados en Banca por Internet o en Banca Móvil, débitos automáticos, pagos de impuestos y servicios legales no acumulan Puntos Qore.
- A partir del 1 de abril del 2024 los clientes que tengan mora mayor a 8 días en el pago de la cuota de su Tarjeta de Crédito BCP, no podrán acumular puntos Qore por los consumos generados a partir del día 9 de mora hasta que se regularice la deuda inclusive. Recién podrá acumular por aquellos consumos realizados a partir del día siguiente después de realizado el pago de su cuota.​

#### Ten en cuenta que

- Puedes trasladar tu deuda en soles o dólares a cualquiera de las Tarjetas de Crédito del BCP.
- Tus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realizas disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debes comunicarte con nuestra Banca por Teléfono.
- Recibes la facturación de tus consumos en el Perú en soles y la de los que realizas en el exterior, en dólares (a excepción de los consumos en los establecimientos en el Perú que facturan en dólares).

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 01697-2023.
[Hoja Resumen Visa Clásica BCP Qore](https://www.viabcp.com/wcm/connect/ff4fcf9c-6209-431f-9a41-c64711db8de8/HR_VISA_LATAM_CLASICA+QORE+%281%29.pdf?MOD=AJPERES&CVID=pOly8s2&attachment=false&id=1772035281955)
[Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
[Cronograma de pagos 2025](https://www.viabcp.com/wcm/connect/9505b989-ff44-4e58-a314-46bb5dd7ef81/VISA+Cronograma+de+Pagos+2025+1.pdf?MOD=AJPERES&CVID=pl8oRE9&attachment=false&id=1740676683683)
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599253074480)
[Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ab50db33-0620-44bc-97bc-3366042f57fa/F%C3%B3rmulas%2BTarjetas_de_Cr%C3%A9dito_Noviembre.pdf?MOD=AJPERES&CVID=pdJVTVl&attachment=false&id=1732716151742)
[Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599253334626)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Hoja Resumen Visa Clásica BCP Qore](https://www.viabcp.com/wcm/connect/ff4fcf9c-6209-431f-9a41-c64711db8de8/HR_VISA_LATAM_CLASICA+QORE+%281%29.pdf?MOD=AJPERES&CVID=pOly8s2&attachment=false&id=1772035281955)
- [Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
- [Cronograma de pagos 2025](https://www.viabcp.com/wcm/connect/9505b989-ff44-4e58-a314-46bb5dd7ef81/VISA+Cronograma+de+Pagos+2025+1.pdf?MOD=AJPERES&CVID=pl8oRE9&attachment=false&id=1740676683683)
- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599253074480)
- [Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ab50db33-0620-44bc-97bc-3366042f57fa/F%C3%B3rmulas%2BTarjetas_de_Cr%C3%A9dito_Noviembre.pdf?MOD=AJPERES&CVID=pdJVTVl&attachment=false&id=1732716151742)
- [Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599253334626)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---

## Preguntas Frecuentes

**¿Qué es una tarjeta Visa Clásica Qore?**
Es una tarjeta de crédito emitida por el Banco de Crédito del Perú (BCP) que ofrece beneficios exclusivos como acumulación de puntos Qore, cuotas sin intereses en establecimientos seleccionados y más.​

**¿Cómo tener la tarjeta Visa Clásica Qore?**
Para obtener una tarjeta dorada BCP debes completar el proceso de solicitud correspondiente mediante la web [www.mitarjetabcp.viabcp.com](https://www.mitarjetabcp.viabcp.com/) o desde tu app Banca Móvil BCP. La oferta se encuentra sujeta a evaluación crediticia.

**Requisitos para solicitar Visa Clásica Qore del BCP**
- Ingreso mensual mínimo S/ 1,800. 
- Debes estar laborando al momento de solicitar la tarjeta.

**Beneficios de la Tarjeta Visa Clásica Qore​**
- Exoneración de membresía por un consumo mínimo de S/1 al mes. 
- Acumulación de Puntos Qore 
- Hasta 24 cuotas sin intereses en + 4,000 establecimientos​
