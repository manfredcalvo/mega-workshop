# Tarjeta de Crédito Visa Signature Qore

**Conoce los beneficios exclusivos de tu Visa Signature Qore**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Bono de Puntos Qore​:** 6,000 Puntos Qore por meta de compras de S/ 5,000 durante los primeros 90 días​
- **Priority Pass:** Acceso a salones VIP con 2 invitados.
- **Acumula Puntos Qore​:** Hasta 2.5 Puntos Qore por cada USD 1 de consumo​

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Beneficios Visa Signature Qore

- Visa Airport Companion
- Visa Luxury Hotel Collection
- Servicios Médicos de Emergencia Internacional
- Visa Concierge
- Visa Digital Concierge
- Visa Médico Online
- COVID Línea de Ayuda
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Asistencia

- Visa Médico Online.
- COVID Línea de Ayuda.
- Servicios de Asistencia Internacional Visa 24x7 (Desembolso de efectivo, Reemplazo de tarjetas).
- Visa Concierge.
- Visa Digital Concierge.
- Conoce más [aquí](https://www.visa.com/portalbeneficios) .
(*) Sólo aplica para casos internacionales

#### Priority Pass

- Accede a más de 1400 Salas VIP* en más de 1000 ciudades de 189 países.
- [Conoce las condiciones aquí](https://www.viabcp.com/wcm/connect/c780e6ee-1fc3-4f79-a005-f9ad600b548d/BCP_Priority+Pass+Signature+Qore.pdf?MOD=AJPERES&CVID=pkAZJy7&attachment=false&id=1740083316785)
Para mayor información sobre el beneficios ingresar aquí: [https://www.viabcp.com/beneficios/tarjetas](https://www.viabcp.com/beneficios/tarjetas)
**Nuevo Aeropuerto Jorge Chávez:** Accede a los establecimientos y salas de la zona internacional, como La Bonbonniere, Bleirot Bar & Lounge y la sala VIP The Club LIM.
**El restaurante TGI Fridays ubicado en la zona nacional del aeropuerto no está incluido dentro de los beneficios Priority Pass ofrecidos por el BCP. El acceso a establecimientos o salas en zonas nacionales con Priority Pass tiene un costo de USD 32 por persona.*

#### Beneficios adicionales

- Delivery gratis a donde quieras​
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Seguros

- **Seguros de viaje** 
- Seguro de alquiler de vehículos. 
- Seguro de inconvenientes en viajes (Demora de Equipaje y/o pérdida de Equipaje).
- **Seguros de compras** 
- Seguro de Protección de Compra. 
- Seguro de Protección de Precio. 
- Garantía Extendida.
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) . 
 Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Visa.

#### Campañas exclusivas

- **Campañas multiplicadoras y sorteos de puntos.**
Podrás participar en campañas exclusivas de Tarjeta de Crédito BCP y ganar puntos Qore para canjear productos/servicios. Para ello es importante que tengas tus datos actualizados.
(*) Las campañas campañas exclusivas y alianzas son temporales.

#### Beneficios adicionales

- **Solicita tu Préstamo Tarjetero**
Obtén liquidez al instante desde tu Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslada tu deuda**
Libérate de las preocupaciones y reorganiza tus deudas.
- **Solicita una Tarjeta Adicional Gratis**
Solicita adicionales sin costo y comparte tu línea de crédito.
[Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplía tu línea de crédito**
Solicita un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesitas un aumento mayor, acércate a cualquiera de nuestras agencias. 
 (*) Sujeto a evaluación.
- **Mejora tu tarjeta**
Se conoce como “Upgrade”. Puedes cambiar tu tarjeta por otra con beneficios adicionales. 
 (*) Sujeto a evaluación.
- **Cuenta Sueldo**
Si eres cliente Cuenta Sueldo, podrás disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas.
Conoce los Beneficios Cuenta Sueldo [aquí](https://www.viabcp.com/beneficios/todos-los-beneficios) .

#### ¡Afíliate a Cargos recurrentes!

- Realiza tus pagos de manera automática con tu Tarjeta de Crédito VISA BCP QORE​.
- Paga todos tus pendientes sin tener que ir al banco ni ingresar a la web. Solo debes registrarte con tu Clave de Internet y tus pagos se harán de manera automática y sencilla.
- Puedes suspender hasta dos cargos seguidos. ¡No te preocupes!, puedes desafiliarte cuando quieras.
- Podrás acumular Puntos Qore según el tipo de tarjeta que tengas​,
- Conoce más beneficios y cómo hacerlo [aquí.](https://www.viabcp.com/tarjetas/cargos-recurrentes)

---

## Qore


#### Bono de bienvenida

- Recibe un bono de 6,000 Puntos Qore por una meta mínima de compras de S/5,000 en consumos por POS o por internet durante los primeros 90 días desde la aprobación de tu tarjeta de crédito..

#### Acumule Puntos Qore​

- Acumule 2.5 Puntos Qore por $1 consumido en restaurantes​
- Acumule 2 puntos por $1 consumido en supermercados y grifos ​
- Acumule 1 punto por $1 consumido en los demás rubros de consumo.
- 1 Punto Qore por US$1 en otros consumos​
- [Consideraciones del programa Qore](https://www.viabcp.com/wcm/connect/c2161748-b362-43a0-8325-23ebb7b663a4/Pauta+Puntos+Signature+Qore.pdf?MOD=AJPERES&CVID=pkzyi35&attachment=false&id=1740058015668)

#### Beneficios Exclusivos

- **Descuentos Qore:** Disfrute de una variedad de establecimientos físicos y virtuales en donde podrá hacer uso de sus descuentos.​
- **Acumulación y Canje de Puntos Qore:** Acumule Puntos Qore y disfrútelos canjeando productos y servicios exclusivos.​
- **Acumulación adicional por Nivel:** Podrá acumular Puntos Qore adicionales a los acumulados como base ($1 = 1 Punto) según el nivel al que pertenezca (Nivel 5: +20%, Nivel 4: 10%, Nivel 3: 5%).
Conoce más sobre los beneficios de Qore ​ [aquí ​](https://www.viabcp.com/qore)
La acumulación, canje, uso y demás condiciones a los beneficios otorgados por las tarjetas BCP Qore se rigen bajo los términos y condiciones del programa publicados ​ [aqui​](https://www.viabcp.com/qore) .

---

## Tasas y Tarifas


#### Tasa de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios: 49.00% - 95.90%
- Tasa Efectiva Anual (TEA) para compras o pago de servicios en $: 49.00% - 76.90%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo: 95.9%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 76.90%​
- Tasa de interés TCEA Máxima: 180.53%
- Tasa de Interés TCEA MÁXIMA en $: 76.90%​

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/ 400 
- ¡Exonérate del pago de membresía! Solo si consumes todos los meses y el consumo promedio de 12 meses es igual o mayor a S/3,500 (aplica para venta de nuevas tarjetas).
- **Seguro desgravamen** 
- Seguro de desgravamen mensual 0.285% del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20
- **Otros gastos** 
- Se cobrará el 3% del monto para operaciones en POS o digitales hechas en el extranjero en moneda diferente al Dólar Americano. 
- (*) Ver más información sobre Tasas y Tarifas [aquí](https://www.viabcp.com/tasasytarifas) .

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo S/ 8,000.
- Debes estar trabajando al momento de solicitar la tarjeta.

#### Documentación en Canal Digital

- No necesitas ningún documento; obtén tu tarjeta al instante ingresando a nuestra web con tu número de tarjeta de débito y tu clave de internet haciendo clic [aquí](https://www.mitarjetabcp.viabcp.com/) .
- La venta está sujeta a evaluación.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesitas una copia de tu documento de identidad.
**Si recibes tu sueldo fuera del BCP**
- **Y eres trabajador dependiente:** 
- Copia de tus dos últimas boletas de pago. 
- Copia del último recibo de teléfono fijo. 
- Copia simple de tu documento de identidad.
- **Y eres trabajador independiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus tres últimas declaraciones de impuestos (PDT) o copia de tu declaración jurada de Impuesto a la Renta. 
- Copia de tu ficha RUC.

---

## Consideraciones


#### ¡Tu eliges cómo asegurarte!

Puedes optar por las siguientes alternativas para asegurarte:
- Elegir la contratación del seguro ofrecido por el BCP.
- Contratar un seguro a través de un corredor de seguros. Este deberá cumplir con las condiciones previamente informadas en el certificado o póliza de seguros.

#### Si vas a realizar compras en el extranjero

- Ten en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación. 
 Para más información sobre las tarifas, clic [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.136188593.1876249796.1645454048-994464575.1644356021) .

#### Sobre el programa Qore​

- Las disposiciones de efectivo, traslados de deuda, préstamo tarjetero, consumos en casinos, pagos de servicios realizados en Banca por Internet o en Banca Móvil, débitos automáticos, pagos de impuestos y servicios legales no acumulan Puntos Qore.
- A partir del 1 de abril del 2024 los clientes que tengan mora mayor a 8 días en el pago de la cuota de su Tarjeta de Crédito BCP, no podrán acumular puntos Qore por los consumos generados a partir del día 9 de mora hasta que se regularice la deuda inclusive. Recién podrá acumular por aquellos consumos realizados a partir del día siguiente después de realizado el pago de su cuota.​​​

#### Ten en cuenta que

- Puedes trasladar tu deuda en soles o dólares a cualquiera de las Tarjetas de Crédito del BCP.
- Tus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realizas disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debes comunicarte con nuestra Banca por Teléfono.
- Recibes la facturación de tus consumos en el Perú en soles y la de los que realizas en el exterior, en dólares (a excepción de los consumos en los establecimientos en el Perú que facturan en dólares).

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 01697-2023.
[Hoja Resumen Visa Signature BCP Qore](https://www.viabcp.com/wcm/connect/d7c64494-e3df-4a57-994d-8bdca672b25c/HR_VISA_SIGNATURE_QORE%2Bv4%2B3%2B%282%29.pdf?MOD=AJPERES&CVID=pAGXcZO&attachment=false&id=1757362532480)
[Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
[VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861) 
 [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599256857185)
[Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
[Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599257023424)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Hoja Resumen Visa Signature BCP Qore](https://www.viabcp.com/wcm/connect/d7c64494-e3df-4a57-994d-8bdca672b25c/HR_VISA_SIGNATURE_QORE%2Bv4%2B3%2B%282%29.pdf?MOD=AJPERES&CVID=pAGXcZO&attachment=false&id=1757362532480)
- [Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
- [VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861)
- [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599256857185)
- [Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
- [Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599257023424)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---

## Preguntas Frecuentes

**¿Cuáles son los principales beneficios de la Visa Signature Qore?**
- Bono de 6mil puntos Qore​ 
- Priority Pass 
- Hasta 24 cuotas sin intereses en + 4,000 establecimientos​ 
- Visa Airport Companion

**¿Qué es Priority Pass Visa Signature BCP Qore?**
Beneficio con el que podrás ingresar ilimitadamente a las Salas VIP Internacionales con 2 invitados GRATIS En caso desees ingresar a una Sala VIP nacional, o con más invitados el costo por cada persona será de $32(1).

**¿Cuál es el costo de membresía de la Tarjeta Visa Signature BCP Qore?**
Membresía anual de S/400, exonerable por un consumo mínimo de S/3500 mensuales.
