# Visa Infinite Sapphire ​LATAM Pass

**Eleva tu experiencia​**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Bono de Millas:** 10,000 Millas por una meta de compras de S/8,000 de los primeros 90 días
- **Priority Pass:** Acceso a salones VIP de vuelos internaciones con 3 invitados
- **Acumula Millas:** Hasta 1.5 millas* por cada USD 1 de consumo
- **Maleta de 23kg adicional:** StartFragment Accede al beneficio registrando tu Código de Socio LATAM

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Beneficios Visa Infinite Sapphire​ LATAM Pass​

- Visa Airport Companion
- Visa Luxury Hotel Collection
- Servicios Médicos de Emergencia Internacional
- Visa Concierge
- Visa Digital Concierge
- Visa Médico Online
- COVID Línea de Ayuda
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Asistencia

- Visa Médico Online.
- COVID Línea de Ayuda.
- Servicios de Asistencia Internacional Visa 24x7 (Desembolso de efectivo, Reemplazo de tarjetas).
- Visa Concierge.
- Visa Digital Concierge.
Conoce más [aquí](https://www.visa.com/portalbeneficios) .
(*) Sólo aplica para casos internacionales

#### Priority Pass

- Accede a más de 1400 Salas VIP* en más de 1000 ciudades de 189 países.
- [Conoce las condiciones aquí](https://www.viabcp.com/wcm/connect/e4dd54f4-8f0e-4629-af98-b186d411e2ec/Consideraciones+Priority+Pass+-+Visa+Infinite+Sapphire.pdf?MOD=AJPERES&CVID=p9D6vVt&attachment=false&id=1728307738128)
- Para mayor información sobre el beneficios ingresar aquí: [https://www.viabcp.com/beneficios/tarjetas](https://www.viabcp.com/beneficios/tarjetas)
**Nuevo Aeropuerto Jorge Chávez:** Accede a los establecimientos y salas de la zona internacional, como La Bonbonniere, Bleirot Bar & Lounge y la sala VIP The Club LIM.
**El restaurante TGI Fridays ubicado en la zona nacional del aeropuerto no está incluido dentro de los beneficios Priority Pass ofrecidos por el BCP. El acceso a establecimientos o salas en zonas nacionales con Priority Pass tiene un costo de USD 32 por persona.*

#### Beneficios adicionales

- GibSky
- Delivery gratis a donde quieras​
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Seguros

- **Seguros de viaje** 
- Seguro de alquiler de vehículos 
- Seguro de inconvenientes en viajes (Demora de Equipaje y/o pérdida de Equipaje).
- **Seguros de compras** 
- Seguro de Protección de Compra 
- Seguro de Protección de Precio 
- Garantía Extendida
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) . 
 Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Visa.

#### Campañas exclusivas

- **Campañas multiplicadoras y sorteos de millas** 
- Podrás participar en campañas exclusivas de Tarjeta de Crédito BCP y ganar millas para canjear productos y/o viajes o participar en sorteos o devolución por compras. Para ello es importante que tengas tus datos actualizados. 
- (*) Las campañas campañas exclusivas y alianzas son temporales.

#### Beneficios adicionales

- **Solicite su Préstamo Tarjetero**
Obtenga liquidez al instante desde su Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslade su deuda**
Libérese de las preocupaciones y reorganice sus deudas.
- **Solicite una Tarjeta Adicional Gratis**
Solicite adicionales sin costo y comparta su línea de crédito.
[Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplíe su línea de crédito**
Solicite un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesita un aumento mayor, acérquese a cualquiera de nuestras agencias. 
 (*) Sujeto a evaluación.
- **Cuenta Sueldo**
Si es cliente Cuenta Sueldo, podrá disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas.
Conoce los Beneficios Cuenta Sueldo [aquí](https://www.viabcp.com/beneficios/todos-los-beneficios) .

#### ¡Afíliese a Cargos recurrentes!

- Realice sus pagos de manera automática con su Tarjeta de Crédito BCP LATAM Pass.
- Pague todos sus pendientes sin tener que ir al banco ni ingresar a la web. Solo debe registrarse con su Clave de Internet y sus pagos se harán de manera automática y sencilla.
- Puede suspender hasta dos cargos seguidos. ¡No se preocupe!, puede desafiliarse cuando quiera.
- Podrá acumular Millas LATAM Pass según el tipo de tarjeta que tenga.
- Conoce más beneficios y cómo hacerlo [aquí.](https://www.viabcp.com/tarjetas/cargos-recurrentes)

---

## LATAM Pass


#### Bono de bienvenida

- Recibe un bono de 10,000 Millas LATAM Pass por una meta mínima de compras de S/8,000 en consumos por POS o por internet durante los primeros 90 días desde la aprobación de tu tarjeta de crédito.​

#### Acumula millas

- Acumula 1.5 millas por US$1 de consumo restaurantes​
- Acumula 1.25 millas por US$1 de consumo en tiendas por departamento, grifos, supermercados y centros de estudios en Perú​
- Acumula 1 milla por US$1 en otros consumos
- [Consideraciones del programa LATAM Pass](https://www.viabcp.com/wcm/connect/3c1a7a29-035d-4145-ac1b-ac35e9ca2d23/Consideraciones%2Bdel%2BPrograma%2BLATAM%2BPass%2B+VISA%2BSAPPHIRE-26.02.pdf?MOD=AJPERES&CVID=oYHnX5S&attachment=false&id=1714419790472)

#### Beneficios Exclusivos

**Beneficios Exclusivos para clientes Visa** **Infinite Sapphire** **LATAM Pass**
Podrás disfrutar de los siguientes beneficios exclusivos por tener una Tarjeta de Crédito Visa Infinite Sapphire BCP LATAM Pass
**Upgrade de cabina con tramos de cortesía​**
Se le otorga una cantidad de tramos de cortesía por única vez para postular a un upgrade en vuelos dentro de Sudamérica y otra cantidad de tramos de cortesía distinta para postular a un upgrade en vuelos fuera de Sudamérica.​
- Dentro de Sudamérica: 2 tramos de cortesía.​
- Fuera de Sudamérica: 1 tramo de cortesía.​
Aplica para vuelos comercializados por LATAM
Para solicitar el upgrade de cabina ingrese [aquí](https://latampass.latam.com/es_pe/upgrade-de-cabina) .
- ​Acceso Premium: Check in preferente sólo para el titular de la tarjeta en vuelos internacionales vendidos y operados por LATAM Airlines en el counter de clase ejecutiva de LATAM del aeropuerto de Lima mostrando su Tarjeta de Crédito VISA Sapphire BCP LATAM Pass.​
- Equipaje adicional: Podrá llevar hasta una maleta adicional de hasta 23 kg permitido en bodega por ruta de viaje en vuelos nacionales e internacionales operados por LATAM.
Condiciones sobre los beneficios **[aquí](https://www.viabcp.com/wcm/connect/7acdb48b-b5c7-45c6-9404-72e6e151aef2/Condiciones_y_restricciones_Visa_Infinite_Sapphire_LATAM_Pass_20_12.pdf?MOD=AJPERES&CVID=pIkgOce&attachment=false&id=1765571650829)**
Conozca los beneficios del programa LATAM Pass [aquí](https://latampass.latam.com/es_pe/acumula-millas/tarjeta-bcp-latam-pass)
Conozca más sobre su tarjeta BCP LATAM Pass **[aquí](https://www.viabcp.com/beneficios/tarjetas?param=visa-infinite-sapphire-latam-pass)** 
 
 La acumulación, canje, uso y demás condiciones aplicables a los beneficios otorgados por las tarjetas BCP LATAM Pass se rigen bajo el reglamento de LATAM Pass publicado **[aquí](https://latampass.latam.com/es_pe/descubre-latam-pass/terminos-y-condiciones)**

---

## Tasas y Tarifas


#### Tasa de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios en S/. 49.0%- 95.9%
- Tasa Efectiva Anual (TEA) para compras o pago de servicios en $: 49.0% - 76.9%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo en S/. : 95.9%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 76.9%​
- Tasa de interés TCEA Máxima en S/.: 189.8%​​
- Tasa de Interés TCEA Máxima en $: 76.9%​

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/450​ 
- Obtén la membresía gratis si consumes como mínimo S/4,500 durante todos los meses en los 12 ciclos de facturación de tu tarjeta. 
- (*) Para mayor información relacionada con [*] de esta tarjeta comuníquese con su sectorista o acérquese a la oficina del banco más cercana.
- **Seguro desgravamen** 
- Seguro de desgravamen mensual 0.285% del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20.
- **Otros gastos** 
- Se cobrará el 3% del monto para operaciones en POS o digitales hechas en el extranjero en moneda diferente al Dólar Americano. 
- (*) Ver más información sobre Tasas y Tarifas [aquí](https://www.viabcp.com/tasasytarifas) .

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo: S/. S/12,000*
- Debes estar trabajando al momento de solicitar la tarjeta. 
 (*) La venta está sujeta a la evaluación crediticia del Cliente.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesita una copia de su documento de identidad.
**Si recibes tu sueldo fuera del BCP**
- **Y es trabajador dependiente:** 
- Copia de sus dos últimas boletas de pago. 
- Copia del último recibo de teléfono fijo. 
- Copia simple de su documento de identidad.
- **Y es trabajador independiente:** 
- Copia simple de su documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de sus tres últimas declaraciones de impuestos (PDT) o copia de su declaración jurada de Impuesto a la Renta. 
- Copia de su ficha RUC.

---

## Consideraciones


#### ¡Tu eliges cómo asegurarte!

Puede optar por las siguientes alternativas para asegurarse:
- Elegir la contratación del seguro ofrecido por el BCP.
- Contratar un seguro a través de un corredor de seguros. Este deberá cumplir con las condiciones previamente informadas en el certificado o póliza de seguros.

#### Si vas a realizar compras en el extranjero

- Tener en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación. 
 Para más información sobre las tarifas, clic [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.136188593.1876249796.1645454048-994464575.1644356021) **.**

#### Sobre el Programa LATAM Pass

- Las disposiciones de efectivo, traslados de deuda, préstamo tarjetero, consumos en casinos, pagos de servicios realizados en Banca por Internet o en Banca Móvil, débitos automáticos, pagos de impuestos y servicios legales no acumulan Millas LATAM Pass. Únicamente los pagos de servicios educativos en viabcp o banca móvil con Tarjeta de crédito Visa Sapphire acumulan **1.25** millas x $1.
- A partir del 1 de abril del 2024 los clientes que tengan mora mayor a 8 días en el pago de la cuota de su Tarjeta de Crédito BCP, no podrán acumular millas por los consumos generados a partir del día 9 de mora hasta que se regularice la deuda inclusive. Recién podrá acumularlas por aquellos consumos realizados a partir del día siguiente después de realizado el pago de su cuota.​

#### Ten en cuenta que

- Puede trasladar su deuda en soles o dólares a cualquiera de las Tarjetas de Crédito del BCP.
- Sus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realiza disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debe comunicarse con nuestra Banca por Teléfono.
- La facturación de tu **Tarjeta de Crédito en el Perú** se realiza en soles, mientras que los consumos efectuados en el exterior se facturan en dólares, excepto en aquellos establecimientos dentro del país que operan en esta moneda.

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 01697-2023.
[Hoja Resumen Visa Infinite Sapphire LATAM Pass](https://www.viabcp.com/wcm/connect/2a577d0a-c9f2-4f9f-bd48-4e87d6c3479a/HR_VISA_LATAM%2B-%2BSapphire%2Bv3.pdf?MOD=AJPERES&CVID=pAGWCSm&attachment=false&id=1757361892182)
[VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861) 
 [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599256857185)
[Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
[Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599257023424)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/5ed7e9e9-c60d-4ac2-adc2-5e3ea87e15e2/INFORMACIO%CC%81N%2BREFERIDA%2BA%2BBENEFICIOS%2BRIESGOS%2BY%2BCONDICIONES%2BDE%2BTARJETA%2BDE%2BCREDITO.pdf?MOD=AJPERES&CVID=oqjphUV&attachment=false&id=1677510124875)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Hoja Resumen Visa Infinite Sapphire LATAM Pass](https://www.viabcp.com/wcm/connect/2a577d0a-c9f2-4f9f-bd48-4e87d6c3479a/HR_VISA_LATAM%2B-%2BSapphire%2Bv3.pdf?MOD=AJPERES&CVID=pAGWCSm&attachment=false&id=1757361892182)
- [VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861)
- [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599256857185)
- [Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
- [Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599257023424)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/5ed7e9e9-c60d-4ac2-adc2-5e3ea87e15e2/INFORMACIO%CC%81N%2BREFERIDA%2BA%2BBENEFICIOS%2BRIESGOS%2BY%2BCONDICIONES%2BDE%2BTARJETA%2BDE%2BCREDITO.pdf?MOD=AJPERES&CVID=oqjphUV&attachment=false&id=1677510124875)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---
