# Tarjeta de CréditoVisa Infinite Qore

**Conoce los beneficios exclusivos de tu Visa Infinite Qore​**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Bono de Puntos Qore​:** 15,000 Puntos Qore por meta de compras de S/ 10,000 durante los primeros 90 días​
- **Priority Pass:** Acceso a salones VIP con 4 invitados.
- **Acumula Puntos Qore​:** Hasta 3 Puntos Qore por cada USD 1 de consumo​

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Beneficios Visa Infinite Qore

- Visa Airport Companion
- Visa Luxury Hotel Collection
- Servicios Médicos de Emergencia Internacional
- Visa Concierge
- Visa Digital Concierge
- Visa Médico Online
- COVID Línea de Ayuda
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Asistencia

- Visa Médico Online.
- COVID Línea de Ayuda.
- Servicios de Asistencia Internacional Visa 24x7 (Desembolso de efectivo, Reemplazo de tarjetas).
- Visa Concierge.
- Visa Digital Concierge.
Conoce más [aquí](https://www.visa.com/portalbeneficios) .
(*) Sólo aplica para casos internacionales

#### Priority Pass

- Accede a más de 1400 Salas VIP* en más de 1000 ciudades de 189 países.
- [Conoce las condiciones aquí](https://www.viabcp.com/wcm/connect/992f2dbf-afa0-43f7-a2e2-bd5cea49e4d1/BCP_Priority+Pass+Infinite+Qore.pdf?MOD=AJPERES&CVID=pkAZRRt&attachment=false&id=1740083371466)
- Para mayor información sobre el beneficios ingresar aquí: [https://www.viabcp.com/beneficios/tarjetas](https://www.viabcp.com/beneficios/tarjetas)
**Nuevo Aeropuerto Jorge Chávez:** Accede a los establecimientos y salas de la zona internacional, como La Bonbonniere, Bleirot Bar & Lounge y la sala VIP The Club LIM.
**El restaurante TGI Fridays ubicado en la zona nacional del aeropuerto no está incluido dentro de los beneficios Priority Pass ofrecidos por el BCP. El acceso a establecimientos o salas en zonas nacionales con Priority Pass tiene un costo de USD 32 por persona.*

#### Beneficios adicionales

- Delivery gratis a donde quieras​
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) .

#### Seguros

- **Seguros de viaje** 
- Seguro de alquiler de vehículos 
- Seguro de inconvenientes en viajes (Demora de Equipaje y/o pérdida de Equipaje).
- **Seguros de compras** 
- Seguro de Protección de Compra 
- Seguro de Protección de Precio 
- Garantía Extendida
Conoce más sobre los términos y condiciones [aquí](https://www.visa.com/portalbeneficios) . 
 Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Visa.

#### Campañas exclusivas

- **Campañas multiplicadoras y sorteos de puntos.​**
​Podrás participar en campañas exclusivas de Tarjeta de Crédito BCP y ganar puntos Qore para canjear productos/servicios. Para ello es importante que tengas tus datos actualizados​
(*) Las campañas exclusivas y alianzas son temporales.

#### Beneficios adicionales

- **Solicite su Préstamo Tarjetero**
Obtenga liquidez al instante desde su Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslade su deuda**
Libérese de las preocupaciones y reorganice sus deudas.
- **Solicite una Tarjeta Adicional Gratis**
Solicite adicionales sin costo y comparta su línea de crédito.
[Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplíe su línea de crédito**
Solicite un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesita un aumento mayor, acérquese a cualquiera de nuestras agencias. 
 (*) Sujeto a evaluación.
- **Cuenta Sueldo**
Si es cliente Cuenta Sueldo, podrá disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas.
Conoce los Beneficios Cuenta Sueldo [aquí](https://www.viabcp.com/beneficios/todos-los-beneficios) .

#### ¡Afíliese a Cargos recurrentes!

- Realice sus pagos de manera automática con su Tarjeta de Crédito BCP Qore​.
- Pague todos sus pendientes sin tener que ir al banco ni ingresar a la web. Solo debe registrarse con su Clave de Internet y sus pagos se harán de manera automática y sencilla.
- Puede suspender hasta dos cargos seguidos. ¡No se preocupe!, puede desafiliarse cuando quiera.
- Podrás acumular Puntos Qore según el tipo de tarjeta que tengas​.
- Conoce más beneficios y cómo hacerlo [aquí.](https://www.viabcp.com/tarjetas/cargos-recurrentes)

---

## Qore


#### Bono de bienvenida

- Recibe un bono de 15,000 Puntos Qore por una meta mínima de compras de S/10,000 en consumos por POS o por internet durante los primeros 90 días desde la aprobación de tu tarjeta de crédito.​

#### Acumula puntos Qore

- Acumule 3 Puntos Qore por $1 consumido en restaurantes y supermercados.​
- Acumule 2 puntos por $1 consumido en grifos y compras realizadas en el extranjero​
- Acumule 1 punto por $1 consumido en los demás rubros de consumo.
- 1 Punto Qore por US$1 en otros consumos​
[Consideraciones de puntos Visa Infinite Qore](https://www.viabcp.com/wcm/connect/c04641c8-20a2-44ce-b524-1d82a2b263b9/Pauta+Puntos+Infinite+Qore.pdf?MOD=AJPERES&CVID=pkzysO9&attachment=false&id=1740058072238)

#### Beneficios Exclusivos

- **Descuentos Qore:** Disfrute de una variedad de establecimientos físicos y virtuales en donde podrá hacer uso de sus descuentos.​
- **Acumulación y Canje de Puntos Qore:** Acumule Puntos Qore y disfrútelos canjeando productos y servicios exclusivos.​
- **Acumulación adicional por Nivel:** Podrá acumular Puntos Qore adicionales a los acumulados como base ($1 = 1 Punto) según el nivel al que pertenezca (Nivel 5: +20%, Nivel 4: 10%, Nivel 3: 5%).​
Conozca los beneficios de Qore [aquí](https://www.viabcp.com/qore) .
La acumulación, canje, uso y demás condiciones a los beneficios otorgados por las tarjetas BCP Qore se rigen bajo los términos y condiciones del programa publicados [aquí](https://www.viabcp.com/qore) .

---

## Tasas y Tarifas


#### Tasa de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios: 33.00% - 63.00%
- Tasa Efectiva Anual (TEA) para compras o pago de servicios en $: 33.00% - 63.00%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo​: 81.50%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 66%​
- Tasa de interés TCEA Máxima 161.74%
- Tasa de Interés TCEA MÁXIMA en $: 63.00%​

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/ 500 
- Puede exonerarse del pago de membresía si su consumo anual es igual o mayor a S/180,000 o si su consumo anual es igual o mayor a S/60,000 y además cumple con alguna de estas dos condiciones en el mes previo al cobro de la membresía: 
- Cuenta con cico o más productos diferentes en el BCP 
- Cuenta con mínimo 250,000 en ahorros e inversiones en BCP 
- (*) Para mayor información relacionada con [*] de esta tarjeta comuníquese con su sectorista o acérquese a la oficina del banco más cercana.
- **Seguro desgravamen** 
- Seguro de desgravamen mensual 0.285% del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20.
- **Otros gastos** 
- Se cobrará el 3% del monto para operaciones en POS o digitales hechas en el extranjero en moneda diferente al Dólar Americano. 
- (*) Ver más información sobre Tasas y Tarifas [aquí](https://www.viabcp.com/tasasytarifas) .

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo: S/. 20,000*
- Debes estar trabajando al momento de solicitar la tarjeta. 
 (*) La venta está sujeta a la evaluación crediticia del Cliente.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesita una copia de su documento de identidad.
**Si recibes tu sueldo fuera del BCP**
- **Y es trabajador dependiente:** 
- Copia de sus dos últimas boletas de pago. 
- Copia del último recibo de teléfono fijo. 
- Copia simple de su documento de identidad.
- **Y es trabajador independiente:** 
- Copia simple de su documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de sus tres últimas declaraciones de impuestos (PDT) o copia de su declaración jurada de Impuesto a la Renta. 
- Copia de su ficha RUC.

---

## Consideraciones


#### ¡Tu eliges cómo asegurarte!

Puede optar por las siguientes alternativas para asegurarse:
- Elegir la contratación del seguro ofrecido por el BCP.
- Contratar un seguro a través de un corredor de seguros. Este deberá cumplir con las condiciones previamente informadas en el certificado o póliza de seguros.

#### Si vas a realizar compras en el extranjero

- Tener en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación. 
 Para más información sobre las tarifas, clic [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.136188593.1876249796.1645454048-994464575.1644356021) **.**

#### Sobre el Programa Qore​

- Las disposiciones de efectivo, traslados de deuda, préstamo tarjetero, consumos en casinos, pagos de servicios realizados en Banca por Internet o en Banca Móvil, débitos automáticos, pagos de impuestos y servicios legales no acumulan Puntos Qore.
- A partir del 1 de abril del 2024 los clientes que tengan mora mayor a 8 días en el pago de la cuota de su Tarjeta de Crédito BCP, no podrán acumular puntos Qore por los consumos generados a partir del día 9 de mora hasta que se regularice la deuda inclusive. Recién podrá acumular por aquellos consumos realizados a partir del día siguiente después de realizado el pago de su cuota.​

#### Ten en cuenta que

- Puede trasladar su deuda en soles o dólares a cualquiera de las Tarjetas de Crédito del BCP.
- Sus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realiza disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debe comunicarse con nuestra Banca por Teléfono.
- Reciba la facturación de sus consumos en el Perú en soles y la de las que realiza en el exterior, en dólares (a excepción de los consumos en los establecimientos en el Perú que facturan en dólares).

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 01697-2023.
[Hoja Resumen Visa Infinite BCP Qore](https://www.viabcp.com/wcm/connect/85b8483f-2c67-4d76-8bb3-0f714bc20fdd/HR_VISA_INFINITE_QORE%2Bv4.pdf?MOD=AJPERES&CVID=pAGXiN5&attachment=false&id=1757362844991)
[VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861) 
 [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599256857185)
[Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
[Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599257023424)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/5ed7e9e9-c60d-4ac2-adc2-5e3ea87e15e2/INFORMACIO%CC%81N%2BREFERIDA%2BA%2BBENEFICIOS%2BRIESGOS%2BY%2BCONDICIONES%2BDE%2BTARJETA%2BDE%2BCREDITO.pdf?MOD=AJPERES&CVID=oqjphUV&attachment=false&id=1677510124875)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Hoja Resumen Visa Infinite BCP Qore](https://www.viabcp.com/wcm/connect/85b8483f-2c67-4d76-8bb3-0f714bc20fdd/HR_VISA_INFINITE_QORE%2Bv4.pdf?MOD=AJPERES&CVID=pAGXiN5&attachment=false&id=1757362844991)
- [VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861)
- [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/2392525e-1e63-4a1a-858a-af7d1b1955c7/_2.FORMATO_SOLICITUD_TARJETA_DESGRAVAMEN+_+modificado.pdf?MOD=AJPERES&CVID=pAqp2bJ&attachment=false&id=1757084824370)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599256857185)
- [Fórmulas y ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
- [Contrato de Tarjeta de Crédito - Vigente desde Setiembre 2025](https://www.viabcp.com/wcm/connect/67120e75-23ef-4ac7-ac72-ac6f87634a25/Contrato+de+tarjeta+de+Cr%C3%A9dito+BCP%28SEPT+25%29.pdf?MOD=AJPERES&CVID=pAqrc8b&attachment=false&id=1757085222598)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599257023424)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/5ed7e9e9-c60d-4ac2-adc2-5e3ea87e15e2/INFORMACIO%CC%81N%2BREFERIDA%2BA%2BBENEFICIOS%2BRIESGOS%2BY%2BCONDICIONES%2BDE%2BTARJETA%2BDE%2BCREDITO.pdf?MOD=AJPERES&CVID=oqjphUV&attachment=false&id=1677510124875)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---

## Preguntas Frecuentes

**¿Qué es Visa Infinite Qore​ Perú?**
Es una tarjeta de crédito exclusiva ofrecida por el Banco de Crédito del Perú (BCP) que brinda beneficios premium como límites de crédito más altos, acceso a salas VIP en aeropuertos, asistencia de viaje, seguros ampliados y más.

**¿Cómo obtener la Visa Infinite Qore​?**
Para obtener una tarjeta Visa Infinite Qore​ debes completar el proceso de solicitud correspondiente mediante la web www.mitarjetabcp.viabcp.com o desde tu app Banca Móvil BCP. La oferta se encuentra sujeta a evaluación crediticia.

**¿Qué beneficios tiene Visa Infinite Qore​?**
- Bono 15,000 Puntos Qore 
- Priority Pass 
- Hasta 24 cuotas sin intereses en + 4,000 establecimientos 
- Visa Airport Companion

**Visa Infinite Qore​ requisitos**
- Ingreso mensual mínimo: S/. 20,000* 
- Debes estar trabajando al momento de solicitar la tarjeta. (*) La venta está sujeta a la evaluación crediticia del Cliente.
