# Tarjeta de Crédito Visa Clásica

**Simple y fácil**

**Solicítala aquí:** https://www.mitarjetabcp.viabcp.com/?pcid=viabcp:home:tu-proxima-tarjeta:masivo:cintillo

---

## Beneficios Destacados

- **Beneficios exclusivos:** Podrás participar en campañas exclusivas.
- **Compra en Cuotas Sin Intereses:** Realiza tus compras hasta en 24 cuotas **[aquí](https://www.viabcp.com/beneficios/cuotas-sin-intereses)**
- **Beneficios Visa:** Descubre un mundo de beneficios **[aquí](https://www.visa.com/portalbeneficios)**

---

## Cómo Obtenerla

1. **Validaremos tu identidad** — Por tu seguridad.
2. **Ingresa tu tarjeta de débito** — Número y clave.
3. **Elige una Tarjeta de Crédito BCP** — Perfecta para ti.
4. **Elige como obtenerla** — Recogerla o recibirla GRATIS en casa.
5. **Ingresa y/o confirma tus datos** — Para el envio del contrato.
6. **Ingresa el código de validación** — Te llegará una notificación a tu Banca Móvil.
7. **¡Listo!** — Disfruta tu Tarjeta de Crédito BCP.

---

## Beneficios


#### Asistencia

Servicio de Asistencia Internacional Visa 24x7 (desembolso de efectivo y reemplazo de tarjetas). Conoce más [aquí](http://www.visa.com/portalbeneficios) . 
 (*) Sólo aplica para casos internacionales

#### Beneficios Especiales

- **Delivery gratis a donde quieras​**

#### Seguros

- **Seguros de compras** 
- Seguro de Protección de Precio
Conoce más sobre los términos y condiciones [aquí](http://www.visa.com/portalbeneficios) . 
 Los seguros aplican mientras la Tarjeta de Crédito BCP se use y se encuentre vigente. Sujeto a las condiciones de Visa.

#### Campañas exclusivas

- **Campañas de cashback** 
- Podrás participar en campañas de Tarjeta de Crédito BCP para obtener una devolución por las compras que realices. 
- (*) Las campañas exclusivas son temporales.

#### Beneficios Adicionales

- **Solicita tu Préstamo Tarjetero**
Obtén liquidez al instante desde tu Tarjeta de Crédito BCP a una tasa de interés preferencial.
- **Traslada tu deuda**
Libérate de las preocupaciones y reorganiza tus deudas.
- **Solicita una Tarjeta Adicional Gratis**
Solicita adicionales sin costo y comparte tu línea de crédito.
[Contrato de Tarjeta de Crédito para Adicionales](https://www.viabcp.com/wcm/connect/1bce07de-799f-430a-94b1-947d88fb04f5/CONTRATO_TARJETA_DE_CREDITO.pdf?MOD=AJPERES&CVID=nLGzhUE&attachment=false&id=1631727722615)
- **Amplía tu línea de crédito**
Solicita un aumento de línea de hasta el 10% a través de Banca por Teléfono. Si necesitas un aumento mayor, acércate a cualquiera de nuestras agencias.
(*) Sujeto a evaluación.
- **Mejora tu tarjeta**
Se conoce como “Upgrade”. Puedes cambiar tu tarjeta por otra con beneficios adicionales.
(*) Sujeto a evaluación.
- **Cuenta Sueldo**
Si eres cliente Cuenta Sueldo, podrás disfrutar de descuentos exclusivos adicionales en restaurantes, diversas marcas, sorteos y experiencias únicas.
Conoce los Beneficios Cuenta Sueldo [aquí](https://www.viabcp.com/beneficios/todos-los-beneficios) .

#### ¡Afíliate a Cargos recurrentes!

- Realiza tus pagos de manera automática con tu Tarjeta de Crédito BCP.
- Paga todos tus pendientes sin tener que ir al banco ni ingresar a la web. Solo debes registrarte con tu Clave de Internet y tus pagos se harán de manera automática y sencilla.
- Puedes suspender hasta dos cargos seguidos. ¡No te preocupes!, puedes desafiliarte cuando quieras.
- Conoce más beneficios y cómo hacerlo [aquí](https://www.viabcp.com/tarjetas/cargos-recurrentes) .

---

## Tasas y Tarifas


#### Tasas de interés

- Tasa Efectiva Anual (TEA) para compras o pago de servicios: 83.40% - 95.90%
- ​Tasa Efectiva Anual (TEA) para compras o pago de servicios en $​: 76.90%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo​: 107.00%​
- Tasa Efectiva Anual (TEA) para retiro de efectivo en $: 85.9%​
- Tasa de interés TCEA Máxima 118.64%
- Tasa de Interés TCEA Máxima en $: 76.90%​

#### Comisiones y otros gastos

- **Membresía** 
- Costo de membresía anual: S/ 80. 
- ¡Exonérate del pago de membresía! 
- Solo si consumes todos los meses y el consumo promedio de 12 meses es igual o mayor a S/ 50 (aplica para venta de nuevas tarjetas).
- **Seguro de desgravamen** 
- Seguro de desgravamen mensual 0.285% del saldo deudor promedio diario del ciclo de facturación con un tope máximo a pagar de S/ 20.
- **Otros gastos** 
- Se cobrará el 3% del monto para operaciones en POS o digitales hechas en el extranjero en moneda diferente al Dólar Americano. 
- (*) Ver más información sobre tasas y tarifas [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.136222385.1876249796.1645454048-994464575.1644356021) .

---

## Requisitos


#### Requisitos Generales

- Ingreso mensual mínimo S/ 850.
- Debes estar trabajando al momento de solicitar la tarjeta.

#### Documentación en Canal Digital

- No necesitas ningún documento; obtén tu tarjeta al instante ingresando a nuestra web con tu número de tarjeta de débito y tu clave de internet haciendo clic [aquí](https://www.mitarjetabcp.viabcp.com/) .
- La venta está sujeta a evaluación.

#### Documentación en Canal Presencial

**Si recibes tu sueldo en el BCP**
Solo necesitas una copia de tu documento de identidad.
**Si recibes tu sueldo fuera del BCP**
- **Y eres trabajador dependiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus dos últimas boletas de pago.
- **Y eres trabajador independiente:** 
- Copia simple de tu documento de identidad. 
- Copia del último recibo de teléfono fijo. 
- Copia de tus tres últimas declaraciones de impuestos (PDT) o copia de tu declaración jurada de Impuesto a la Renta. 
- Copia de tu ficha RUC.

---

## Consideraciones


#### ¡Tu eliges cómo asegurarte!

Puedes optar por las siguientes alternativas para asegurarte:
- Elegir la contratación del seguro ofrecido por el BCP.
- Contratar un seguro a través de un corredor de seguros. Este deberá cumplir con las condiciones previamente informadas en el certificado o póliza de seguros.

#### Si vas a realizar compras en el extranjero

- Ten en cuenta que el tipo de cambio no es administrado ni pactado en el BCP, por lo que podría variar el importe al momento de la facturación. 
 Para más información sobre las tarifas, clic [aquí](https://www.viabcp.com/tasasytarifas?_ga=2.161300029.1876249796.1645454048-994464575.1644356021) **.**

#### Ten en cuenta que

- Puedes trasladar tu deuda en soles o dólares a cualquiera de las Tarjetas de Crédito del BCP.
- Tus compras en cuotas sólo aplican para consumos nacionales y no a consumos en el extranjero.
- Si realizas disposiciones en efectivo en cajeros automáticos, puedes pactar en cuotas; para ello, debes comunicarte con nuestra Banca por Teléfono.
- Recibes la facturación de tus consumos en el Perú en soles y la de los que realizas en el exterior, en dólares (a excepción de los consumos en los establecimientos en el Perú que facturan en dólares).

---

## Documentación

Los formularios contractuales de esta sección se encuentran aprobados por la SBS mediante Resolución N° 01697-2023.
[Hoja Resumen Visa Clásica](https://www.viabcp.com/wcm/connect/e9986a1d-8e9e-4e02-96dc-b218ae517628/HR_VISA_CLASICA%2B-%2B0712.pdf?MOD=AJPERES&CVID=pAG.U4i&attachment=false&id=1757363238118)
[Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
[Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/e99d5ced-603e-4025-a7a3-0c9954c64270/2.%2BFORMATO%2BSOLICITUD%2BTARJETA%2B%2B%2BDESGRAVAMEN.pdf?MOD=AJPERES&CVID=oRlZObl&attachment=false&id=1676576383422)
[Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599504096626)
[Fórmulas y Ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
[VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861) 
 [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
[Contrato de Tarjeta de Crédito - Vigente desde Octubre 2023](https://www.viabcp.com/wcm/connect/11ffb5d9-8477-4e1e-b715-684c938f4d99/Contrato+TC+Octubre.pdf?MOD=AJPERES&CVID=oR6bi5z)
[Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599504247445)
[Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
[Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
[Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

### Documentos Descargables

- [Hoja Resumen Visa Clásica](https://www.viabcp.com/wcm/connect/e9986a1d-8e9e-4e02-96dc-b218ae517628/HR_VISA_CLASICA%2B-%2B0712.pdf?MOD=AJPERES&CVID=pAG.U4i&attachment=false&id=1757363238118)
- [Pasos endoso de la Póliza de seguro de desgravamen](https://www.viabcp.com/wcm/connect/cef01ea6-d665-414e-9c67-add2ee5bcb6a/Pasos%2Bpara%2Bendoso%2Bde%2Bseguro%2Bde%2Bdesgravamen%2By%2Bde%2Binmueble+15.04.24.pdf?MOD=AJPERES&CVID=oZYy6Xt&attachment=false&id=1715781342097)
- [Solicitud de Tarjeta de Crédito-Cuadernillo SUFP5308](https://www.viabcp.com/wcm/connect/e99d5ced-603e-4025-a7a3-0c9954c64270/2.%2BFORMATO%2BSOLICITUD%2BTARJETA%2B%2B%2BDESGRAVAMEN.pdf?MOD=AJPERES&CVID=oRlZObl&attachment=false&id=1676576383422)
- [Solicitud Compra de Deuda Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/de84701a-e90a-4c35-a490-0d0faadfc9a7/Solicitud+Compra+de+Deuda+Tarjeta+de+Cre%CC%81dito.pdf?MOD=AJPERES&CVID=nhqiFlD&attachment=true&id=1599504096626)
- [Fórmulas y Ejemplos explicativos Tarjeta de Crédito](https://www.viabcp.com/wcm/connect/ba52f6c9-ea9d-435e-80d3-b77b44a1eef0/Fo%CC%81rmulas%2BTarjetas_de_Cre%CC%81dito_Noviembre.pdf.pdf?MOD=AJPERES&CVID=pJbCBNH&attachment=false&id=1766500368787)
- [VISA 10 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/539b11f3-4af9-4bb5-a5bb-d2f1463b6f9e/VISA+10+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25eqJ&attachment=false&id=1768487818861)
- [VISA 25 - Cronograma virtual de pagos TC 2026](https://www.viabcp.com/wcm/connect/49cbe3d9-5f47-43be-a8f4-5a1b7134a63b/VISA+25+-+Cronograma+Virtual+de+Pago+TC+2025.pdf?MOD=AJPERES&CVID=pL25EyS&attachment=false&id=1768491236828)
- [Contrato de Tarjeta de Crédito - Vigente desde Octubre 2023](https://www.viabcp.com/wcm/connect/11ffb5d9-8477-4e1e-b715-684c938f4d99/Contrato+TC+Octubre.pdf?MOD=AJPERES&CVID=oR6bi5z)
- [Contrato de Afiliación a Cargos Recurrentes](https://www.viabcp.com/wcm/connect/65a03d3d-f1b7-452d-b37d-c0fd2bbff48a/Contrato_Afiliacio%CC%81n+a+Cargos+Recurrentes.pdf?MOD=AJPERES&CVID=nhqfn.t&attachment=true&id=1599504247445)
- [Beneficios, riesgos y condiciones de las tarjetas de crédito](https://www.viabcp.com/wcm/connect/c6b76b1f-1fd0-4f4f-9d05-c2b6ababeeab/INFORMACI%C3%93N+REFERIDA+A+BENEFICIOS+RIESGOS+Y+CONDICIONES+DE+TARJETA+DE+CREDITO.pdf?MOD=AJPERES&CVID=nMZPUMx&attachment=false&id=1633124584835)
- [Requisitos a presentar para el reembolso o anulación de compras y/o consumos](https://www.viabcp.com/wcm/connect/0931d2ce-29cd-4b26-bb55-0aa27142df8a/Requisitos+a+presentar+para+el+reembolso+o+anulacio%CC%81n+de+compras+o+consumos.pdf?MOD=AJPERES&CVID=o58TBb9&attachment=false&id=1654784939073)
- [Lo que debes conocer sobre todas nuestras Cuentas](https://www.viabcp.com/wcm/connect/bbbf6e90-6dab-42d6-a1a5-93b9c398e8fb/Lo+que+debes+conocer+sobre+todas+nuestras+Cuentas.pdf?MOD=AJPERES&CVID=o5eli5M&attachment=false&id=1654876612320)

---

## Preguntas Frecuentes

**¿Qué es la Tarjeta Visa Clásica?**
Es una [tarjeta](https://www.mitarjetabcp.viabcp.com/) de crédito emitida por el Banco de Crédito del Perú (BCP), que ofrece beneficios como cuotas sin intereses en establecimientos seleccionados, pagos en línea, compras en establecimientos comerciales y más.

**¿Cómo obtener la Tarjeta Visa Clásica?**
Para obtener una tarjeta Visa Clásica BCP debes completar el proceso de solicitud correspondiente mediante la web [www.mitarjetabcp.viabcp.com](https://www.mitarjetabcp.viabcp.com/) o desde tu app Banca Móvil BCP. La oferta se encuentra sujeta a evaluación crediticia.

**¿Qué beneficios tiene la Tarjeta Visa Clásica?**
- Exoneración de membresía por un consumo mínimo de S/50 al mes. 
- Hasta 24 cuotas sin intereses en + 4,000 establecimientos.
